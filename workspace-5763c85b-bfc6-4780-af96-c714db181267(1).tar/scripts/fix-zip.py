"""Shrink repo screenshots and rebuild the Hashpilot zip with a clean, standard structure."""
import os
import zipfile
from PIL import Image

BASE = "/home/z/my-project/download"
SHOTS = os.path.join(BASE, "hashpilot", "docs", "screenshots")

# 1. Compress screenshots: PNG -> optimized JPG, max width 1100px
total_before = 0
total_after = 0
for name in ["home", "analyze", "trends", "mobile"]:
    png = os.path.join(SHOTS, f"{name}.png")
    jpg = os.path.join(SHOTS, f"{name}.jpg")
    if os.path.exists(png):
        total_before += os.path.getsize(png)
        im = Image.open(png).convert("RGB")
        w, h = im.size
        if w > 1100:
            im = im.resize((1100, round(h * 1100 / w)), Image.LANCZOS)
        im.save(jpg, "JPEG", quality=82, optimize=True, progressive=True)
        total_after += os.path.getsize(jpg)
        os.remove(png)
        print(f"{name}.png -> {name}.jpg  {os.path.getsize(jpg) // 1024}KB")

print(f"screenshots: {total_before // 1024}KB -> {total_after // 1024}KB")

# 2. Rebuild zip with Python zipfile (standard deflate, no unix extras)
zip_path = os.path.join(BASE, "hashpilot.zip")
if os.path.exists(zip_path):
    os.remove(zip_path)

count = 0
with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for root, dirs, files in os.walk(os.path.join(BASE, "hashpilot")):
        dirs.sort()
        for f in sorted(files):
            full = os.path.join(root, f)
            arc = os.path.relpath(full, BASE)  # paths start with hashpilot/
            z.write(full, arc)
            count += 1

os.chmod(zip_path, 0o644)
print(f"zip rebuilt: {count} files, {os.path.getsize(zip_path) // 1024}KB")
