// Quick engine sanity check: run sample captions through all strategies.
import { analyze, regenerateTags, replacementFor, getTrending, fmtCount } from "../src/lib/tagline/engine";
import type { AnalyzeInput } from "../src/lib/tagline/types";

const samples = [
  "Just landed in Tokyo. The food, architecture and tiny coffee shops completely surprised me.",
  "Five months of consistent lifting and the numbers finally moved. Here is the exact push day split I used, down to the rest times.",
  "Our small studio just shipped its first collection. Handmade ceramics, hand-glazed, made in batches of twenty.",
];

for (const caption of samples) {
  console.log("\n=== " + caption.slice(0, 50) + " ===");
  const detected = analyze({ caption, platform: "instagram", categories: [], strategy: "balanced" });
  console.log("detected:", detected.detected.join(", ") || "(none)", "| signals:", detected.signals.join(", "));
  for (const strategy of ["balanced", "reach", "niche"] as const) {
    const a = analyze({ caption, platform: "instagram", categories: [], strategy });
    const tops = a.tags.slice(0, 5).map((t) => `${t.tag}:${t.score}/${t.relevance}r ${t.status === "Rising" ? "+" : ""}${t.momentum}%`);
    console.log(`${strategy.padEnd(8)} avg=${a.stats.average} rising=${a.stats.rising} | ${tops.join("  ")}`);
  }
}

// Check niche vs reach actually reorder
const cap = samples[0];
const b = analyze({ caption: cap, platform: "instagram", categories: [], strategy: "balanced" });
const n = analyze({ caption: cap, platform: "instagram", categories: [], strategy: "niche" });
const r = analyze({ caption: cap, platform: "instagram", categories: [], strategy: "reach" });
const order = (x: typeof b) => x.tags.slice(0, 6).map((t) => t.tag).join(",");
console.log("\nbalance order:", order(b));
console.log("niche order:  ", order(n));
console.log("reach order:  ", order(r));

// Replacement + regenerate
const replaced = replacementFor({ caption: cap, platform: "instagram", categories: [], strategy: "balanced" }, b.tags.map((t) => t.tag), "food");
console.log("\nreplacement for food slot:", replaced?.tag, replaced?.score);
const regen = regenerateTags({ caption: cap, platform: "instagram", categories: [], strategy: "balanced" }, b.tags);
console.log("regenerate kept anchors:", regen.slice(0, 3).map((t) => t.tag).join(","), "| total:", regen.length, "| unique:", new Set(regen.map((t) => t.tag)).size === regen.length);

// Trends
const tr = getTrending({ platform: "instagram", category: "all", sort: "fastest" });
console.log("\ntrend fastest (ig):", tr.slice(0, 4).map((t) => `${t.tag} +${t.rec.momentum}% ${fmtCount(t.rec.volume)}`).join(" | "));
const tr2 = getTrending({ platform: "all", category: "all", sort: "competition" });
console.log("trend lowest comp:", tr2.slice(0, 4).map((t) => `${t.tag} ${t.rec.competition}`).join(" | "));
