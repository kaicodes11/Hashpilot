import type { NextConfig } from "next";

/**
 * Hashpilot builds to a fully static site in `out/`.
 *
 * For GitHub Pages project sites the app is served from /<repo-name>/,
 * so set the base path at build time:
 *
 *   NEXT_PUBLIC_BASE_PATH=/your-repo-name npm run build
 *
 * Leave it empty for hosting at a domain root (Vercel, Netlify, custom domain).
 */
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";

const nextConfig: NextConfig = {
  output: "export",
  basePath: basePath || undefined,
  images: {
    unoptimized: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
};

export default nextConfig;
