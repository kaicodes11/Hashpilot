<p align="center">
  <img src="public/logo.png" width="72" alt="Hashpilot logo" />
</p>

<h1 align="center">Hashpilot</h1>

<p align="center">
  Hashtag research for working creators.<br />
  Paste a post, pick a strategy, and see which conversations are gaining momentum.
</p>

<p align="center">
  <a href="#run-it-locally">Run locally</a> &middot;
  <a href="#publish-on-github-pages">Publish to GitHub Pages</a> &middot;
  <a href="#how-the-ranking-works">How ranking works</a>
</p>

## Screenshots

| Analyze | Trends |
| --- | --- |
| ![Analyze view](docs/screenshots/analyze.jpg) | ![Trends view](docs/screenshots/trends.jpg) |

| Home | Mobile |
| --- | --- |
| ![Home](docs/screenshots/home.jpg) | ![Mobile](docs/screenshots/mobile.jpg) |

## What it does

Hashpilot sits between your draft and the publish button. You paste the caption you are about to post, and the tool reads it the way an editor would: which topic words matter, which communities talk about them, and where activity is actually moving right now.

- **Ranked recommendations.** Every tag gets an opportunity score out of 100, plus search demand, competition level, relevance to your caption, reach potential and a one line reason for why it is on the list.
- **Three strategies that change the ranking.** Balanced, Reach and Niche reweight the same signals differently, so the mix you copy matches the goal of the post.
- **Working set builder.** Select tags into a tray, reorder them, replace weak ones with alternatives, and copy the whole set in one click.
- **Trends view.** A sortable table of what is rising across platforms, filterable by platform and category.
- **Saved and History.** Keep tags, sets and collections for later, and reopen any past analysis with its original inputs.
- **Everything is stored locally** in your browser. No account, no server, no tracking.

## Run it locally

Requires Node.js 20 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000. Try the sample captions in the composer, or paste your own.

## Build for production

The app is fully static. There is no server component and no database.

```bash
npm run build
```

The site is generated into `out/`. You can host it anywhere that serves files.

## Publish on GitHub Pages

This repository ships with a prebuilt site in the `docs/` folder, so publishing takes two steps:

1. Push this repository to GitHub.
2. In the repository settings, open **Pages**, set **Source** to *Deploy from a branch*, pick your main branch and the **/docs** folder, then save.

Your site goes live at `https://<username>.github.io/<repo-name>/`.

The included `docs/` build assumes the repository is named `hashpilot`. If you renamed the repository, rebuild with a matching base path and replace the contents of `docs/` with the new `out/` folder:

```bash
NEXT_PUBLIC_BASE_PATH=/your-repo-name npm run build
```

For a domain root deployment (Vercel, Netlify, Cloudflare Pages, or a user page repository), build without the base path and upload `out/`.

## How the ranking works

Each caption is tokenized, then matched against a topic vocabulary of eight categories: Travel, Food, Fashion, Fitness, Beauty, Business, Technology and Lifestyle. Every tag in the corpus carries a demand, competition, momentum and reach profile. The score for each tag is assembled from four signals:

| Signal | What it measures |
| --- | --- |
| Content analysis | Topic word overlap between the caption and the tag |
| Trend signal | 24 hour and 14 day momentum, which sets the Rising, Stable or Falling status |
| Audience fit | How closely the tag matches the detected categories |
| Competition | How hard it is to place into the feed for that tag today |

The strategy you pick changes the weighting:

- **Balanced** mixes reach, relevance and competition evenly. The default for most posts.
- **Reach** favors large, active conversations, accepting more competition for more eyes.
- **Niche** favors low competition communities with strong relevance, where a small account can actually rank.

The dataset in `src/lib/hashpilot/corpus.ts` is demo data with realistic shapes: volume, competition tiers, momentum deltas and platform fit. The engine and the UI treat it as a pluggable layer, so a real trend API can replace it without touching any component. Types in `src/lib/hashpilot/types.ts` describe the contract.

## Project structure

```
hashpilot/
├── docs/                        Prebuilt static site, ready for GitHub Pages
├── public/                      Logo and robots.txt
├── src/
│   ├── app/                     Layout, page shell, design system
│   ├── components/hashpilot/    Composer, results, trends, saved, history, set tray
│   └── lib/hashpilot/           Corpus, scoring engine, types, storage
├── next.config.ts               Static export configuration
├── package.json
├── postcss.config.mjs
└── tsconfig.json
```

## Tech

Next.js 16, React 19, Tailwind CSS 4 and TypeScript. The app has no runtime dependencies beyond the framework, and all state lives in the browser.

## License

Released under the [MIT License](LICENSE).
