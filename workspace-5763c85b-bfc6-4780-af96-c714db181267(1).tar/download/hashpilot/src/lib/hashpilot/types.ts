// Hashpilot core types.
// The corpus + engine are isolated here so a real trend API can replace
// `corpus.ts` / `engine.ts` internals without touching any UI code.

export type Platform = "instagram" | "tiktok" | "youtube" | "linkedin";

export type Category =
  | "travel"
  | "food"
  | "fashion"
  | "fitness"
  | "beauty"
  | "business"
  | "technology"
  | "lifestyle";

export type Competition = "Low" | "Medium" | "High";
export type Demand = "Low" | "Medium" | "High" | "Very high";
export type Status = "Rising" | "Stable" | "Falling";
export type Strategy = "balanced" | "reach" | "niche";

export type TrendSort =
  | "fastest"
  | "reach"
  | "competition"
  | "opportunity";

export interface HashtagRecord {
  tag: string; // without "#"
  category: Category;
  secondary?: Category;
  keywords: string[]; // caption tokens that indicate a strong match
  volume: number; // approximate monthly posts
  competition: Competition;
  momentum: number; // 24h change, percent
  momentum7: number; // 7d change, percent
  platforms: Platform[]; // platforms where the tag performs best
  note?: string;
}

export interface Spark {
  tag: string;
  points: number[]; // 14 day relative interest
}

export interface ReachEstimate {
  label: "Compact" | "Solid" | "Large" | "Very large";
  low: number; // estimated weekly impressions
  high: number;
}

export interface RankedTag {
  tag: string;
  score: number; // opportunity 0-100
  relevance: number; // 0-100
  momentum: number; // 24h %
  momentum7: number; // 7d %
  competition: Competition;
  demand: Demand;
  status: Status;
  reach: ReachEstimate;
  audienceFit: string;
  reason: string;
  why: string; // "Why this tag" paragraph
  spark: number[];
  category: Category;
  secondary?: Category;
  volume: number;
  matched: string[]; // caption keywords that matched
}

export interface AnalyzeInput {
  caption: string;
  platform: Platform;
  categories: Category[];
  strategy: Strategy;
  seed?: number;
}

export interface AnalysisStats {
  average: number;
  rising: number;
  stable: number;
  falling: number;
}

export interface Analysis {
  id: string;
  createdAt: number;
  input: AnalyzeInput;
  detected: Category[]; // categories detected from the caption
  signals: string[]; // matched topic words from the caption
  tags: RankedTag[];
  stats: AnalysisStats;
  stale?: boolean; // caption edited after the analysis ran
}

export interface SavedTag {
  tag: string;
  score: number;
  momentum: number;
  competition: Competition;
  category: Category;
  platform: Platform;
  savedAt: number;
}

export interface TagSet {
  id: string;
  name: string;
  collectionId: string;
  tags: string[];
  platform: Platform;
  createdAt: number;
}

export interface Collection {
  id: string;
  name: string;
  createdAt: number;
}

export interface HistoryEntry {
  id: string;
  createdAt: number;
  caption: string;
  platform: Platform;
  categories: Category[];
  strategy: Strategy;
  seed: number;
  tagCount: number;
  topTag: string;
  topScore: number;
  selected: string[]; // the final set at time of analysis
}

export interface Topic {
  label: string;
  momentum: number;
  category: Category;
  relatedTag: string;
}

export const PLATFORM_LABEL: Record<Platform, string> = {
  instagram: "Instagram",
  tiktok: "TikTok",
  youtube: "YouTube",
  linkedin: "LinkedIn",
};

export const PLATFORM_GUIDE: Record<Platform, { rec: number; max: number; note: string }> = {
  instagram: { rec: 12, max: 30, note: "Instagram performs best with 12 to 15 focused tags." },
  tiktok: { rec: 6, max: 10, note: "TikTok favors 4 to 6 precise tags over long lists." },
  youtube: { rec: 4, max: 8, note: "YouTube reads the first 3 tags above everything else." },
  linkedin: { rec: 4, max: 6, note: "LinkedIn rewards 3 to 5 professional, niche tags." },
};

export const CATEGORY_LABEL: Record<Category, string> = {
  travel: "Travel",
  food: "Food",
  fashion: "Fashion",
  fitness: "Fitness",
  beauty: "Beauty",
  business: "Business",
  technology: "Technology",
  lifestyle: "Lifestyle",
};

export const STRATEGY_LABEL: Record<Strategy, { title: string; desc: string }> = {
  balanced: { title: "Balanced", desc: "Even mix of reach, relevance and competition." },
  reach: { title: "Reach", desc: "Larger, more active conversations." },
  niche: { title: "Niche", desc: "Low-competition communities with strong relevance." },
};
