// Sample trend corpus. In production this file is replaced by a trend API
// client that returns the same HashtagRecord[] shape, so no UI code changes.

import type { HashtagRecord, Topic, Platform } from "./types";

export const CORPUS: HashtagRecord[] = [
  // ---- Travel ----------------------------------------------------------------
  { tag: "TokyoFood", category: "travel", secondary: "food", keywords: ["tokyo", "food", "japan", "eat", "eatery"], volume: 412000, competition: "Medium", momentum: 34, momentum7: 18, platforms: ["instagram", "tiktok"], note: "Peaks during dinner hours JST." },
  { tag: "JapanTravel", category: "travel", keywords: ["japan", "travel", "trip", "tokyo", "kyoto"], volume: 1240000, competition: "High", momentum: 21, momentum7: 12, platforms: ["instagram", "youtube"] },
  { tag: "HiddenCafes", category: "travel", secondary: "food", keywords: ["coffee", "cafe", "shop", "hidden", "corner"], volume: 96000, competition: "Low", momentum: 12, momentum7: 7, platforms: ["instagram"] },
  { tag: "JapanFoodGuide", category: "food", secondary: "travel", keywords: ["japan", "food", "guide", "tokyo", "eat"], volume: 128000, competition: "Low", momentum: 28, momentum7: 15, platforms: ["instagram", "tiktok"] },
  { tag: "TokyoEats", category: "food", secondary: "travel", keywords: ["tokyo", "eat", "food", "japan"], volume: 97000, competition: "Low", momentum: 36, momentum7: 20, platforms: ["tiktok", "instagram"] },
  { tag: "CoffeeShopVibes", category: "travel", secondary: "food", keywords: ["coffee", "shop", "cafe", "vibe"], volume: 187000, competition: "Medium", momentum: 19, momentum7: 10, platforms: ["instagram"] },
  { tag: "TravelPhotography", category: "travel", keywords: ["photography", "photo", "shot", "camera", "frame"], volume: 2100000, competition: "High", momentum: 6, momentum7: 3, platforms: ["instagram", "youtube"] },
  { tag: "SoloTravel", category: "travel", keywords: ["solo", "travel", "alone", "trip"], volume: 690000, competition: "High", momentum: 14, momentum7: 8, platforms: ["instagram", "tiktok"] },
  { tag: "TravelItinerary", category: "travel", keywords: ["itinerary", "plan", "days", "guide", "route"], volume: 145000, competition: "Low", momentum: 17, momentum7: 9, platforms: ["instagram", "tiktok"] },
  { tag: "BudgetTravel", category: "travel", keywords: ["budget", "cheap", "affordable", "money", "travel"], volume: 320000, competition: "Medium", momentum: 8, momentum7: 4, platforms: ["youtube", "tiktok"] },
  { tag: "ArchitectureLovers", category: "travel", secondary: "lifestyle", keywords: ["architecture", "building", "design", "concrete"], volume: 530000, competition: "Medium", momentum: 5, momentum7: 2, platforms: ["instagram"] },
  { tag: "UrbanExploring", category: "travel", keywords: ["city", "street", "explore", "walk", "block"], volume: 74000, competition: "Low", momentum: 11, momentum7: 6, platforms: ["instagram"] },
  { tag: "SlowTravel", category: "travel", keywords: ["slow", "travel", "week", "stay", "longer"], volume: 88000, competition: "Low", momentum: 9, momentum7: 5, platforms: ["instagram"] },
  { tag: "CityBreaks", category: "travel", keywords: ["city", "weekend", "break", "trip", "48"], volume: 154000, competition: "Medium", momentum: -4, momentum7: -2, platforms: ["instagram"] },

  // ---- Food ------------------------------------------------------------------
  { tag: "HomeCooking", category: "food", keywords: ["cook", "home", "recipe", "kitchen", "dinner"], volume: 3400000, competition: "High", momentum: 4, momentum7: 2, platforms: ["youtube", "instagram"] },
  { tag: "MealPrepIdeas", category: "food", secondary: "fitness", keywords: ["meal", "prep", "week", "recipe", "lunch"], volume: 480000, competition: "Medium", momentum: 13, momentum7: 7, platforms: ["instagram", "tiktok"] },
  { tag: "CafeHopping", category: "food", secondary: "travel", keywords: ["cafe", "coffee", "hop", "brunch", "pastry"], volume: 233000, competition: "Medium", momentum: 25, momentum7: 14, platforms: ["instagram", "tiktok"] },
  { tag: "RamenGuide", category: "food", secondary: "travel", keywords: ["ramen", "noodle", "japan", "bowl", "broth"], volume: 121000, competition: "Low", momentum: 31, momentum7: 16, platforms: ["tiktok", "instagram"] },
  { tag: "StreetFoodTour", category: "food", secondary: "travel", keywords: ["street", "food", "market", "stall", "tour"], volume: 275000, competition: "Medium", momentum: 18, momentum7: 9, platforms: ["tiktok", "youtube"] },
  { tag: "BakingFromScratch", category: "food", keywords: ["bake", "bread", "sourdough", "dough", "oven"], volume: 164000, competition: "Low", momentum: 7, momentum7: 4, platforms: ["instagram"] },
  { tag: "EasyDinners", category: "food", keywords: ["easy", "dinner", "quick", "weeknight", "minutes"], volume: 720000, competition: "High", momentum: 15, momentum7: 8, platforms: ["instagram", "tiktok"] },
  { tag: "CoffeeBrewing", category: "food", keywords: ["coffee", "brew", "espresso", "beans", "pour"], volume: 143000, competition: "Low", momentum: 10, momentum7: 6, platforms: ["instagram", "youtube"] },
  { tag: "FoodPhotography", category: "food", keywords: ["food", "photo", "styling", "shoot", "plate"], volume: 610000, competition: "Medium", momentum: 6, momentum7: 3, platforms: ["instagram"] },
  { tag: "RecipeOfTheDay", category: "food", keywords: ["recipe", "today", "cook", "make"], volume: 890000, competition: "High", momentum: 9, momentum7: 5, platforms: ["instagram"] },
  { tag: "BrunchIdeas", category: "food", keywords: ["brunch", "weekend", "eggs", "toast", "cafe"], volume: 205000, competition: "Medium", momentum: 12, momentum7: 6, platforms: ["instagram", "tiktok"] },
  { tag: "FarmToTable", category: "food", secondary: "lifestyle", keywords: ["farm", "seasonal", "local", "fresh", "market"], volume: 82000, competition: "Low", momentum: 5, momentum7: 3, platforms: ["instagram"] },

  // ---- Fashion ---------------------------------------------------------------
  { tag: "QuietLuxury", category: "fashion", keywords: ["quiet", "luxury", "minimal", "style", "elegant"], volume: 385000, competition: "Medium", momentum: 26, momentum7: 15, platforms: ["instagram", "tiktok"] },
  { tag: "CapsuleWardrobe", category: "fashion", keywords: ["capsule", "wardrobe", "basics", "autumn", "pieces"], volume: 298000, competition: "Medium", momentum: 19, momentum7: 11, platforms: ["instagram", "youtube"] },
  { tag: "AutumnLayering", category: "fashion", keywords: ["autumn", "layer", "fall", "coat", "knit"], volume: 96000, competition: "Low", momentum: 34, momentum7: 19, platforms: ["instagram", "tiktok"], note: "Seasonal lift, northern hemisphere." },
  { tag: "OutfitIdeas", category: "fashion", keywords: ["outfit", "idea", "wear", "style", "combine"], volume: 1900000, competition: "High", momentum: 8, momentum7: 4, platforms: ["instagram"] },
  { tag: "ThriftFinds", category: "fashion", keywords: ["thrift", "vintage", "secondhand", "haul", "used"], volume: 410000, competition: "Medium", momentum: 23, momentum7: 13, platforms: ["tiktok", "instagram"] },
  { tag: "StreetStyle", category: "fashion", keywords: ["street", "style", "city", "outfit", "walk"], volume: 860000, competition: "High", momentum: 5, momentum7: 2, platforms: ["instagram"] },
  { tag: "SlowFashion", category: "fashion", secondary: "lifestyle", keywords: ["slow", "sustainable", "ethical", "made", "quality"], volume: 128000, competition: "Low", momentum: 11, momentum7: 6, platforms: ["instagram"] },
  { tag: "WorkwearStyle", category: "fashion", keywords: ["work", "office", "blazer", "tailored", "suit"], volume: 74000, competition: "Low", momentum: 16, momentum7: 9, platforms: ["instagram"] },
  { tag: "DenimOnDenim", category: "fashion", keywords: ["denim", "jeans", "jacket", "double"], volume: 152000, competition: "Medium", momentum: 21, momentum7: 12, platforms: ["tiktok", "instagram"] },
  { tag: "StyleOnABudget", category: "fashion", secondary: "lifestyle", keywords: ["budget", "affordable", "style", "cheap", "price"], volume: 187000, competition: "Medium", momentum: 14, momentum7: 8, platforms: ["tiktok"] },
  { tag: "OOTDInspo", category: "fashion", keywords: ["ootd", "outfit", "today", "inspo", "wearing"], volume: 1150000, competition: "High", momentum: 7, momentum7: 3, platforms: ["instagram"] },
  { tag: "FitCheck", category: "fashion", keywords: ["fit", "check", "outfit", "look"], volume: 640000, competition: "Medium", momentum: 17, momentum7: 10, platforms: ["tiktok"] },

  // ---- Fitness ---------------------------------------------------------------
  { tag: "PushDayWorkout", category: "fitness", keywords: ["push", "day", "split", "lift", "chest"], volume: 132000, competition: "Low", momentum: 24, momentum7: 13, platforms: ["tiktok", "youtube"] },
  { tag: "ProgressiveOverload", category: "fitness", keywords: ["progressive", "overload", "strength", "gains", "numbers"], volume: 88000, competition: "Low", momentum: 15, momentum7: 8, platforms: ["youtube", "instagram"] },
  { tag: "HomeGymSetup", category: "fitness", secondary: "lifestyle", keywords: ["home", "gym", "setup", "equipment", "rack"], volume: 176000, competition: "Medium", momentum: 9, momentum7: 5, platforms: ["instagram", "youtube"] },
  { tag: "RunningCommunity", category: "fitness", keywords: ["running", "run", "5k", "marathon", "miles"], volume: 540000, competition: "Medium", momentum: 12, momentum7: 7, platforms: ["instagram"] },
  { tag: "MobilityWork", category: "fitness", keywords: ["mobility", "stretch", "hips", "recovery", "range"], volume: 96000, competition: "Low", momentum: 18, momentum7: 10, platforms: ["youtube", "instagram"] },
  { tag: "StrengthTraining", category: "fitness", keywords: ["strength", "train", "lift", "barbell", "squat"], volume: 890000, competition: "High", momentum: 6, momentum7: 3, platforms: ["instagram", "youtube"] },
  { tag: "GymProgress", category: "fitness", keywords: ["gym", "progress", "months", "gains", "consistent"], volume: 245000, competition: "Medium", momentum: 20, momentum7: 11, platforms: ["tiktok", "instagram"] },
  { tag: "MarathonTraining", category: "fitness", keywords: ["marathon", "training", "race", "plan", "block"], volume: 187000, competition: "Medium", momentum: 14, momentum7: 8, platforms: ["instagram", "youtube"] },
  { tag: "HighProteinMeals", category: "fitness", secondary: "food", keywords: ["protein", "meals", "recipe", "gym", "grams"], volume: 310000, competition: "Medium", momentum: 22, momentum7: 12, platforms: ["tiktok", "instagram"] },
  { tag: "FitnessJourney", category: "fitness", keywords: ["fitness", "journey", "transformation", "start"], volume: 1600000, competition: "High", momentum: 3, momentum7: 1, platforms: ["instagram"] },
  { tag: "RecoveryDay", category: "fitness", keywords: ["recovery", "rest", "sleep", "sore", "off"], volume: 54000, competition: "Low", momentum: 8, momentum7: 4, platforms: ["instagram"] },
  { tag: "FormCheck", category: "fitness", keywords: ["form", "lift", "technique", "cue"], volume: 62000, competition: "Low", momentum: 11, momentum7: 6, platforms: ["tiktok", "youtube"] },

  // ---- Beauty ----------------------------------------------------------------
  { tag: "GlassSkinRoutine", category: "beauty", keywords: ["glass", "skin", "routine", "skincare", "glow"], volume: 265000, competition: "Medium", momentum: 29, momentum7: 16, platforms: ["tiktok", "instagram"] },
  { tag: "BarrierRepair", category: "beauty", keywords: ["barrier", "repair", "skin", "sensitive", "ceramides"], volume: 76000, competition: "Low", momentum: 33, momentum7: 18, platforms: ["tiktok", "instagram"] },
  { tag: "SkincareBasics", category: "beauty", keywords: ["skincare", "routine", "cleanse", "basics", "steps"], volume: 720000, competition: "High", momentum: 7, momentum7: 4, platforms: ["instagram"] },
  { tag: "CleanBeauty", category: "beauty", secondary: "lifestyle", keywords: ["clean", "beauty", "ingredients", "formula"], volume: 143000, competition: "Low", momentum: 10, momentum7: 5, platforms: ["instagram"] },
  { tag: "DrugstoreFinds", category: "beauty", secondary: "fashion", keywords: ["drugstore", "affordable", "makeup", "find", "pharmacy"], volume: 198000, competition: "Medium", momentum: 21, momentum7: 12, platforms: ["tiktok"] },
  { tag: "MakeupLooks", category: "beauty", keywords: ["makeup", "look", "eye", "glam", "brush"], volume: 1300000, competition: "High", momentum: 5, momentum7: 2, platforms: ["instagram", "tiktok"] },
  { tag: "HairCareRoutine", category: "beauty", keywords: ["hair", "care", "routine", "wash", "curls"], volume: 460000, competition: "Medium", momentum: 13, momentum7: 7, platforms: ["instagram", "tiktok"] },
  { tag: "NoMakeupLook", category: "beauty", keywords: ["no", "makeup", "natural", "skin", "bare"], volume: 340000, competition: "Medium", momentum: 16, momentum7: 9, platforms: ["instagram"] },
  { tag: "BeautyOnBudget", category: "beauty", keywords: ["budget", "beauty", "affordable", "dupe"], volume: 120000, competition: "Low", momentum: 12, momentum7: 6, platforms: ["tiktok"] },
  { tag: "SPFEveryday", category: "beauty", keywords: ["spf", "sunscreen", "protection", "uv"], volume: 88000, competition: "Low", momentum: 19, momentum7: 11, platforms: ["instagram"] },
  { tag: "FragranceLayering", category: "beauty", secondary: "lifestyle", keywords: ["fragrance", "perfume", "layer", "scent", "notes"], volume: 102000, competition: "Low", momentum: 27, momentum7: 15, platforms: ["tiktok", "instagram"] },

  // ---- Business --------------------------------------------------------------
  { tag: "SmallBusinessStory", category: "business", keywords: ["small", "business", "studio", "story", "shop"], volume: 210000, competition: "Medium", momentum: 15, momentum7: 8, platforms: ["instagram", "linkedin"] },
  { tag: "FounderDiary", category: "business", keywords: ["founder", "startup", "building", "diary", "shipping"], volume: 96000, competition: "Low", momentum: 22, momentum7: 12, platforms: ["linkedin", "tiktok"] },
  { tag: "EcommerceTips", category: "business", keywords: ["ecommerce", "shop", "store", "sales", "conversion"], volume: 175000, competition: "Medium", momentum: 11, momentum7: 6, platforms: ["linkedin", "instagram"] },
  { tag: "HandmadeBusiness", category: "business", secondary: "lifestyle", keywords: ["handmade", "ceramics", "craft", "maker", "glaze"], volume: 84000, competition: "Low", momentum: 18, momentum7: 10, platforms: ["instagram"] },
  { tag: "MarketingTips", category: "business", keywords: ["marketing", "brand", "audience", "growth", " funnel"], volume: 640000, competition: "High", momentum: 8, momentum7: 4, platforms: ["linkedin"] },
  { tag: "SoloFounder", category: "business", keywords: ["solo", "founder", "bootstrapped", "own"], volume: 58000, competition: "Low", momentum: 16, momentum7: 9, platforms: ["linkedin", "tiktok"] },
  { tag: "ClientWork", category: "business", keywords: ["client", "freelance", "project", "brief", "invoice"], volume: 72000, competition: "Low", momentum: 9, momentum7: 5, platforms: ["linkedin", "instagram"] },
  { tag: "StudioProcess", category: "business", secondary: "lifestyle", keywords: ["studio", "process", "making", "workshop", "batch"], volume: 46000, competition: "Low", momentum: 14, momentum7: 8, platforms: ["instagram"] },
  { tag: "PersonalBranding", category: "business", keywords: ["personal", "brand", "linkedin", "voice", "position"], volume: 380000, competition: "Medium", momentum: 19, momentum7: 10, platforms: ["linkedin"] },
  { tag: "SideHustleIdeas", category: "business", keywords: ["side", "hustle", "income", "extra", "weekends"], volume: 920000, competition: "High", momentum: 12, momentum7: 6, platforms: ["tiktok", "youtube"] },
  { tag: "PricingYourWork", category: "business", keywords: ["pricing", "price", "charge", "work", "rates"], volume: 38000, competition: "Low", momentum: 21, momentum7: 12, platforms: ["instagram", "linkedin"] },
  { tag: "FirstLaunch", category: "business", secondary: "technology", keywords: ["launch", "first", "ship", "product", "shipped"], volume: 66000, competition: "Low", momentum: 25, momentum7: 14, platforms: ["linkedin", "tiktok"] },

  // ---- Technology ------------------------------------------------------------
  { tag: "AIToolsDaily", category: "technology", keywords: ["ai", "tool", "workflow", "daily", "automate"], volume: 740000, competition: "High", momentum: 41, momentum7: 24, platforms: ["tiktok", "linkedin"], note: "Fastest riser in the tech cluster this week." },
  { tag: "NotionTemplates", category: "technology", secondary: "lifestyle", keywords: ["notion", "template", "system", "organize", "track"], volume: 320000, competition: "Medium", momentum: 17, momentum7: 9, platforms: ["tiktok", "instagram"] },
  { tag: "DeskSetupTour", category: "technology", secondary: "lifestyle", keywords: ["desk", "setup", "workspace", "gear", "monitor"], volume: 285000, competition: "Medium", momentum: 13, momentum7: 7, platforms: ["youtube", "instagram"] },
  { tag: "CodingJourney", category: "technology", keywords: ["code", "learn", "developer", "journey", "bootcamp"], volume: 410000, competition: "Medium", momentum: 8, momentum7: 4, platforms: ["tiktok", "youtube"] },
  { tag: "TechReview", category: "technology", keywords: ["review", "gadget", "phone", "laptop", "tested"], volume: 980000, competition: "High", momentum: 5, momentum7: 2, platforms: ["youtube"] },
  { tag: "ProductivitySystems", category: "technology", secondary: "business", keywords: ["productivity", "system", "focus", "deep", "work"], volume: 190000, competition: "Medium", momentum: 15, momentum7: 8, platforms: ["linkedin", "instagram"] },
  { tag: "AppLaunch", category: "technology", secondary: "business", keywords: ["app", "launch", "build", "ship", "beta"], volume: 120000, competition: "Low", momentum: 20, momentum7: 11, platforms: ["linkedin", "tiktok"] },
  { tag: "SmartHomeSetup", category: "technology", keywords: ["smart", "home", "automation", "lights", "sensor"], volume: 230000, competition: "Medium", momentum: 10, momentum7: 5, platforms: ["youtube", "instagram"] },
  { tag: "GearTalk", category: "technology", secondary: "travel", keywords: ["camera", "gear", "lens", "kit", "carry"], volume: 155000, competition: "Low", momentum: 9, momentum7: 5, platforms: ["youtube"] },
  { tag: "AutomationIdeas", category: "technology", secondary: "business", keywords: ["automation", "workflow", "bot", "integrate", "no-code"], volume: 98000, competition: "Low", momentum: 23, momentum7: 13, platforms: ["linkedin"] },
  { tag: "DayInTech", category: "technology", keywords: ["day", "life", "tech", "engineer", "office"], volume: 260000, competition: "Medium", momentum: 18, momentum7: 10, platforms: ["tiktok"] },

  // ---- Lifestyle ---------------------------------------------------------------
  { tag: "SlowLiving", category: "lifestyle", keywords: ["slow", "living", "simple", "calm", "quiet"], volume: 380000, competition: "Medium", momentum: 24, momentum7: 14, platforms: ["instagram"] },
  { tag: "MorningRituals", category: "lifestyle", keywords: ["morning", "ritual", "routine", "coffee", "early"], volume: 305000, competition: "Medium", momentum: 16, momentum7: 9, platforms: ["instagram", "tiktok"] },
  { tag: "ApartmentDecor", category: "lifestyle", keywords: ["apartment", "decor", "small", "space", "room"], volume: 520000, competition: "Medium", momentum: 11, momentum7: 6, platforms: ["instagram"] },
  { tag: "JournalingPractice", category: "lifestyle", keywords: ["journal", "notebook", "writing", "daily", "pages"], volume: 140000, competition: "Low", momentum: 19, momentum7: 11, platforms: ["instagram"] },
  { tag: "WeekendReset", category: "lifestyle", keywords: ["weekend", "reset", "clean", "plan", "refresh"], volume: 87000, competition: "Low", momentum: 28, momentum7: 16, platforms: ["tiktok", "instagram"] },
  { tag: "DigitalDetox", category: "lifestyle", keywords: ["digital", "detox", "phone", "offline", "screen"], volume: 110000, competition: "Low", momentum: 21, momentum7: 12, platforms: ["instagram", "tiktok"] },
  { tag: "ReadingList", category: "lifestyle", keywords: ["book", "read", "reading", "shelf", "pages"], volume: 610000, competition: "Medium", momentum: 9, momentum7: 5, platforms: ["instagram"] },
  { tag: "PlantCorner", category: "lifestyle", keywords: ["plant", "plants", "monstera", "corner", "leaf"], volume: 195000, competition: "Low", momentum: 7, momentum7: 4, platforms: ["instagram"] },
  { tag: "MoneyHabits", category: "lifestyle", secondary: "business", keywords: ["money", "budget", "save", "habits", "spend"], volume: 440000, competition: "Medium", momentum: 17, momentum7: 9, platforms: ["tiktok", "instagram"] },
  { tag: "SundayReset", category: "lifestyle", keywords: ["sunday", "reset", "week", "prep", "plan"], volume: 260000, competition: "Medium", momentum: 31, momentum7: 18, platforms: ["tiktok", "instagram"] },
  { tag: "CozySeason", category: "lifestyle", secondary: "fashion", keywords: ["cozy", "autumn", "candle", "season", "sweater"], volume: 340000, competition: "Medium", momentum: 37, momentum7: 22, platforms: ["instagram", "tiktok"], note: "Strong seasonal lift in US and UK." },
  { tag: "MinimalHome", category: "lifestyle", keywords: ["minimal", "home", "declutter", "less", "space"], volume: 230000, competition: "Medium", momentum: 8, momentum7: 4, platforms: ["instagram", "youtube"] },
];

// Caption keywords used for category detection (stronger signal words first).
export const CATEGORY_KEYWORDS: Record<string, string[]> = {
  travel: ["travel", "trip", "flight", "landed", "city", "hotel", "airport", "tokyo", "japan", "kyoto", "street", "explore", "walk", "itinerary", "abroad", "train"],
  food: ["food", "eat", "recipe", "cook", "coffee", "cafe", "dinner", "lunch", "brunch", "ramen", "bake", "bread", "meal", "kitchen", "taste", "menu"],
  fashion: ["outfit", "wear", "style", "wardrobe", "denim", "vintage", "thrift", "coat", "knit", "autumn", "clothes", "fashion", "ootd", "tailored"],
  fitness: ["gym", "lift", "workout", "training", "run", "running", "reps", "strength", "mobility", "recovery", "protein", "marathon", "split", "set"],
  beauty: ["skin", "skincare", "makeup", "glow", "routine", "hair", "spf", "perfume", "fragrance", "beauty", "serum", "barrier"],
  business: ["studio", "business", "client", "launch", "founder", "ship", "shipped", "product", "brand", "sales", "pricing", "order", "market", "batch", "wholesale"],
  technology: ["ai", "app", "tool", "desk", "setup", "code", "automation", "notion", "tech", "software", "camera", "gear", "laptop"],
  lifestyle: ["morning", "weekend", "sunday", "slow", "cozy", "journal", "plants", "home", "apartment", "books", "reading", "reset", "quiet", "habits", "declutter"],
};

// Rising conversational topics for the Trends page.
export const TOPICS: Topic[] = [
  { label: "Hidden coffee shop crawls", momentum: 22, category: "travel", relatedTag: "HiddenCafes" },
  { label: "Autumn capsule wardrobes", momentum: 19, category: "fashion", relatedTag: "CapsuleWardrobe" },
  { label: "Sunday reset routines", momentum: 31, category: "lifestyle", relatedTag: "SundayReset" },
  { label: "Barrier repair skincare", momentum: 33, category: "beauty", relatedTag: "BarrierRepair" },
  { label: "Small batch ceramics", momentum: 18, category: "business", relatedTag: "HandmadeBusiness" },
  { label: "AI workflow tools", momentum: 41, category: "technology", relatedTag: "AIToolsDaily" },
  { label: "Run club culture", momentum: 12, category: "fitness", relatedTag: "RunningCommunity" },
  { label: "Quiet luxury on a budget", momentum: 14, category: "fashion", relatedTag: "StyleOnABudget" },
  { label: "Cozy season evenings", momentum: 37, category: "lifestyle", relatedTag: "CozySeason" },
  { label: "Desk setup refresh", momentum: 13, category: "technology", relatedTag: "DeskSetupTour" },
  { label: "Tokyo food alleys", momentum: 36, category: "food", relatedTag: "TokyoEats" },
  { label: "Slow weekend travel", momentum: 9, category: "travel", relatedTag: "SlowTravel" },
];

// Realistic starter captions for the composer.
export const SAMPLES: { label: string; caption: string }[] = [
  {
    label: "Tokyo trip",
    caption:
      "Just landed in Tokyo. The food, architecture and tiny coffee shops completely surprised me.",
  },
  {
    label: "Push day",
    caption:
      "Five months of consistent lifting and the numbers finally moved. Here is the exact push day split I used, down to the rest times.",
  },
  {
    label: "Studio launch",
    caption:
      "Our small studio just shipped its first collection. Handmade ceramics, hand-glazed, made in batches of twenty. Every order leaves the workshop by Friday.",
  },
  {
    label: "Autumn capsule",
    caption:
      "Quiet luxury on a real budget: the full autumn capsule I actually wear every week, styled three ways from the same six pieces.",
  },
];

export function tagByTag(tag: string): HashtagRecord | undefined {
  return CORPUS.find((r) => r.tag === tag);
}

export const ALL_PLATFORMS: Platform[] = ["instagram", "tiktok", "youtube", "linkedin"];
