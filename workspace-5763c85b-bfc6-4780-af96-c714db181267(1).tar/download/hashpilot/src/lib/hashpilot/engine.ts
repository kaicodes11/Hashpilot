// Analysis engine: turns a caption + platform + strategy into a ranked,
// explained hashtag list. Deterministic for a given input + seed so results
// can be replayed from history. Swap points for a live API are documented
// in types.ts.

import { CORPUS, CATEGORY_KEYWORDS, TOPICS } from "./corpus";
import type {
  AnalyzeInput,
  Analysis,
  Category,
  Competition,
  Demand,
  HashtagRecord,
  Platform,
  RankedTag,
  Status,
  Strategy,
  TrendSort,
  ReachEstimate,
} from "./types";

// ---------- deterministic randomness ----------

export function hashSeed(str: string): number {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) >>> 0;
  return h >>> 0;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------- text processing ----------

const STOP = new Set([
  "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with",
  "my", "our", "your", "i", "we", "you", "it", "is", "was", "are", "were", "be",
  "been", "just", "here", "this", "that", "these", "those", "from", "by", "as",
  "so", "not", "no", "yes", "how", "what", "when", "why", "me", "us", "them",
  "its", "it's", "i'm", "we're", "don't", "didn't", "can't", "won't", "about",
  "into", "over", "under", "up", "down", "out", "off", "again", "then", "than",
  "very", "really", "some", "any", "every", "each", "all", "more", "most", "get",
  "got", "have", "has", "had", "do", "does", "did", "will", "would", "could",
  "should", "completely", "totally", "finally", "actually", "literally",
]);

export function tokenize(caption: string): string[] {
  return caption
    .toLowerCase()
    .replace(/[^a-z0-9\s'-]/g, " ")
    .split(/\s+/)
    .map((t) => t.replace(/^['-]+|['-]+$/g, ""))
    .filter((t) => t.length > 1 && !STOP.has(t));
}

function stem(token: string): string {
  if (token.endsWith("ies") && token.length > 4) return token.slice(0, -3) + "y";
  if (token.endsWith("es") && token.length > 3) return token.slice(0, -2);
  if (token.endsWith("s") && !token.endsWith("ss") && token.length > 2) return token.slice(0, -1);
  return token;
}

function matchKeyword(token: string, keyword: string): "strong" | "partial" | null {
  const t = stem(token);
  const k = stem(keyword.toLowerCase());
  if (t === k) return "strong";
  if (t.startsWith(k) || k.startsWith(t)) {
    if (Math.min(t.length, k.length) >= 3) return "partial";
  }
  return null;
}

// ---------- formatting ----------

export function fmtCount(n: number): string {
  if (n >= 1000000) {
    const m = n / 1000000;
    return (m >= 10 ? Math.round(m) : Math.round(m * 10) / 10) + "M";
  }
  if (n >= 1000) return Math.round(n / 1000) + "K";
  return String(n);
}

export function fmtImpressions(n: number): string {
  if (n >= 1000000) return (Math.round((n / 1000000) * 10) / 10) + "M";
  if (n >= 1000) return Math.round(n / 1000) + "K";
  return String(n);
}

// ---------- derived metrics ----------

export function demandFor(volume: number): Demand {
  if (volume >= 1000000) return "Very high";
  if (volume >= 400000) return "High";
  if (volume >= 100000) return "Medium";
  return "Low";
}

export function statusFor(momentum: number): Status {
  if (momentum >= 15) return "Rising";
  if (momentum <= -3) return "Falling";
  return "Stable";
}

export function reachFor(rec: HashtagRecord): ReachEstimate {
  const factor = 0.04 + Math.max(rec.momentum, 0) / 300;
  const low = rec.volume * factor * 0.7;
  const high = rec.volume * factor * 1.6;
  const mid = (low + high) / 2;
  const label =
    mid >= 250000 ? "Very large" : mid >= 80000 ? "Large" : mid >= 20000 ? "Solid" : "Compact";
  return { label, low: Math.round(low), high: Math.round(high) };
}

const AUDIENCE_FIT: Record<Category, string> = {
  travel: "Strong with 25 to 34 city-break and trip-planning audiences",
  food: "Core food audience, high save rates on recipes and guides",
  fashion: "Fashion-first followers, strong outfit-save behavior",
  fitness: "Gym and running communities with high comment rates",
  beauty: "Skincare-focused viewers with high watch-through",
  business: "Founders, freelancers and marketers, active on weekdays",
  technology: "Tool hunters and early adopters, strong shares",
  lifestyle: "Broad lifestyle reach with steady evergreen interest",
};

export function audienceFitFor(rec: HashtagRecord, platform: Platform): string {
  const base = AUDIENCE_FIT[rec.category];
  const p: Partial<Record<Platform, string>> = {
    instagram: ", tuned to saves and story shares",
    tiktok: ", tuned to watch-through and sound reuse",
    youtube: ", tuned to search browse and chaptered viewing",
    linkedin: ", tuned to professional reach and reshares",
  };
  return base + (p[platform] ?? "");
}

// 14-point sparkline ending near current momentum. Deterministic.
export function sparkFor(rec: HashtagRecord): number[] {
  const rng = mulberry32(hashSeed(rec.tag));
  const drift = rec.momentum7;
  const shape = drift >= 12 ? 1 : drift <= -3 ? -1 : 0;
  const base = 46 + shape * 6;
  const pts: number[] = [];
  for (let i = 0; i < 14; i++) {
    const progress = i / 13;
    const trend = base + shape * 18 * progress + (rng() - 0.5) * 7;
    pts.push(Math.max(6, Math.min(98, trend)));
  }
  pts[13] = Math.max(pts[13], base + shape * 12);
  return pts.map((v) => Math.round(v));
}

// ---------- category detection ----------

export function detectCategories(tokens: string[]): Category[] {
  const scores = new Map<Category, number>();
  for (const [cat, kws] of Object.entries(CATEGORY_KEYWORDS)) {
    let s = 0;
    for (const t of tokens) {
      for (const kw of kws) {
        const m = matchKeyword(t, kw);
        if (m === "strong") s += 2;
        else if (m === "partial") s += 1;
      }
    }
    if (s > 0) scores.set(cat as Category, s);
  }
  const ranked = [...scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, 2);
  return ranked.filter(([, s]) => s >= 2).map(([c]) => c);
}

export function detectSignals(tokens: string[]): string[] {
  const signalSet = new Set<string>();
  for (const kws of Object.values(CATEGORY_KEYWORDS)) {
    for (const t of tokens) {
      for (const kw of kws) {
        if (matchKeyword(t, kw) === "strong") {
          signalSet.add(kw);
          break;
        }
      }
    }
  }
  return [...signalSet].slice(0, 6);
}

// ---------- scoring ----------

interface Weights {
  relevance: number;
  momentum: number;
  reach: number;
  lowComp: number;
}

const STRATEGY_WEIGHTS: Record<Strategy, Weights> = {
  balanced: { relevance: 0.42, momentum: 0.28, reach: 0.15, lowComp: 0.15 },
  reach: { relevance: 0.22, momentum: 0.25, reach: 0.4, lowComp: 0.13 },
  niche: { relevance: 0.45, momentum: 0.12, reach: 0.08, lowComp: 0.35 },
};

const COMP_INDEX: Record<Competition, number> = { Low: 20, Medium: 55, High: 85 };

function relevanceFor(
  rec: HashtagRecord,
  tokens: string[],
  categories: Category[],
  platform: Platform
): { relevance: number; matched: string[] } {
  let strong = 0;
  let partial = 0;
  const matched: string[] = [];
  for (const kw of rec.keywords) {
    let best: "strong" | "partial" | null = null;
    for (const t of tokens) {
      const m = matchKeyword(t, kw);
      if (m === "strong") { best = "strong"; break; }
      if (m === "partial" && !best) best = "partial";
    }
    if (best === "strong") { strong++; matched.push(kw); }
    else if (best === "partial") { partial++; matched.push(kw); }
  }
  const catMatch = categories.includes(rec.category) || (rec.secondary && categories.includes(rec.secondary));
  let rel = 34 + Math.min(40, strong * 20) + Math.min(12, partial * 8);
  if (catMatch) rel += 22;
  if (rec.platforms.includes(platform)) rel += 4;
  if (strong >= 2) rel += 6;
  return { relevance: Math.max(20, Math.min(98, rel)), matched };
}

function momentumNorm(m: number): number {
  return Math.max(0, Math.min(100, ((m + 25) / 70) * 100));
}

function reachNorm(volume: number): number {
  return Math.min(100, (Math.log10(Math.max(volume, 1000)) / Math.log10(5000000)) * 100);
}

function whyFor(
  rec: HashtagRecord,
  matched: string[],
  catMatch: boolean,
  status: Status,
  relevance: number
): string {
  const parts: string[] = [];
  if (matched.length >= 2) {
    parts.push(`Direct match for the ${matched[0]} + ${matched[1]} combination in your caption.`);
  } else if (matched.length === 1) {
    parts.push(`Connects to "${matched[0]}" from your caption.`);
  } else if (catMatch) {
    parts.push(`Fits the ${rec.category === "food" ? "food" : rec.category} focus of your post.`);
  } else {
    parts.push(`Adjacent to your topic through the ${rec.category} conversation.`);
  }
  if (status === "Rising") {
    parts.push(
      `Activity is up ${rec.momentum}% in the last 24 hours${
        rec.competition === "Low"
          ? " and competition is low enough to rank"
          : rec.competition === "Medium"
            ? ", with moderate competition"
            : ", though competition is heavy"
      }.`
    );
  } else if (status === "Stable") {
    parts.push(
      `Search demand is steady week over week${
        rec.competition === "Low" ? ", and smaller accounts still rank here" : "."
      }`
    );
  } else {
    parts.push(
      `Interest cooled ${Math.abs(rec.momentum)}% recently, so treat it as a labeling tag rather than a reach driver.`
    );
  }
  if (relevance >= 85) parts.push("Content relevance is among the highest available for this post.");
  return parts.join(" ");
}

function reasonFor(
  rec: HashtagRecord,
  matched: string[],
  catMatch: boolean,
  status: Status,
  rng: () => number
): string {
  const a = matched[0];
  const b = matched[1];
  if (matched.length >= 2) {
    const opts = [
      `Strong match for the ${a} + ${b} combination, with rising activity over the last 24 hours.`,
      `Picked up both "${a}" and "${b}" from your caption and momentum is climbing.`,
      `Hits the ${a} + ${b} overlap your post sits in right now.`,
    ];
    return status === "Falling" ? opts[2] : opts[Math.floor(rng() * opts.length)];
  }
  if (matched.length === 1) {
    const opts = [
      `Ties directly to "${a}" in your post with ${rec.competition.toLowerCase()} competition.`,
      `Built around "${a}", which your audience actively searches.`,
    ];
    return opts[Math.floor(rng() * opts.length)];
  }
  if (catMatch) {
    const opts = [
      `Reliable ${rec.category} community tag with ${rec.competition.toLowerCase()} competition.`,
      `Keeps your post inside the ${rec.category} conversation where it belongs.`,
      `Standard ${rec.category} coverage; helps grouping more than reach.`,
    ];
    return opts[Math.floor(rng() * opts.length)];
  }
  return `Broad ${rec.category} tag that widens discovery beyond your core topic.`;
}

function scoreFor(
  rec: HashtagRecord,
  relevance: number,
  strategy: Strategy
): number {
  const w = STRATEGY_WEIGHTS[strategy];
  const raw =
    w.relevance * relevance +
    w.momentum * momentumNorm(rec.momentum) +
    w.reach * reachNorm(rec.volume) +
    w.lowComp * (100 - COMP_INDEX[rec.competition]);
  const bonus = relevance >= 85 ? 8 : relevance >= 70 ? 4 : 0;
  return Math.max(40, Math.min(98, Math.round(raw + bonus)));
}

// ---------- main entry ----------

export function analyze(input: AnalyzeInput): Analysis {
  const tokens = tokenize(input.caption);
  const detected = detectCategories(tokens);
  const categories = input.categories.length ? input.categories : detected;
  const seedBase = hashSeed(
    input.caption + input.platform + input.strategy + categories.join(",") + (input.seed ?? 0)
  );
  const rng = mulberry32(seedBase);

  const candidates: { rec: HashtagRecord; relevance: number; matched: string[] }[] = [];
  for (const rec of CORPUS) {
    const { relevance, matched } = relevanceFor(rec, tokens, categories, input.platform);
    if (relevance >= 48) candidates.push({ rec, relevance, matched });
  }
  // Small deterministic jitter breaks ties so strategies reshuffle visibly.
  for (const c of candidates) c.relevance += (rng() - 0.5) * 2;

  candidates.sort((a, b) => {
    const sa = scoreFor(a.rec, a.relevance, input.strategy);
    const sb = scoreFor(b.rec, b.relevance, input.strategy);
    if (sb !== sa) return sb - sa;
    return b.relevance - a.relevance;
  });

  const platformTarget: Record<Platform, number> = {
    instagram: 15,
    tiktok: 9,
    youtube: 7,
    linkedin: 7,
  };
  const top = candidates.slice(0, platformTarget[input.platform]);

  const tags: RankedTag[] = top.map(({ rec, relevance, matched }) => {
    const status = statusFor(rec.momentum);
    const cleanMatched = matched.slice(0, 2);
    return {
      tag: rec.tag,
      score: scoreFor(rec, relevance, input.strategy),
      relevance: Math.round(relevance),
      momentum: rec.momentum,
      momentum7: rec.momentum7,
      competition: rec.competition,
      demand: demandFor(rec.volume),
      status,
      reach: reachFor(rec),
      audienceFit: audienceFitFor(rec, input.platform),
      reason: reasonFor(rec, cleanMatched, categories.includes(rec.category), status, rng),
      why: whyFor(rec, cleanMatched, categories.includes(rec.category), status, relevance),
      spark: sparkFor(rec),
      category: rec.category,
      secondary: rec.secondary,
      volume: rec.volume,
      matched: cleanMatched,
    };
  });

  const stats = {
    average: tags.length ? Math.round(tags.reduce((s, t) => s + t.score, 0) / tags.length) : 0,
    rising: tags.filter((t) => t.status === "Rising").length,
    stable: tags.filter((t) => t.status === "Stable").length,
    falling: tags.filter((t) => t.status === "Falling").length,
  };

  return {
    id: `a-${seedBase.toString(36)}`,
    createdAt: 0, // stamped by the caller
    input: { ...input, categories },
    detected,
    signals: detectSignals(tokens),
    tags,
    stats,
  };
}

// Find a replacement candidate for one row: same primary category when
// possible, not already in the list, next best available.
export function replacementFor(
  input: AnalyzeInput,
  exclude: string[],
  preferCategory: Category
): RankedTag | null {
  const tokens = tokenize(input.caption);
  const categories = input.categories.length ? input.categories : detectCategories(tokens);
  const pool: { rec: HashtagRecord; relevance: number }[] = [];
  for (const rec of CORPUS) {
    if (exclude.includes(rec.tag)) continue;
    const { relevance } = relevanceFor(rec, tokens, categories, input.platform);
    if (relevance < 40) continue;
    pool.push({ rec, relevance });
  }
  pool.sort((a, b) => scoreFor(b.rec, b.relevance, input.strategy) - scoreFor(a.rec, a.relevance, input.strategy));
  const sameCat = pool.find((p) => p.rec.category === preferCategory || p.rec.secondary === preferCategory);
  const pick = sameCat ?? pool[0];
  if (!pick) return null;
  const { rec, relevance } = pick;
  const rng = mulberry32(hashSeed(rec.tag + exclude.length));
  const status = statusFor(rec.momentum);
  const matched = relevanceFor(rec, tokens, categories, input.platform).matched.slice(0, 2);
  return {
    tag: rec.tag,
    score: scoreFor(rec, relevance, input.strategy),
    relevance: Math.round(relevance),
    momentum: rec.momentum,
    momentum7: rec.momentum7,
    competition: rec.competition,
    demand: demandFor(rec.volume),
    status,
    reach: reachFor(rec),
    audienceFit: audienceFitFor(rec, input.platform),
    reason: reasonFor(rec, matched, categories.includes(rec.category), status, rng),
    why: whyFor(rec, matched, categories.includes(rec.category), status, relevance),
    spark: sparkFor(rec),
    category: rec.category,
    secondary: rec.secondary,
    volume: rec.volume,
    matched,
  };
}

// Alternate mix for Regenerate: keep the three strongest anchors, rotate the
// rest of the list with the next tier of candidates.
export function regenerateTags(
  input: AnalyzeInput,
  current: RankedTag[]
): RankedTag[] {
  const nextSeed = (input.seed ?? 0) + 1;
  const fresh = analyze({ ...input, seed: nextSeed });
  const anchors = [...current]
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .filter((a) => fresh.tags.some((t) => t.tag === a.tag));
  const keep = new Set(anchors.map((a) => a.tag));
  const rest = fresh.tags.filter((t) => !keep.has(t.tag));
  return [...anchors, ...rest].slice(0, current.length || fresh.tags.length);
}

// ---------- trends page ----------

export interface TrendRow {
  rec: HashtagRecord;
  score: number;
  status: Status;
  demand: Demand;
  reach: ReachEstimate;
  spark: number[];
}

export function getTrending(opts: {
  platform?: Platform | "all";
  category?: Category | "all";
  sort: TrendSort;
}): TrendRow[] {
  const rows: TrendRow[] = CORPUS.filter((rec) => {
    if (opts.category && opts.category !== "all" && rec.category !== opts.category && rec.secondary !== opts.category) return false;
    if (opts.platform && opts.platform !== "all" && !rec.platforms.includes(opts.platform)) return false;
    return true;
  }).map((rec) => {
    const balanced = STRATEGY_WEIGHTS.balanced;
    const relProxy = 62; // trends page has no caption; use a neutral relevance
    const raw =
      balanced.relevance * relProxy +
      balanced.momentum * momentumNorm(rec.momentum) +
      balanced.reach * reachNorm(rec.volume) +
      balanced.lowComp * (100 - COMP_INDEX[rec.competition]);
    return {
      rec,
      score: Math.max(40, Math.min(98, Math.round(raw))),
      status: statusFor(rec.momentum),
      demand: demandFor(rec.volume),
      reach: reachFor(rec),
      spark: sparkFor(rec),
    };
  });

  switch (opts.sort) {
    case "fastest":
      rows.sort((a, b) => b.rec.momentum - a.rec.momentum);
      break;
    case "reach":
      rows.sort((a, b) => b.rec.volume - a.rec.volume);
      break;
    case "competition":
      rows.sort((a, b) => {
        const ca = COMP_INDEX[a.rec.competition];
        const cb = COMP_INDEX[b.rec.competition];
        if (ca !== cb) return ca - cb;
        return b.rec.momentum - a.rec.momentum;
      });
      break;
    case "opportunity":
      rows.sort((a, b) => b.score - a.score);
      break;
  }
  return rows;
}

export function getTopics(category?: Category | "all") {
  return category && category !== "all" ? TOPICS.filter((t) => t.category === category) : TOPICS;
}

// Momentum list for the Analyze view trend section.
export function getMomentumSignals(categories: Category[], platform: Platform | "all") {
  const rows: TrendRow[] = CORPUS.filter((rec) => {
    const catOk =
      categories.length === 0 ||
      categories.includes(rec.category) ||
      (rec.secondary ? categories.includes(rec.secondary) : false);
    const platOk = platform === "all" || rec.platforms.includes(platform);
    return catOk && platOk;
  })
    .map((rec) => ({
      rec,
      score: Math.max(40, Math.min(98, Math.round(
        0.42 * (60 + Math.min(30, rec.momentum / 2)) +
        0.28 * momentumNorm(rec.momentum) +
        0.15 * reachNorm(rec.volume) +
        0.15 * (100 - COMP_INDEX[rec.competition])
      ))),
      status: statusFor(rec.momentum),
      demand: demandFor(rec.volume),
      reach: reachFor(rec),
      spark: sparkFor(rec),
    }))
    .sort((a, b) => b.rec.momentum - a.rec.momentum);

  return rows.slice(0, 8);
}

export function fitLabel(momentum: number, catMatch: boolean): string {
  if (!catMatch) return "Adjacent";
  if (momentum >= 25) return "Strong fit";
  if (momentum >= 8) return "Good fit";
  return "Fair fit";
}
