// localStorage-backed state hooks. All reads happen after mount so SSR
// hydration stays deterministic.

"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export function readLS<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function writeLS<T>(key: string, value: T) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // private mode or quota exceeded: state still works in memory
  }
}

export function useLocalStorage<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(initial);
  const loaded = useRef(false);

  useEffect(() => {
    // Deferred so the first paint stays deterministic (SSR-safe) and we
    // never call setState synchronously inside an effect.
    const id = setTimeout(() => {
      setValue(readLS(key, initial));
      loaded.current = true;
    }, 0);
    return () => clearTimeout(id);
  }, [key]);

  useEffect(() => {
    if (loaded.current) writeLS(key, value);
  }, [key, value]);

  const update = useCallback((updater: T | ((prev: T) => T)) => {
    setValue((prev) =>
      typeof updater === "function" ? (updater as (p: T) => T)(prev) : updater
    );
  }, []);

  return [value, update] as const;
}

export const LS_KEYS = {
  savedTags: "hashpilot.saved-tags.v1",
  sets: "hashpilot.sets.v1",
  collections: "hashpilot.collections.v1",
  history: "hashpilot.history.v1",
  platform: "hashpilot.platform.v1",
  usage: "hashpilot.usage.v1",
};
