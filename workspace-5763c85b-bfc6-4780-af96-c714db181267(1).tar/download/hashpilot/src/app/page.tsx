"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Analysis,
  AnalyzeInput,
  Category,
  Collection,
  HistoryEntry,
  PLATFORM_GUIDE,
  PLATFORM_LABEL,
  Platform,
  RankedTag,
  SavedTag,
  Strategy,
  TagSet,
} from "@/lib/hashpilot/types";
import { analyze, regenerateTags, replacementFor } from "@/lib/hashpilot/engine";
import { ALL_PLATFORMS } from "@/lib/hashpilot/corpus";
import { LS_KEYS, useLocalStorage } from "@/lib/hashpilot/storage";
import { ChevronGlyph, Dropdown, DropdownItem, Reveal } from "@/components/hashpilot/ui";
import { IconClock, IconTrend, IconAnalyze, IconBookmarkNav } from "@/components/hashpilot/icons";
import AnalyzeView from "@/components/hashpilot/analyze-view";
import TrendsView from "@/components/hashpilot/trends-view";
import SavedView from "@/components/hashpilot/saved-view";
import HistoryView from "@/components/hashpilot/history-view";
import SetTray from "@/components/hashpilot/set-tray";

type View = "analyze" | "trends" | "saved" | "history";

const ANALYZE_STEPS = [
  "Reading your caption",
  "Matching topic signals",
  "Scanning 14 day momentum",
  "Ranking by opportunity",
];

const NAV: { id: View; label: string }[] = [
  { id: "analyze", label: "Analyze" },
  { id: "trends", label: "Trends" },
  { id: "saved", label: "Saved" },
  { id: "history", label: "History" },
];

export default function Home() {
  // ---------- persisted state ----------
  const [platform, setPlatform] = useLocalStorage<Platform>(LS_KEYS.platform, "instagram");
  const [savedTags, setSavedTags] = useLocalStorage<SavedTag[]>(LS_KEYS.savedTags, []);
  const [sets, setSets] = useLocalStorage<TagSet[]>(LS_KEYS.sets, []);
  const [collections, setCollections] = useLocalStorage<Collection[]>(LS_KEYS.collections, []);
  const [history, setHistory] = useLocalStorage<HistoryEntry[]>(LS_KEYS.history, []);
  const [usage, setUsage] = useLocalStorage<number>(LS_KEYS.usage, 31);

  // ---------- session state ----------
  const [view, setView] = useState<View>("analyze");
  const [caption, setCaption] = useState("");
  const [categories, setCategories] = useState<Category[]>([]);
  const [manualCats, setManualCats] = useState(false);
  const [strategy, setStrategy] = useState<Strategy>("balanced");
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [analysisSeed, setAnalysisSeed] = useState(0);
  const [analyzing, setAnalyzing] = useState(false);
  const [step, setStep] = useState(0);
  const [rankKey, setRankKey] = useState(0);
  const [selected, setSelected] = useState<string[]>([]);
  const [stale, setStale] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [toast, setToast] = useState<{ msg: string; id: number } | null>(null);
  const resultsRef = useRef<HTMLDivElement | null>(null);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const showToast = useCallback((msg: string) => {
    setToast({ msg, id: Date.now() });
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2400);
    return () => clearTimeout(t);
  }, [toast]);

  // Seed a default collection once, after persisted state has loaded.
  useEffect(() => {
    const id = setTimeout(() => {
      setCollections((prev) =>
        prev.length === 0
          ? [{ id: "c-default", name: "My tags", createdAt: Date.now() }]
          : prev
      );
    }, 50);
    return () => clearTimeout(id);
  }, [setCollections]);

  const guide = PLATFORM_GUIDE[platform];

  const currentInput = useCallback(
    (over: Partial<AnalyzeInput> = {}, seed = analysisSeed): AnalyzeInput => ({
      caption,
      platform,
      categories,
      strategy,
      seed,
      ...over,
    }),
    [caption, platform, categories, strategy, analysisSeed]
  );

  // ---------- analysis flows ----------

  const runAnalysis = useCallback(() => {
    if (!caption.trim() || analyzing) return;
    timers.current.forEach(clearTimeout);
    timers.current = [];
    setAnalyzing(true);
    setStep(0);
    setExpanded(null);

    ANALYZE_STEPS.forEach((_, i) => {
      if (i === 0) return;
      timers.current.push(setTimeout(() => setStep(i), i * 340));
    });

    timers.current.push(
      setTimeout(() => {
        const input = currentInput();
        const result = analyze(input);
        result.createdAt = Date.now();
        setAnalysis(result);
        setAnalysisSeed(0);
        setAnalyzing(false);
        setStale(false);
        setRankKey((k) => k + 1);

        const auto = result.tags.slice(0, guide.rec).map((t) => t.tag);
        setSelected(auto);

        setHistory((prev) => {
          const entry: HistoryEntry = {
            id: result.id + "-" + Date.now().toString(36),
            createdAt: result.createdAt,
            caption: result.input.caption,
            platform: result.input.platform,
            categories: result.input.categories,
            strategy: result.input.strategy,
            seed: 0,
            tagCount: result.tags.length,
            topTag: result.tags[0]?.tag ?? "",
            topScore: result.tags[0]?.score ?? 0,
            selected: auto,
          };
          return [entry, ...prev].slice(0, 24);
        });
        setUsage((u) => u + 1);

        if (typeof window !== "undefined" && window.innerWidth < 1020) {
          timers.current.push(
            setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 120)
          );
        }
      }, 1500)
    );
  }, [caption, analyzing, currentInput, guide.rec, setHistory, setUsage]);

  // Quick re-rank when strategy, platform or categories change mid-results.
  const rerank = useCallback(
    (over: Partial<AnalyzeInput>) => {
      if (!analysis) return;
      const input = currentInput(over);
      const fresh = analyze(input);
      fresh.createdAt = analysis.createdAt;
      setAnalysis(fresh);
      setRankKey((k) => k + 1);
      setSelected((prev) => {
        const present = new Set(fresh.tags.map((t) => t.tag));
        const keep = prev.filter((t) => present.has(t));
        return keep;
      });
    },
    [analysis, currentInput]
  );

  const changePlatform = useCallback(
    (p: Platform) => {
      setPlatform(p);
      rerank({ platform: p });
    },
    [setPlatform, rerank]
  );

  const changeStrategy = useCallback(
    (s: Strategy) => {
      setStrategy(s);
      rerank({ strategy: s });
    },
    [setStrategy, rerank]
  );

  const toggleCategory = useCallback(
    (c: Category) => {
      setManualCats(true);
      const next = categories.includes(c)
        ? categories.filter((x) => x !== c)
        : [...categories, c].slice(-3);
      setCategories(next);
      rerank({ categories: next });
    },
    [categories, rerank]
  );

  const onCaptionChange = useCallback(
    (v: string) => {
      setCaption(v);
      if (analysis) setStale(v !== analysis.input.caption);
    },
    [analysis]
  );

  const regenerate = useCallback(() => {
    if (!analysis) return;
    const nextSeed = analysisSeed + 1;
    const input = currentInput({}, nextSeed);
    const tags = regenerateTags(input, analysis.tags);
    setAnalysis({ ...analysis, tags, input });
    setAnalysisSeed(nextSeed);
    setRankKey((k) => k + 1);
    setSelected((prev) => {
      const present = new Set(tags.map((t) => t.tag));
      const keep = prev.filter((t) => present.has(t));
      return keep.length ? keep : tags.slice(0, guide.rec).map((t) => t.tag);
    });
    showToast("Alternate mix ready. Top 3 anchors kept.");
  }, [analysis, analysisSeed, currentInput, guide.rec, showToast]);

  const replaceTag = useCallback(
    (tag: string) => {
      if (!analysis) return;
      const idx = analysis.tags.findIndex((t) => t.tag === tag);
      if (idx < 0) return;
      const current = analysis.tags.map((t) => t.tag);
      const rec = replacementFor(
        currentInput(),
        current,
        analysis.tags[idx].category
      );
      if (!rec) {
        showToast("No alternatives left in this category.");
        return;
      }
      const tags = [...analysis.tags];
      tags[idx] = rec;
      setAnalysis({ ...analysis, tags });
      setSelected((prev) => (prev.includes(tag) ? prev.map((t) => (t === tag ? rec.tag : t)) : prev));
      showToast(`Swapped #${tag} for #${rec.tag}`);
    },
    [analysis, currentInput, showToast]
  );

  // ---------- selection / copy / save ----------

  const toggleSelect = useCallback(
    (tag: string) => {
      setSelected((prev) => (prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]));
    },
    []
  );

  const copyText = useCallback(
    async (text: string, msg: string) => {
      try {
        await navigator.clipboard.writeText(text);
        showToast(msg);
      } catch {
        try {
          const ta = document.createElement("textarea");
          ta.value = text;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          document.body.removeChild(ta);
          showToast(msg);
        } catch {
          showToast("Copy failed. Select the tags manually.");
        }
      }
    },
    [showToast]
  );

  const copyTag = useCallback((tag: string) => copyText(`#${tag}`, `Copied #${tag}`), [copyText]);

  const copySet = useCallback(() => {
    if (!selected.length) return;
    copyText(selected.map((t) => `#${t}`).join(" "), `Copied ${selected.length} tags`);
  }, [selected, copyText]);

  const toggleSaveTag = useCallback(
    (tag: RankedTag) => {
      setSavedTags((prev) => {
        const exists = prev.find((s) => s.tag === tag.tag);
        if (exists) {
          showToast(`Removed #${tag.tag} from saved`);
          return prev.filter((s) => s.tag !== tag.tag);
        }
        showToast(`Saved #${tag.tag}`);
        return [
          {
            tag: tag.tag,
            score: tag.score,
            momentum: tag.momentum,
            competition: tag.competition,
            category: tag.category,
            platform,
            savedAt: Date.now(),
          },
          ...prev,
        ];
      });
    },
    [platform, setSavedTags, showToast]
  );

  const saveSet = useCallback(
    (name: string, collectionId: string) => {
      if (!selected.length) return;
      const set: TagSet = {
        id: `s-${Date.now().toString(36)}`,
        name: name.trim() || `Set of ${new Date().toLocaleDateString("en-US", { month: "short", day: "numeric" })}`,
        collectionId,
        tags: [...selected],
        platform,
        createdAt: Date.now(),
      };
      setSets((prev) => [set, ...prev]);
      showToast(`Saved "${set.name}" with ${set.tags.length} tags`);
    },
    [selected, platform, setSets, showToast]
  );

  // ---------- history reopen ----------

  const openHistory = useCallback(
    (entry: HistoryEntry) => {
      const input: AnalyzeInput = {
        caption: entry.caption,
        platform: entry.platform,
        categories: entry.categories,
        strategy: entry.strategy,
        seed: entry.seed,
      };
      const result = analyze(input);
      result.createdAt = entry.createdAt;
      setCaption(entry.caption);
      setPlatform(entry.platform);
      setCategories(entry.categories);
      setManualCats(true);
      setStrategy(entry.strategy);
      setAnalysisSeed(entry.seed);
      setAnalysis(result);
      setSelected(entry.selected.filter((t) => result.tags.some((r) => r.tag === t)));
      setStale(false);
      setRankKey((k) => k + 1);
      setView("analyze");
      timers.current.push(
        setTimeout(() => resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 150)
      );
    },
    [setPlatform]
  );

  // ---------- keyboard shortcut ----------

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter" && view === "analyze") {
        e.preventDefault();
        runAnalysis();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [runAnalysis, view]);

  // ---------- derived ----------

  const savedTagSet = useMemo(() => new Set(savedTags.map((s) => s.tag)), [savedTags]);

  const scrollTo = (v: View) => {
    setView(v);
    window.scrollTo({ top: 0, behavior: "auto" });
  };

  return (
    <div className="app">
      <header className="masthead">
        <div className="masthead-inner">
          <button className="wordmark" onClick={() => scrollTo("analyze")} aria-label="Hashpilot home">
            <img src="logo.png" alt="" width={21} height={21} className="wordmark-logo" />
            Hashpilot
          </button>
          <nav className="nav" aria-label="Main">
            {NAV.map((n) => (
              <button
                key={n.id}
                className={`nav-link ${view === n.id ? "active" : ""}`}
                aria-current={view === n.id ? "page" : undefined}
                onClick={() => scrollTo(n.id)}
              >
                {n.label}
              </button>
            ))}
          </nav>
          <div className="masthead-right">
            <Dropdown
              trigger={(open) => (
                <>
                  <span className="dd-label">Platform</span>
                  <strong style={{ fontWeight: 600 }}>{PLATFORM_LABEL[platform]}</strong>
                  <ChevronGlyph />
                </>
              )}
            >
              {(close) => (
                <>
                  {ALL_PLATFORMS.map((p) => (
                    <DropdownItem
                      key={p}
                      selected={p === platform}
                      onClick={() => {
                        changePlatform(p);
                        close();
                      }}
                    >
                      {PLATFORM_LABEL[p]}
                    </DropdownItem>
                  ))}
                </>
              )}
            </Dropdown>
            <span className="masthead-divider" aria-hidden />
            <Dropdown
              trigger={() => <span className="avatar">MK</span>}
              width={216}
            >
              {(close) => (
                <>
                  <div className="dd-meta" style={{ paddingTop: 8 }}>
                    MARA KESSLER · STUDIO PLAN
                  </div>
                  <div className="dd-meta" style={{ color: "var(--mut)", fontFamily: "var(--sans)", fontSize: 12 }}>
                    {usage} analyses this month
                  </div>
                  <div className="dd-sep" />
                  <DropdownItem onClick={() => { scrollTo("history"); close(); }}>
                    <IconClock size={13} /> Analysis history
                  </DropdownItem>
                  <DropdownItem onClick={() => { scrollTo("saved"); close(); }}>
                    <IconBookmarkNav size={13} /> Saved tags and sets
                  </DropdownItem>
                  <div className="dd-sep" />
                  <div className="dd-meta" style={{ paddingBottom: 8 }}>
                    Trend data refreshed 09:41
                  </div>
                </>
              )}
            </Dropdown>
          </div>
        </div>
      </header>

      <main className="page" style={{ paddingTop: 2, paddingBottom: 120 }}>
        {view === "analyze" && (
          <AnalyzeView
            caption={caption}
            onCaptionChange={onCaptionChange}
            platform={platform}
            onPlatformChange={changePlatform}
            categories={categories}
            onToggleCategory={toggleCategory}
            strategy={strategy}
            onStrategyChange={changeStrategy}
            analysis={analysis}
            analyzing={analyzing}
            step={step}
            stale={stale}
            rankKey={rankKey}
            selected={selected}
            savedTagSet={savedTagSet}
            resultsRef={resultsRef}
            onAnalyze={runAnalysis}
            onRegenerate={regenerate}
            onReplace={replaceTag}
            onToggleSelect={toggleSelect}
            onCopyTag={copyTag}
            onToggleSave={toggleSaveTag}
            expanded={expanded}
            onExpand={setExpanded}
            onToast={showToast}
            onSample={(c) => onCaptionChange(c)}
          />
        )}
        {view === "trends" && (
          <Reveal>
            <TrendsView
              key={platform}
              platform={platform}
              onPlatformChange={changePlatform}
              onCopyTag={copyTag}
              onToggleSave={toggleSaveTag}
              savedTagSet={savedTagSet}
              onToast={showToast}
            />
          </Reveal>
        )}
        {view === "saved" && (
          <Reveal>
            <SavedView
              savedTags={savedTags}
              sets={sets}
              collections={collections}
              onRemoveSaved={(tag) => {
                setSavedTags((prev) => prev.filter((s) => s.tag !== tag));
                showToast(`Removed #${tag}`);
              }}
              onCopyTag={copyTag}
              onCopySet={(set) => copyText(set.tags.map((t) => `#${t}`).join(" "), `Copied "${set.name}"`)}
              onDeleteSet={(id) => {
                setSets((prev) => prev.filter((s) => s.id !== id));
                showToast("Set deleted");
              }}
              onAddToSet={(tag, setId) => {
                setSets((prev) =>
                  prev.map((s) => (s.id === setId && !s.tags.includes(tag) ? { ...s, tags: [...s.tags, tag] } : s))
                );
                showToast(`Added #${tag} to set`);
              }}
              onCreateCollection={(name) => {
                setCollections((prev) => [
                  ...prev,
                  { id: `c-${Date.now().toString(36)}`, name, createdAt: Date.now() },
                ]);
                showToast(`Collection "${name}" created`);
              }}
              onToast={showToast}
            />
          </Reveal>
        )}
        {view === "history" && (
          <Reveal>
            <HistoryView
              history={history}
              onOpen={openHistory}
              onDelete={(id) => {
                setHistory((prev) => prev.filter((h) => h.id !== id));
                showToast("Analysis removed");
              }}
              onClear={() => {
                setHistory([]);
                showToast("History cleared");
              }}
            />
          </Reveal>
        )}
      </main>

      <footer className="colophon">
        <div className="colophon-inner">
          <span className="colophon-mark">Hashpilot</span>
          <p>Hashtag research for people who publish on schedule.</p>
          <p>Instagram · TikTok · YouTube · LinkedIn</p>
          <span className="colophon-right">SIGNAL DATASET V0.9 · REFRESHED 09:41 GMT</span>
        </div>
      </footer>

      <SetTray
        selected={selected}
        analysis={analysis}
        guide={guide}
        platform={platform}
        collections={collections}
        onRemove={toggleSelect}
        onReorder={(next) => setSelected(next)}
        onCopyAll={copySet}
        onSaveSet={saveSet}
        onClear={() => setSelected([])}
        onToast={showToast}
      />

      {toast && (
        <div className="toast" key={toast.id} role="status">
          {toast.msg}
        </div>
      )}

      <nav className="bottom-nav" aria-label="Mobile">
        <div className="bottom-nav-inner">
          {NAV.map((n) => {
            const Icon =
              n.id === "analyze" ? IconAnalyze : n.id === "trends" ? IconTrend : n.id === "saved" ? IconBookmarkNav : IconClock;
            return (
              <button
                key={n.id}
                className={`bottom-link ${view === n.id ? "active" : ""}`}
                onClick={() => scrollTo(n.id)}
                aria-current={view === n.id ? "page" : undefined}
              >
                <Icon size={17} />
                {n.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
