"use client";

import { useEffect, useMemo, useState } from "react";
import { Category, PLATFORM_LABEL, Platform } from "@/lib/hashpilot/types";
import { fitLabel, fmtCount, getMomentumSignals } from "@/lib/hashpilot/engine";
import { DeltaText, Sparkline, StatusChip, observeReveal, useReveal } from "@/components/hashpilot/ui";

export default function MomentumSection({
  categories,
  platform,
}: {
  categories: Category[];
  platform: Platform | "all";
}) {
  const rows = useMemo(() => getMomentumSignals(categories, platform), [categories, platform]);
  const [updated, setUpdated] = useState("");
  const revealRef = useReveal<HTMLDivElement>(0.08);

  useEffect(() => {
    const id = setTimeout(() => {
      const d = new Date(Date.now() - 7 * 60000);
      setUpdated(
        d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
      );
    }, 0);
    return () => clearTimeout(id);
  }, []);

  if (!rows.length) return null;
  const featured = rows[0];

  return (
    <section className="page-block" aria-label="Trend momentum">
      <div className="reveal" ref={revealRef}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 12, flexWrap: "wrap", marginBottom: 12 }}>
          <div>
            <div className="section-label">Trend momentum</div>
            <h2 className="section-title" style={{ margin: "4px 0 0" }}>
              {categories.length
                ? `Where ${categories.join(" and ")} is moving`
                : "Where conversations are moving"}
          </h2>
          </div>
          <div style={{ marginLeft: "auto" }} className="updated-note">
            <span className="dot" />
            Signal updated {updated || "09:41"}
          </div>
        </div>

        <div className="momentum-grid">
          <div className="panel">
            <div className="momo-row" style={{ borderTop: 0, paddingBottom: 4 }}>
              <span className="section-label">Hashtag</span>
              <span className="section-label" style={{ textAlign: "left" }}>14 day</span>
              <span className="section-label momo-right">24h</span>
              <span className="section-label momo-right">Fit</span>
            </div>
            {rows.map((r, i) => {
              const catMatch =
                categories.length === 0 ||
                categories.includes(r.rec.category) ||
                (r.rec.secondary ? categories.includes(r.rec.secondary) : false);
              return (
                <div
                  className="momo-row reveal"
                  key={r.rec.tag}
                  ref={(el) => {
                    if (!el) return;
                    el.style.setProperty("--reveal-delay", `${i * 45}ms`);
                    observeReveal(el);
                  }}
                >
                  <div style={{ minWidth: 0 }}>
                    <div className="momo-tag">
                      <span className="hash">#</span>
                      {r.rec.tag}
                    </div>
                    <div style={{ marginTop: 2 }}>
                      <StatusChip status={r.status} />
                    </div>
                  </div>
                  <div className={`spark-cell s-${r.status.toLowerCase()} momo-spark`}>
                    <Sparkline points={r.spark} width={96} height={26} />
                  </div>
                  <div className="momo-right">
                    <DeltaText value={r.rec.momentum} />
                    <div className="faint mono" style={{ fontSize: 10, marginTop: 2 }}>
                      {fmtCount(r.rec.volume)}
                    </div>
                  </div>
                  <div className="momo-right meta">{fitLabel(r.rec.momentum, catMatch)}</div>
                </div>
              );
            })}
          </div>

          <div className="panel" style={{ padding: "18px 20px" }}>
            <div className="section-label">Fastest riser</div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 8, flexWrap: "wrap" }}>
              <span className="tag-name" style={{ fontSize: 17 }}>
                <span className="hash">#</span>
                {featured.rec.tag}
              </span>
              <StatusChip status={featured.status} momentum={featured.rec.momentum} />
            </div>
            <div className={`spark-cell s-${featured.status.toLowerCase()}`} style={{ marginTop: 14 }}>
              <Sparkline points={featured.spark} width={280} height={64} />
            </div>
            <div style={{ height: 14 }} />
            <dl
              style={{
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: "10px 18px",
                margin: 0,
                fontSize: 13,
              }}
            >
              {[
                ["Monthly posts", fmtCount(featured.rec.volume)],
                ["Competition", featured.rec.competition],
                ["7 day move", `${featured.rec.momentum7 > 0 ? "+" : ""}${featured.rec.momentum7}%`],
                ["Best on", featured.rec.platforms.map((p) => PLATFORM_LABEL[p]).join(" · ")],
              ].map(([k, v]) => (
                <div key={k}>
                  <dt className="metric-k">{k}</dt>
                  <dd className="metric-v" style={{ margin: 0 }}>
                    {v}
                  </dd>
                </div>
              ))}
            </dl>
            {featured.rec.note && (
              <p className="meta" style={{ margin: "14px 0 0", fontSize: 12.5 }}>
                {featured.rec.note}
              </p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
