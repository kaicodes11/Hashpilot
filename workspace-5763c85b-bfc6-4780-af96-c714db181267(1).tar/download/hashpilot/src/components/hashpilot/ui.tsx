"use client";

// Shared UI primitives: scroll reveal, animated numbers, sparklines,
// status chips, dropdowns.

import {
  ReactNode,
  SVGProps,
  useEffect,
  useRef,
  useState,
} from "react";
import type { Status } from "@/lib/hashpilot/types";
import {
  IconArrowUpRight,
  IconArrowDownRight,
  IconDash,
  IconCheck,
  IconChevronDown,
} from "./icons";

/* ---------- reveal on scroll ---------- */

let sharedIO: IntersectionObserver | null = null;

function getSharedIO() {
  if (typeof window === "undefined") return null;
  if (!sharedIO) {
    sharedIO = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            sharedIO?.unobserve(e.target);
          }
        }
      },
      { threshold: 0, rootMargin: "0px 0px -6% 0px" }
    );
  }
  return sharedIO;
}

/** Adds `.in` to the element when it slides into the viewport. */
export function observeReveal(el: HTMLElement | null) {
  if (!el) return;
  const io = getSharedIO();
  if (!io) return;
  // Elements already scrolled past (jump navigation) reveal immediately.
  if (el.getBoundingClientRect().bottom < 0) {
    el.classList.add("in");
    return;
  }
  io.observe(el);
}

export function useReveal<T extends HTMLElement>(threshold = 0.12) {
  const ref = useRef<T | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        }
      },
      { threshold, rootMargin: "0px 0px -6% 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return ref;
}

export function Reveal({
  children,
  delay = 0,
  className = "",
  as: Tag = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section" | "header";
}) {
  const ref = useReveal<HTMLDivElement>();
  return (
    <Tag
      ref={ref as never}
      className={`reveal ${className}`}
      style={{ ["--reveal-delay" as string]: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

/* ---------- animated number ---------- */

export function AnimatedNumber({
  value,
  duration = 520,
  className = "",
}: {
  value: number;
  duration?: number;
  className?: string;
}) {
  const [display, setDisplay] = useState(0);
  const raf = useRef<number | null>(null);

  useEffect(() => {
    const from = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setDisplay(Math.round(from + (value - from) * eased));
      if (p < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
  }, [value, duration]);

  return (
    <span className={className} style={{ fontVariantNumeric: "tabular-nums" }}>
      {display}
    </span>
  );
}

/* ---------- sparkline ---------- */

export function Sparkline({
  points,
  width = 96,
  height = 26,
  showDot = true,
}: {
  points: number[];
  width?: number;
  height?: number;
  showDot?: boolean;
}) {
  if (!points.length) return null;
  const min = Math.min(...points);
  const max = Math.max(...points);
  const span = Math.max(max - min, 8);
  const pad = 3;
  const step = (width - pad * 2) / (points.length - 1);
  const coords = points.map((p, i) => {
    const x = pad + i * step;
    const y = pad + (1 - (p - min) / span) * (height - pad * 2);
    return [x, y] as const;
  });
  const line = coords.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const last = coords[coords.length - 1];
  const baseY = height - 2;
  return (
    <svg className="spark" width={width} height={height} aria-hidden>
      <line className="spark-base" x1={0} x2={width} y1={baseY} y2={baseY} />
      <polyline points={line} />
      {showDot && <circle className="spark-dot" cx={last[0]} cy={last[1]} r={2} />}
    </svg>
  );
}

/* ---------- status ---------- */

export function StatusChip({ status, momentum, statusLabel }: {
  status: Status;
  momentum?: number;
  statusLabel?: string;
}) {
  const cls = status === "Rising" ? "rising" : status === "Falling" ? "falling" : "stable";
  const Icon =
    status === "Rising" ? IconArrowUpRight : status === "Falling" ? IconArrowDownRight : IconDash;
  const sign = momentum === undefined ? "" : momentum > 0 ? `+${momentum}%` : `${momentum}%`;
  return (
    <span className={`status-chip ${cls}`}>
      <Icon size={11} />
      {statusLabel ?? `${status}${momentum !== undefined ? " " + sign : ""}`}
    </span>
  );
}

export function DeltaText({ value, className = "" }: { value: number; className?: string }) {
  const cls = value >= 15 ? "up" : value <= -3 ? "down" : "flat";
  const sign = value > 0 ? `+${value}%` : `${value}%`;
  return <span className={`momo-delta ${cls} ${className}`}>{sign}</span>;
}

/* ---------- dropdown ---------- */

export function Dropdown({
  trigger,
  children,
  align = "right",
  width,
}: {
  trigger: (open: boolean) => ReactNode;
  children: (close: () => void) => ReactNode;
  align?: "left" | "right";
  width?: number;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <div className="dd" ref={ref}>
      <button
        type="button"
        className="dd-trigger"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-haspopup="true"
      >
        {trigger(open)}
      </button>
      {open && (
        <div
          className="dd-menu"
          style={{ [align === "right" ? "right" : "left"]: 0, width }}
          role="menu"
        >
          {children(() => setOpen(false))}
        </div>
      )}
    </div>
  );
}

export function DropdownItem({
  children,
  onClick,
  selected,
}: {
  children: ReactNode;
  onClick?: () => void;
  selected?: boolean;
}) {
  return (
    <button type="button" className="dd-item" onClick={onClick} role="menuitem">
      <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>{children}</span>
      {selected && <IconCheck size={13} className="dd-check" />}
    </button>
  );
}

export function ChevronGlyph() {
  return <IconChevronDown size={12} className="faint" />;
}

/* ---------- misc ---------- */

export function HashTag({ tag }: { tag: string }) {
  return (
    <span className="trend-tag">
      <span className="hash">#</span>
      {tag}
    </span>
  );
}

export function SectionHead({
  label,
  title,
  right,
}: {
  label: string;
  title: string;
  right?: ReactNode;
}) {
  return (
    <div style={{ display: "flex", alignItems: "baseline", gap: 12, flexWrap: "wrap" }}>
      <div>
        <div className="section-label">{label}</div>
        <h2 className="section-title" style={{ margin: "4px 0 0" }}>
          {title}
        </h2>
      </div>
      {right && <div style={{ marginLeft: "auto" }}>{right}</div>}
    </div>
  );
}

export function SquareIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 16 16" width={14} height={14} aria-hidden {...props}>
      <rect x="2" y="2" width="12" height="12" rx="2" fill="none" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}
