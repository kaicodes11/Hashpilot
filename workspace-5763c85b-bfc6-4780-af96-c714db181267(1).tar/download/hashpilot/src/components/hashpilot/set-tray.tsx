"use client";

import { useEffect, useRef, useState } from "react";
import { Analysis, Collection, PLATFORM_GUIDE, Platform } from "@/lib/hashpilot/types";
import { IconChevronLeft, IconChevronRight, IconGrip, IconX } from "@/components/hashpilot/icons";

export default function SetTray({
  selected,
  analysis,
  guide,
  platform,
  collections,
  onRemove,
  onReorder,
  onCopyAll,
  onSaveSet,
  onClear,
  onToast,
}: {
  selected: string[];
  analysis: Analysis | null;
  guide: { rec: number; max: number; note: string };
  platform: Platform;
  collections: Collection[];
  onRemove: (tag: string) => void;
  onReorder: (next: string[]) => void;
  onCopyAll: () => void;
  onSaveSet: (name: string, collectionId: string) => void;
  onClear: () => void;
  onToast: (msg: string) => void;
}) {
  const [show, setShow] = useState(false);
  const [saving, setSaving] = useState(false);
  const [collapsed, setCollapsed] = useState(false);
  const [name, setName] = useState("");
  const [collectionId, setCollectionId] = useState("");
  const dragFrom = useRef<number | null>(null);

  useEffect(() => {
    setShow(selected.length > 0);
  }, [selected]);

  useEffect(() => {
    if (collections.length && !collectionId) setCollectionId(collections[0].id);
  }, [collections, collectionId]);

  if (!show && !selected.length) return null;

  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= selected.length) return;
    const next = [...selected];
    [next[i], next[j]] = [next[j], next[i]];
    onReorder(next);
  };

  const doSave = () => {
    if (!collections.length) {
      onToast("Create a collection on the Saved page first.");
      setSaving(false);
      return;
    }
    onSaveSet(name, collectionId || collections[0].id);
    setName("");
    setSaving(false);
  };

  const over = analysis && analysis.tags.length ? analysis.tags.length : guide.rec;

  return (
    <div className={`tray ${show ? "show" : ""}`} aria-label="Your hashtag set">
      <div className="tray-inner">
        <div className="tray-bar">
          <div className="tray-top">
            <button
              className="btn-icon btn"
              onClick={() => setCollapsed((c) => !c)}
              title={collapsed ? "Expand tray" : "Collapse tray"}
              aria-label={collapsed ? "Expand set tray" : "Collapse set tray"}
              aria-expanded={!collapsed}
            >
              {collapsed ? <IconChevronRight size={13} /> : <IconChevronLeft size={13} />}
            </button>
            <span className="section-label">Your set</span>
            <span className="tray-count">
              {selected.length} / {over} SELECTED · {PLATFORM_GUIDE[platform].rec} RECOMMENDED ON{" "}
              {platform.toUpperCase()}
            </span>
            <span style={{ flex: 1 }} />
            {saving ? (
              <button className="btn btn-sm" onClick={() => setSaving(false)}>
                Cancel
              </button>
            ) : (
              <button className="btn btn-sm" onClick={() => setSaving(true)} disabled={!selected.length}>
                Save as set
              </button>
            )}
            <button className="btn btn-sm" onClick={onCopyAll} disabled={!selected.length}>
              Copy all
            </button>
            <button className="btn btn-sm btn-ghost" onClick={onClear} disabled={!selected.length}>
              Clear
            </button>
          </div>

          {saving ? (
            <div className="save-form">
              <input
                type="text"
                placeholder="Set name, e.g. Tokyo launch week"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && doSave()}
                maxLength={48}
              />
              <select value={collectionId} onChange={(e) => setCollectionId(e.target.value)}>
                {collections.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <button className="btn btn-primary btn-sm" onClick={doSave}>
                Save
              </button>
            </div>
          ) : collapsed ? (
            <div className="tray-note" style={{ paddingTop: 6 }}>
              {selected.map((t) => `#${t}`).join("  ")}
            </div>
          ) : (
            <>
              <div className="tray-chips">
                {selected.map((tag, i) => (
                  <span
                    className="tray-chip"
                    key={tag}
                    draggable
                    onDragStart={() => (dragFrom.current = i)}
                    onDragOver={(e) => e.preventDefault()}
                    onDragEnd={() => (dragFrom.current = null)}
                    onDrop={() => {
                      const from = dragFrom.current;
                      if (from === null || from === i) return;
                      const next = [...selected];
                      const [moved] = next.splice(from, 1);
                      next.splice(i, 0, moved);
                      onReorder(next);
                      dragFrom.current = null;
                    }}
                  >
                    <span className="hash">#</span>
                    {tag}
                    <button
                      className="move touch-show"
                      onClick={() => move(i, -1)}
                      aria-label={`Move ${tag} earlier`}
                      style={{ opacity: i === 0 ? 0.3 : 1 }}
                    >
                      <IconChevronLeft size={12} />
                    </button>
                    <button
                      className="move touch-show"
                      onClick={() => move(i, 1)}
                      aria-label={`Move ${tag} later`}
                      style={{ opacity: i === selected.length - 1 ? 0.3 : 1 }}
                    >
                      <IconChevronRight size={12} />
                    </button>
                    <span className="faint" style={{ display: "inline-flex", cursor: "grab" }} title="Drag to reorder">
                      <IconGrip size={12} />
                    </span>
                    <button onClick={() => onRemove(tag)} aria-label={`Remove ${tag} from set`}>
                      <IconX size={12} />
                    </button>
                  </span>
                ))}
              </div>
              <div className="tray-note">
                Drag chips to reorder order matters less than fit, but lead with your strongest tag.
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
