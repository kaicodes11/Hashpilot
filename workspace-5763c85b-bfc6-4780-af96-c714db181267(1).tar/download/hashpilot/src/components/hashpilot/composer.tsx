"use client";

import { useMemo } from "react";
import {
  CATEGORY_LABEL,
  Category,
  PLATFORM_GUIDE,
  PLATFORM_LABEL,
  Platform,
  Strategy,
  STRATEGY_LABEL,
} from "@/lib/hashpilot/types";
import { detectSignals, tokenize } from "@/lib/hashpilot/engine";
import { SAMPLES } from "@/lib/hashpilot/corpus";

const ALL_CATEGORIES = Object.keys(CATEGORY_LABEL) as Category[];

export default function Composer({
  caption,
  onCaptionChange,
  platform,
  onPlatformChange,
  categories,
  onToggleCategory,
  strategy,
  onStrategyChange,
  onAnalyze,
  analyzing,
  stale,
  onSample,
}: {
  caption: string;
  onCaptionChange: (v: string) => void;
  platform: Platform;
  onPlatformChange: (p: Platform) => void;
  categories: Category[];
  onToggleCategory: (c: Category) => void;
  strategy: Strategy;
  onStrategyChange: (s: Strategy) => void;
  onAnalyze: () => void;
  analyzing: boolean;
  stale: boolean;
  onSample: (caption: string) => void;
}) {
  const signals = useMemo(() => detectSignals(tokenize(caption)), [caption]);
  const guide = PLATFORM_GUIDE[platform];

  return (
    <div className="composer">
      <div className="panel">
        <div className="composer-block">
          <div className="field-label">
            <span>Caption</span>
            <span>
              {caption.length} / {platform === "instagram" ? "2,200" : platform === "linkedin" ? "3,000" : "2,200"}
            </span>
          </div>
          <textarea
            className="caption-input"
            placeholder={"Paste or write your post...\n\nExample: Just landed in Tokyo. The food, architecture and tiny coffee shops completely surprised me."}
            value={caption}
            onChange={(e) => onCaptionChange(e.target.value)}
            aria-label="Social media caption"
          />
          <div className="caption-foot">
            <span className="signals-line">
              {signals.length ? (
                <>
                  SIGNALS <strong>{signals.slice(0, 5).join(" · ")}</strong>
                </>
              ) : (
                "SIGNALS appear here as you write"
              )}
            </span>
          </div>
          <div className="sample-row" aria-label="Sample captions">
            {SAMPLES.map((s) => (
              <button key={s.label} className="chip" onClick={() => onSample(s.caption)}>
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <div className="composer-block">
          <div className="field-label">
            <span>Platform</span>
            <span>{guide.rec} tags recommended</span>
          </div>
          <div className="seg" role="tablist" aria-label="Platform">
            {(Object.keys(PLATFORM_LABEL) as Platform[]).map((p) => (
              <button
                key={p}
                className={p === platform ? "active" : ""}
                onClick={() => onPlatformChange(p)}
                role="tab"
                aria-selected={p === platform}
              >
                {PLATFORM_LABEL[p]}
              </button>
            ))}
          </div>
          <div style={{ height: 16 }} />
          <div className="field-label">
            <span>Audience</span>
            <span>{categories.length ? `${categories.length} selected` : "auto from caption"}</span>
          </div>
          <div className="chip-row">
            {ALL_CATEGORIES.map((c) => (
              <button
                key={c}
                className={`chip ${categories.includes(c) ? "active" : ""}`}
                onClick={() => onToggleCategory(c)}
                aria-pressed={categories.includes(c)}
              >
                {CATEGORY_LABEL[c]}
              </button>
            ))}
          </div>
        </div>

        <div className="composer-block">
          <div className="field-label">
            <span>Strategy</span>
            <span>changes the ranking live</span>
          </div>
          <div className="seg seg-cards">
            {(Object.keys(STRATEGY_LABEL) as Strategy[]).map((s) => (
              <button
                key={s}
                className={s === strategy ? "active" : ""}
                onClick={() => onStrategyChange(s)}
                aria-pressed={s === strategy}
              >
                <span className="seg-title">{STRATEGY_LABEL[s].title}</span>
                <span className="seg-desc">{STRATEGY_LABEL[s].desc}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="compose-actions">
          <button className="btn btn-primary" onClick={onAnalyze} disabled={analyzing || !caption.trim()}>
            {analyzing ? "Analyzing" : stale ? "Re-analyze post" : "Analyze post"}
          </button>
          <span className="kbd-hint">CTRL + ENTER</span>
        </div>
      </div>
    </div>
  );
}
