"use client";

import { HistoryEntry, PLATFORM_LABEL, STRATEGY_LABEL } from "@/lib/hashpilot/types";
import { useReveal } from "@/components/hashpilot/ui";
import { IconClock, IconTrash } from "@/components/hashpilot/icons";

export default function HistoryView({
  history,
  onOpen,
  onDelete,
  onClear,
}: {
  history: HistoryEntry[];
  onOpen: (entry: HistoryEntry) => void;
  onDelete: (id: string) => void;
  onClear: () => void;
}) {
  const pageRef = useReveal<HTMLDivElement>(0.03);

  const fmtDate = (ts: number) =>
    new Date(ts).toLocaleDateString("en-US", { month: "short", day: "numeric" });
  const fmtTime = (ts: number) =>
    new Date(ts).toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });

  const topic = (caption: string) => {
    const t = caption.length > 74 ? caption.slice(0, 74).trimEnd() + "..." : caption;
    return t;
  };

  return (
    <div ref={pageRef} className="reveal in">
      <div className="hero" style={{ paddingBottom: 20 }}>
        <div className="hero-eyebrow">
          <span className="section-label">Past analyses</span>
        </div>
        <h1>History</h1>
        <p className="lede">
          Every analysis you run is kept here. Open one to restore the caption, the strategy and the
          full ranked list.
        </p>
      </div>

      <div className="panel">
        <div className="results-head">
          <span className="section-label">Analyses</span>
          <span className="results-stats">{history.length} ENTRIES</span>
          <span className="spacer" />
          {history.length > 0 && (
            <button className="btn btn-sm" onClick={onClear}>
              <IconTrash size={12} />
              Clear all
            </button>
          )}
        </div>

        {history.length === 0 ? (
          <div className="empty-state">
            <div className="section-label" style={{ marginBottom: 8 }}>
              <IconClock size={12} />
            </div>
            <h3>Nothing here yet.</h3>
            <p>
              Run your first analysis on the Analyze page. Each run is archived with its caption,
              platform, strategy and top recommendation.
            </p>
          </div>
        ) : (
          history.map((h) => (
            <button
              className="hrow"
              key={h.id}
              onClick={() => onOpen(h)}
              aria-label={`Reopen analysis from ${fmtDate(h.createdAt)}`}
            >
              <span className="h-date">
                {fmtDate(h.createdAt)}
                <br />
                {fmtTime(h.createdAt)}
              </span>
              <span className="h-topic">{topic(h.caption)}</span>
              <span className="meta">{PLATFORM_LABEL[h.platform]}</span>
              <span className="meta">
                {h.tagCount} tags · {STRATEGY_LABEL[h.strategy].title}
              </span>
              <span className="h-top">
                Top pick <b>#{h.topTag}</b> at {h.topScore}/100
              </span>
              <span className="meta" style={{ color: "var(--accent)", fontWeight: 550 }}>
                Reopen
              </span>
            </button>
          ))
        )}
      </div>
    </div>
  );
}
