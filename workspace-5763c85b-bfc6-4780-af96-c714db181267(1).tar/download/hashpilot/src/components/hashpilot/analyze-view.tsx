"use client";

import { RefObject } from "react";
import { Analysis, Category, Platform, RankedTag, Strategy } from "@/lib/hashpilot/types";
import { useReveal } from "@/components/hashpilot/ui";
import Composer from "./composer";
import ResultsPanel from "./results";
import MomentumSection from "./momentum";

export default function AnalyzeView({
  caption,
  onCaptionChange,
  platform,
  onPlatformChange,
  categories,
  onToggleCategory,
  strategy,
  onStrategyChange,
  analysis,
  analyzing,
  step,
  stale,
  rankKey,
  selected,
  savedTagSet,
  resultsRef,
  onAnalyze,
  onRegenerate,
  onReplace,
  onToggleSelect,
  onCopyTag,
  onToggleSave,
  expanded,
  onExpand,
  onSample,
}: {
  caption: string;
  onCaptionChange: (v: string) => void;
  platform: Platform;
  onPlatformChange: (p: Platform) => void;
  categories: Category[];
  onToggleCategory: (c: Category) => void;
  strategy: Strategy;
  onStrategyChange: (s: Strategy) => void;
  analysis: Analysis | null;
  analyzing: boolean;
  step: number;
  stale: boolean;
  rankKey: number;
  selected: string[];
  savedTagSet: Set<string>;
  resultsRef: RefObject<HTMLDivElement | null>;
  onAnalyze: () => void;
  onRegenerate: () => void;
  onReplace: (tag: string) => void;
  onToggleSelect: (tag: string) => void;
  onCopyTag: (tag: string) => void;
  onToggleSave: (tag: RankedTag) => void;
  expanded: string | null;
  onExpand: (tag: string | null) => void;
  onSample: (caption: string) => void;
}) {
  const heroRef = useReveal<HTMLDivElement>(0.05);
  const wsRef = useReveal<HTMLDivElement>(0.03);

  return (
    <>
      <div className="hero reveal in" ref={heroRef}>
        <div className="hero-eyebrow">
          <span className="dot" />
          <span className="section-label">Hashtag research · live signal</span>
        </div>
        <h1>Find the tags your post deserves.</h1>
        <p className="lede">
          Paste your post and see which conversations are gaining momentum. Every tag is scored on
          relevance, competition and current movement.
        </p>
      </div>

      <div className="workspace reveal in" ref={wsRef}>
        <Composer
          caption={caption}
          onCaptionChange={onCaptionChange}
          platform={platform}
          onPlatformChange={onPlatformChange}
          categories={categories}
          onToggleCategory={onToggleCategory}
          strategy={strategy}
          onStrategyChange={onStrategyChange}
          onAnalyze={onAnalyze}
          analyzing={analyzing}
          stale={stale}
          onSample={onSample}
        />
        <ResultsPanel
          analysis={analysis}
          analyzing={analyzing}
          step={step}
          stale={stale}
          rankKey={rankKey}
          selected={selected}
          savedTagSet={savedTagSet}
          resultsRef={resultsRef}
          platform={platform}
          strategy={strategy}
          onRegenerate={onRegenerate}
          onReplace={onReplace}
          onToggleSelect={onToggleSelect}
          onCopyTag={onCopyTag}
          onToggleSave={onToggleSave}
          expanded={expanded}
          onExpand={onExpand}
        />
      </div>

      <MomentumSection categories={categories} platform={platform} />
    </>
  );
}
