"use client";

import { Fragment, useEffect, useMemo, useState } from "react";
import {
  CATEGORY_LABEL,
  Category,
  PLATFORM_LABEL,
  Platform,
  RankedTag,
  TrendSort,
} from "@/lib/hashpilot/types";
import { fmtCount, fmtImpressions, getTrending, getTopics } from "@/lib/hashpilot/engine";
import { DeltaText, HashTag, Reveal, Sparkline, StatusChip } from "@/components/hashpilot/ui";
import { IconBookmark, IconCopy } from "@/components/hashpilot/icons";
import { ALL_PLATFORMS, CORPUS } from "@/lib/hashpilot/corpus";

const ALL_CATEGORIES = Object.keys(CATEGORY_LABEL) as Category[];

const SORTS: { id: TrendSort; label: string }[] = [
  { id: "fastest", label: "Rising fastest" },
  { id: "reach", label: "Highest reach" },
  { id: "competition", label: "Lowest competition" },
  { id: "opportunity", label: "Best opportunity" },
];

export default function TrendsView({
  platform,
  onPlatformChange,
  onCopyTag,
  onToggleSave,
  savedTagSet,
  onToast,
}: {
  platform: Platform;
  onPlatformChange: (p: Platform) => void;
  onCopyTag: (tag: string) => void;
  onToggleSave: (tag: RankedTag) => void;
  savedTagSet: Set<string>;
  onToast: (msg: string) => void;
}) {
  const [category, setCategory] = useState<Category | "all">("all");
  const [sort, setSort] = useState<TrendSort>("fastest");
  const [platformFilter, setPlatformFilter] = useState<Platform | "all">(platform);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [updated, setUpdated] = useState("");

  useEffect(() => {
    const id = setTimeout(() => {
      const d = new Date(Date.now() - 12 * 60000);
      setUpdated(
        d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false })
      );
    }, 0);
    return () => clearTimeout(id);
  }, []);

  const rows = useMemo(
    () => getTrending({ platform: platformFilter, category, sort }),
    [platformFilter, category, sort]
  );
  const topics = useMemo(() => getTopics(category).slice(0, 8), [category]);

  const fakeToggleSave = (tag: string) => {
    const rec = CORPUS.find((r) => r.tag === tag);
    if (!rec) return;
    onToggleSave({
      tag: rec.tag,
      score: 75,
      relevance: 60,
      momentum: rec.momentum,
      momentum7: rec.momentum7,
      competition: rec.competition,
      demand: "Medium",
      status: "Stable",
      reach: { label: "Solid", low: 1000, high: 2000 },
      audienceFit: "",
      reason: "",
      why: "",
      spark: [],
      category: rec.category,
      secondary: rec.secondary,
      volume: rec.volume,
      matched: [],
    } as RankedTag);
  };

  return (
    <>
      <div className="hero" style={{ paddingBottom: 20 }}>
        <div className="hero-eyebrow">
          <span className="dot" />
          <span className="section-label">Trend signals</span>
        </div>
        <h1>Trends</h1>
        <p className="lede">
          What is gaining momentum across platforms right now. Sort by the dimension you optimize
          for, then move tags straight into your set.
        </p>
      </div>

      <Reveal>
        <section aria-label="Rising topics" style={{ marginBottom: 26 }}>
          <div className="panel" style={{ padding: "16px 20px 6px" }}>
            <div style={{ display: "flex", alignItems: "baseline", gap: 10, marginBottom: 4 }}>
              <span className="section-label">Rising topics</span>
              <span className="updated-note" style={{ marginLeft: "auto" }}>
                <span className="dot" /> Updated {updated || "09:29"}
              </span>
            </div>
            <div className="topic-grid">
              {topics.map((t) => (
                <div className="topic-row" key={t.label}>
                  <span className="t-label">{t.label}</span>
                  <DeltaText value={t.momentum} />
                  <button
                    className="t-rel"
                    onClick={() => {
                      navigator.clipboard?.writeText(`#${t.relatedTag}`).catch(() => {});
                      onToast(`Copied #${t.relatedTag}`);
                    }}
                    title={`Copy #${t.relatedTag}`}
                  >
                    #{t.relatedTag}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>
      </Reveal>

      <Reveal delay={60}>
        <section aria-label="Trending hashtags">
          <div className="panel">
            <div className="filters-bar">
              <div className="fgroup">
                <span className="flabel">Platform</span>
                <div className="seg" style={{ minWidth: 0 }}>
                  <button
                    className={platformFilter === "all" ? "active" : ""}
                    onClick={() => setPlatformFilter("all")}
                  >
                    All
                  </button>
                  {ALL_PLATFORMS.map((p) => (
                    <button
                      key={p}
                      className={platformFilter === p ? "active" : ""}
                      onClick={() => setPlatformFilter(p)}
                    >
                      {PLATFORM_LABEL[p]}
                    </button>
                  ))}
                </div>
              </div>
              <div className="fgroup" style={{ maxWidth: "100%", overflowX: "auto" }}>
                <span className="flabel">Category</span>
                <button className={`chip ${category === "all" ? "active" : ""}`} onClick={() => setCategory("all")}>
                  All
                </button>
                {ALL_CATEGORIES.map((c) => (
                  <button
                    key={c}
                    className={`chip ${category === c ? "active" : ""}`}
                    onClick={() => setCategory(c)}
                  >
                    {CATEGORY_LABEL[c]}
                  </button>
                ))}
              </div>
            </div>
            <div className="filters-bar" style={{ borderTop: 0 }}>
              <div className="fgroup">
                <span className="flabel">Sort</span>
                <div className="seg" style={{ flexWrap: "wrap" }}>
                  {SORTS.map((s) => (
                    <button key={s.id} className={sort === s.id ? "active" : ""} onClick={() => setSort(s.id)}>
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
              <span className="spacer" />
              <span className="results-stats">{rows.length} TAGS</span>
            </div>

            {rows.length === 0 ? (
              <div className="empty-state">
                <h3>Nothing matches these filters.</h3>
                <p>Try a different platform or category combination.</p>
              </div>
            ) : (
              <div className="table-scroll">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th style={{ width: 34 }}>#</th>
                      <th>Hashtag</th>
                      <th>Category</th>
                      <th>14 day trend</th>
                      <th className="num">Volume</th>
                      <th className="num">24h</th>
                      <th>Competition</th>
                      <th className="num">Opportunity</th>
                      <th style={{ width: 76 }}></th>
                    </tr>
                  </thead>
                  <tbody key={`${platformFilter}-${category}-${sort}`}>
                    {rows.slice(0, 24).map((r, i) => {
                      const isSaved = savedTagSet.has(r.rec.tag);
                      const open = expanded === r.rec.tag;
                      return (
                        <Fragment key={r.rec.tag}>
                          <tr onClick={() => setExpanded(open ? null : r.rec.tag)} aria-expanded={open}>
                            <td className="mono faint" style={{ fontSize: 11 }}>
                              {String(i + 1).padStart(2, "0")}
                            </td>
                            <td>
                              <HashTag tag={r.rec.tag} />
                            </td>
                            <td className="meta">{CATEGORY_LABEL[r.rec.category]}</td>
                            <td>
                              <span className={`spark-cell s-${r.status.toLowerCase()}`}>
                                <Sparkline points={r.spark} width={92} height={24} />
                              </span>
                            </td>
                            <td className="num">{fmtCount(r.rec.volume)}</td>
                            <td className="num">
                              <DeltaText value={r.rec.momentum} />
                            </td>
                            <td>{r.rec.competition}</td>
                            <td className="num" style={{ fontWeight: 650 }}>{r.score}</td>
                            <td>
                              <span style={{ display: "inline-flex", gap: 2 }} onClick={(e) => e.stopPropagation()}>
                                <button
                                  className="btn-icon btn"
                                  title={isSaved ? "Remove from saved" : "Save tag"}
                                  onClick={() => fakeToggleSave(r.rec.tag)}
                                  aria-label={isSaved ? `Remove ${r.rec.tag} from saved` : `Save ${r.rec.tag}`}
                                >
                                  <IconBookmark size={13} filled={isSaved} />
                                </button>
                                <button
                                  className="btn-icon btn"
                                  title="Copy"
                                  onClick={() => onCopyTag(r.rec.tag)}
                                  aria-label={`Copy ${r.rec.tag}`}
                                >
                                  <IconCopy size={13} />
                                </button>
                              </span>
                            </td>
                          </tr>
                          {open && (
                            <tr>
                              <td colSpan={9} className="expand-cell">
                                <div className="expand-grid">
                                  <div>
                                    <div className="metric-k">Status</div>
                                    <div className="metric-v">
                                      <StatusChip status={r.status} momentum={r.rec.momentum} />
                                    </div>
                                  </div>
                                  <div>
                                    <div className="metric-k">Search demand</div>
                                    <div className="metric-v">{r.demand}</div>
                                  </div>
                                  <div>
                                    <div className="metric-k">7 day move</div>
                                    <div className="metric-v">
                                      {r.rec.momentum7 > 0 ? "+" : ""}
                                      {r.rec.momentum7}%
                                    </div>
                                  </div>
                                  <div>
                                    <div className="metric-k">Reach potential</div>
                                    <div className="metric-v">
                                      {fmtImpressions(r.reach.low)} to {fmtImpressions(r.reach.high)} / wk
                                    </div>
                                  </div>
                                  <div>
                                    <div className="metric-k">Strongest on</div>
                                    <div className="metric-v">
                                      {r.rec.platforms.map((p) => PLATFORM_LABEL[p]).join(", ")}
                                    </div>
                                  </div>
                                  <div style={{ gridColumn: "span 3" }}>
                                    <div className="metric-k">Note</div>
                                    <div className="metric-v" style={{ fontWeight: 450, color: "var(--mut)" }}>
                                      {r.rec.note ?? `Currently ${r.status.toLowerCase()} in the ${CATEGORY_LABEL[r.rec.category].toLowerCase()} cluster with ${r.rec.competition.toLowerCase()} competition.`}
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </section>
      </Reveal>
    </>
  );
}
