"use client";

import { Analysis, PLATFORM_GUIDE, Platform, RankedTag, STRATEGY_LABEL, Strategy } from "@/lib/hashpilot/types";
import { fmtCount, fmtImpressions } from "@/lib/hashpilot/engine";
import { AnimatedNumber, Sparkline, StatusChip } from "@/components/hashpilot/ui";
import {
  IconBookmark,
  IconCopy,
  IconPlus,
  IconCheck,
  IconReplace,
} from "@/components/hashpilot/icons";

export default function ResultsPanel({
  analysis,
  analyzing,
  step,
  stale,
  rankKey,
  selected,
  savedTagSet,
  resultsRef,
  platform,
  strategy,
  onRegenerate,
  onReplace,
  onToggleSelect,
  onCopyTag,
  onToggleSave,
  expanded,
  onExpand,
}: {
  analysis: Analysis | null;
  analyzing: boolean;
  step: number;
  stale: boolean;
  rankKey: number;
  selected: string[];
  savedTagSet: Set<string>;
  resultsRef: React.RefObject<HTMLDivElement | null>;
  platform: Platform;
  strategy: Strategy;
  onRegenerate: () => void;
  onReplace: (tag: string) => void;
  onToggleSelect: (tag: string) => void;
  onCopyTag: (tag: string) => void;
  onToggleSave: (tag: RankedTag) => void;
  expanded: string | null;
  onExpand: (tag: string | null) => void;
}) {
  const guide = PLATFORM_GUIDE[platform];

  return (
    <div className="panel" ref={resultsRef} style={{ scrollMarginTop: 74 }}>
      {analyzing ? (
        <AnalyzingState step={step} />
      ) : !analysis ? (
        <EmptyState />
      ) : (
        <>
          <div className="results-head">
            <span className="section-label">Recommendations</span>
            <span className="results-stats">
              {analysis.tags.length} TAGS · AVG {analysis.stats.average} · {analysis.stats.rising} RISING /{" "}
              {analysis.stats.stable} STABLE{analysis.stats.falling ? ` / ${analysis.stats.falling} FALLING` : ""}
            </span>
            <span className="spacer" />
            {stale && <span className="stale-note">Caption edited. Analyze again to refresh.</span>}
            <button className="btn btn-sm" onClick={onRegenerate} title="Keep the top 3, rotate the rest">
              <IconReplace size={13} />
              Regenerate
            </button>
          </div>

          <ul className="tag-list" key={`${rankKey}-${strategy}-${platform}`}>
            {analysis.tags.map((t, i) => (
              <Row
                key={t.tag}
                tag={t}
                index={i}
                isSelected={selected.includes(t.tag)}
                isSaved={savedTagSet.has(t.tag)}
                isExpanded={expanded === t.tag}
                onToggleSelect={onToggleSelect}
                onCopyTag={onCopyTag}
                onToggleSave={onToggleSave}
                onReplace={onReplace}
                onExpand={onExpand}
              />
            ))}
          </ul>

          <div
            className="results-head"
            style={{ borderTop: "1px solid var(--line)", borderBottom: 0 }}
          >
            <span className="results-stats">
              {STRATEGY_LABEL[strategy].title.toUpperCase()} MIX FOR {PLATFORM_GUIDE[platform].rec} TAG SLOTS
            </span>
            <span className="spacer" />
            <span className="meta">{guide.note}</span>
          </div>
        </>
      )}
    </div>
  );
}

function AnalyzingState({ step }: { step: number }) {
  return (
    <div className="analyzing" aria-live="polite">
      <div className="section-label" style={{ marginBottom: 10 }}>
        Working
      </div>
      <div className="analyzing-line">{["Reading your caption", "Matching topic signals", "Scanning 14 day momentum", "Ranking by opportunity"][step] ?? "Reading your caption"}...</div>
      <div className="analyzing-sub">
        STEP {step + 1} OF 4 · {Math.round(((step + 1) / 4) * 100)}%
      </div>
      <div className="progress" role="progressbar" aria-valuenow={((step + 1) / 4) * 100} aria-valuemin={0} aria-valuemax={100}>
        <i style={{ width: `${((step + 1) / 4) * 100}%` }} />
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="empty-state">
      <div className="section-label" style={{ marginBottom: 10 }}>
        Results
      </div>
      <h3>Run an analysis to see ranked tags.</h3>
      <p>
        Every recommendation is scored on what actually moves distribution, then explained in plain
        language. Change the strategy to reshape the mix.
      </p>
      <ul className="def-list">
        <li>
          <span className="def-k">Content analysis</span>
          <span>Topic words from your caption are matched against active hashtag conversations.</span>
        </li>
        <li>
          <span className="def-k">Trend signal</span>
          <span>24 hour and 7 day momentum show whether a tag is rising, stable or cooling.</span>
        </li>
        <li>
          <span className="def-k">Competition</span>
          <span>How hard it is to rank against the posts already using the tag today.</span>
        </li>
        <li>
          <span className="def-k">Reach potential</span>
          <span>Estimated weekly impressions for a post that ranks mid-feed on this tag.</span>
        </li>
      </ul>
    </div>
  );
}

function Row({
  tag,
  index,
  isSelected,
  isSaved,
  isExpanded,
  onToggleSelect,
  onCopyTag,
  onToggleSave,
  onReplace,
  onExpand,
}: {
  tag: RankedTag;
  index: number;
  isSelected: boolean;
  isSaved: boolean;
  isExpanded: boolean;
  onToggleSelect: (tag: string) => void;
  onCopyTag: (tag: string) => void;
  onToggleSave: (tag: RankedTag) => void;
  onReplace: (tag: string) => void;
  onExpand: (tag: string | null) => void;
}) {
  return (
    <li
      className={`tag-row ${isSelected ? "selected" : ""}`}
      style={{ ["--i" as string]: index }}
      onClick={() => onExpand(isExpanded ? null : tag.tag)}
    >
      <div className={`score-block ${tag.score >= 85 ? "hot" : ""}`}>
        <span className="score-num">
          <AnimatedNumber value={tag.score} />
          <span className="of">/100</span>
        </span>
      </div>

      <div className="tag-main">
        <div className="tag-name-line">
          <span className="tag-name">
            <span className="hash">#</span>
            {tag.tag}
          </span>
          <StatusChip status={tag.status} momentum={tag.momentum} />
          <span className="meta" style={{ fontSize: 12 }}>
            {fmtCount(tag.volume)} posts / mo
          </span>
        </div>
        <p className="tag-reason">{tag.reason}</p>
        <div className="tag-meta">
          <span>
            DEMAND <b>{tag.demand}</b>
          </span>
          <span className="sep">·</span>
          <span>
            COMPETITION <b>{tag.competition}</b>
          </span>
          <span className="sep">·</span>
          <span>
            RELEVANCE <b>{tag.relevance}%</b>
          </span>
          <span className="sep">·</span>
          <span>
            REACH <b>{tag.reach.label}</b>
          </span>
        </div>

        {isExpanded && (
          <div className="tag-detail" onClick={(e) => e.stopPropagation()}>
            <div>
              <div className="metric-grid">
                <div>
                  <div className="metric-k">Search demand</div>
                  <div className="metric-v">{tag.demand}</div>
                </div>
                <div>
                  <div className="metric-k">Competition</div>
                  <div className="metric-v">{tag.competition}</div>
                </div>
                <div>
                  <div className="metric-k">Momentum 24h</div>
                  <div className="metric-v">
                    {tag.momentum > 0 ? "+" : ""}
                    {tag.momentum}%
                  </div>
                </div>
                <div>
                  <div className="metric-k">Momentum 7d</div>
                  <div className="metric-v">
                    {tag.momentum7 > 0 ? "+" : ""}
                    {tag.momentum7}%
                  </div>
                </div>
                <div>
                  <div className="metric-k">Content relevance</div>
                  <div className="metric-v">{tag.relevance}%</div>
                </div>
                <div>
                  <div className="metric-k">Reach potential</div>
                  <div className="metric-v">
                    {fmtImpressions(tag.reach.low)} to {fmtImpressions(tag.reach.high)}
                  </div>
                </div>
              </div>
              <div className="why-label">Why this tag</div>
              <p className="why-text">{tag.why}</p>
              <div style={{ marginTop: 12, display: "flex", gap: 6, flexWrap: "wrap" }}>
                <button className="btn btn-sm" onClick={() => onCopyTag(tag.tag)}>
                  <IconCopy size={12} /> Copy
                </button>
                <button className="btn btn-sm" onClick={() => onReplace(tag.tag)}>
                  <IconReplace size={12} /> Replace
                </button>
                <button className="btn btn-sm" onClick={() => onToggleSave(tag)}>
                  <IconBookmark size={12} filled={isSaved} /> {isSaved ? "Saved" : "Save"}
                </button>
              </div>
            </div>
            <div className={`spark-cell s-${tag.status.toLowerCase()}`}>
              <Sparkline points={tag.spark} width={172} height={44} />
              <div className="spark-caption">14 day relative interest</div>
            </div>
          </div>
        )}
      </div>

      <div className="tag-actions" onClick={(e) => e.stopPropagation()}>
        <button
          className={`btn-icon btn ${isSelected ? "is-on" : ""}`}
          onClick={() => onToggleSelect(tag.tag)}
          title={isSelected ? "Remove from set" : "Add to set"}
          aria-label={isSelected ? `Remove ${tag.tag} from set` : `Add ${tag.tag} to set`}
        >
          {isSelected ? <IconCheck size={14} /> : <IconPlus size={14} />}
        </button>
        <button
          className="btn-icon btn"
          onClick={() => onToggleSave(tag)}
          title={isSaved ? "Remove from saved" : "Save tag"}
          aria-label={isSaved ? `Remove ${tag.tag} from saved` : `Save ${tag.tag}`}
        >
          <IconBookmark size={14} filled={isSaved} />
        </button>
        <button className="btn-icon btn" onClick={() => onCopyTag(tag.tag)} title="Copy" aria-label={`Copy ${tag.tag}`}>
          <IconCopy size={14} />
        </button>
        <button className="btn-icon btn" onClick={() => onReplace(tag.tag)} title="Replace with alternative" aria-label={`Replace ${tag.tag}`}>
          <IconReplace size={14} />
        </button>
      </div>
    </li>
  );
}
