// Minimal custom icon set. 16px grid, 1.5 stroke, no decoration.
// Deliberately not Lucide: fewer glyphs, flatter geometry, aligned to the
// editorial layout rather than a generic SaaS look.

interface IconProps {
  size?: number;
  className?: string;
}

function base(size?: number) {
  return {
    width: size ?? 16,
    height: size ?? 16,
    viewBox: "0 0 16 16",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.5,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };
}

export function IconArrowUpRight({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M4.5 11.5 11.5 4.5M6 4.5h5.5V10" />
    </svg>
  );
}

export function IconArrowDownRight({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M4.5 4.5l7 7M11.5 6v5.5H6" />
    </svg>
  );
}

export function IconDash({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M4 8h8" />
    </svg>
  );
}

export function IconCopy({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <rect x="5.5" y="5.5" width="8" height="8" rx="1.5" />
      <path d="M10.5 3.5h-7a1 1 0 0 0-1 1v7" />
    </svg>
  );
}

export function IconReplace({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M12.5 6.5a4.7 4.7 0 0 0-8.6-1.2M3.5 3v2.5H6" />
      <path d="M3.5 9.5a4.7 4.7 0 0 0 8.6 1.2M12.5 13v-2.5H10" />
    </svg>
  );
}

export function IconBookmark({ size, className, filled }: IconProps & { filled?: boolean }) {
  return (
    <svg {...base(size)} className={className} fill={filled ? "currentColor" : "none"}>
      <path d="M4.5 3h7a.5.5 0 0 1 .5.5V13L8 10.6 4 13V3.5a.5.5 0 0 1 .5-.5Z" />
    </svg>
  );
}

export function IconPlus({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M8 3.5v9M3.5 8h9" />
    </svg>
  );
}

export function IconCheck({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M3 8.5 6.5 12 13 4.5" />
    </svg>
  );
}

export function IconX({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M4 4l8 8M12 4l-8 8" />
    </svg>
  );
}

export function IconChevronDown({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M4 6l4 4 4-4" />
    </svg>
  );
}

export function IconChevronLeft({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M10 3.5 5.5 8l4.5 4.5" />
    </svg>
  );
}

export function IconChevronRight({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M6 3.5 10.5 8 6 12.5" />
    </svg>
  );
}

export function IconTrash({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5 5 13h6l.5-8.5M6.7 7v3.5M9.3 7v3.5" />
    </svg>
  );
}

export function IconClock({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <circle cx="8" cy="8" r="5.5" />
      <path d="M8 5v3.2l2 1.3" />
    </svg>
  );
}

export function IconTrend({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M2 11.5 6 7l2.5 2.5L14 4" />
      <path d="M10.5 4H14v3.5" />
    </svg>
  );
}

export function IconAnalyze({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M2.5 13.5 6 9l2.5 2L13.5 4" />
      <circle cx="11" cy="11.5" r="0.5" />
      <path d="M2.5 6.5h3M2.5 9.5h2" />
    </svg>
  );
}

export function IconBookmarkNav({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <path d="M4.5 2.5h7a.5.5 0 0 1 .5.5v10L8 10.6 4 13V3a.5.5 0 0 1 .5-.5Z" />
    </svg>
  );
}

export function IconGrip({ size, className }: IconProps) {
  return (
    <svg {...base(size)} className={className}>
      <circle cx="6" cy="4.5" r="0.6" fill="currentColor" />
      <circle cx="10" cy="4.5" r="0.6" fill="currentColor" />
      <circle cx="6" cy="8" r="0.6" fill="currentColor" />
      <circle cx="10" cy="8" r="0.6" fill="currentColor" />
      <circle cx="6" cy="11.5" r="0.6" fill="currentColor" />
      <circle cx="10" cy="11.5" r="0.6" fill="currentColor" />
    </svg>
  );
}
