"use client";

import { useState } from "react";
import {
  CATEGORY_LABEL,
  Collection,
  PLATFORM_LABEL,
  SavedTag,
  TagSet,
} from "@/lib/hashpilot/types";
import { useReveal } from "@/components/hashpilot/ui";
import { IconBookmark, IconCopy, IconPlus, IconTrash } from "@/components/hashpilot/icons";

export default function SavedView({
  savedTags,
  sets,
  collections,
  onRemoveSaved,
  onCopyTag,
  onCopySet,
  onDeleteSet,
  onAddToSet,
  onCreateCollection,
  onToast,
}: {
  savedTags: SavedTag[];
  sets: TagSet[];
  collections: Collection[];
  onRemoveSaved: (tag: string) => void;
  onCopyTag: (tag: string) => void;
  onCopySet: (set: TagSet) => void;
  onDeleteSet: (id: string) => void;
  onAddToSet: (tag: string, setId: string) => void;
  onCreateCollection: (name: string) => void;
  onToast: (msg: string) => void;
}) {
  const [openSet, setOpenSet] = useState<string | null>(null);
  const [newCollection, setNewCollection] = useState("");
  const [addToSetFor, setAddToSetFor] = useState<string | null>(null);
  const pageRef = useReveal<HTMLDivElement>(0.03);

  const fmtDate = (ts: number) =>
    new Date(ts).toLocaleDateString("en-US", { month: "short", day: "numeric" });

  const collectionName = (id: string) => collections.find((c) => c.id === id)?.name ?? "My tags";

  return (
    <div ref={pageRef} className="reveal in">
      <div className="hero" style={{ paddingBottom: 20 }}>
        <div className="hero-eyebrow">
          <span className="section-label">Library</span>
        </div>
        <h1>Saved</h1>
        <p className="lede">
          Tags and sets you keep coming back to. Everything stays on this device.
        </p>
      </div>

      {/* Saved hashtags */}
      <section aria-label="Saved hashtags" style={{ marginBottom: 26 }}>
        <div className="panel">
          <div className="results-head">
            <span className="section-label">Saved hashtags</span>
            <span className="results-stats">{savedTags.length} TAGS</span>
          </div>
          {savedTags.length === 0 ? (
            <div className="empty-state">
              <h3>No saved tags yet.</h3>
              <p>Use the bookmark action on any recommendation or trend row. Saved tags keep their score snapshot so you can compare later.</p>
            </div>
          ) : (
            savedTags.map((s) => (
              <div className="srow" key={s.tag}>
                <span className="s-name">
                  <span className="hash">#</span>
                  {s.tag}
                </span>
                <span className="s-metrics">
                  SCORE {s.score} · {s.momentum > 0 ? "+" : ""}
                  {s.momentum}% · {s.competition.toUpperCase()} COMP · {CATEGORY_LABEL[s.category].toUpperCase()}
                </span>
                <span className="s-metrics" style={{ color: "var(--mut)" }}>
                  SAVED {fmtDate(s.savedAt)} · {PLATFORM_LABEL[s.platform]}
                </span>
                <span className="spacer" />
                <button className="btn-icon btn" onClick={() => onCopyTag(s.tag)} title="Copy" aria-label={`Copy ${s.tag}`}>
                  <IconCopy size={14} />
                </button>
                <button
                  className="btn-icon btn"
                  onClick={() => setAddToSetFor(addToSetFor === s.tag ? null : s.tag)}
                  title="Add to set"
                  aria-label={`Add ${s.tag} to a set`}
                >
                  <IconPlus size={14} />
                </button>
                <button
                  className="btn-icon btn"
                  onClick={() => onRemoveSaved(s.tag)}
                  title="Remove"
                  aria-label={`Remove ${s.tag} from saved`}
                >
                  <IconBookmark size={14} filled />
                </button>
              </div>
            ))
          )}
          {addToSetFor &&
            (sets.length ? (
              <div className="save-form" style={{ padding: "10px 18px 14px", borderTop: "1px solid var(--line)" }}>
                <span className="meta">Add #{addToSetFor} to:</span>
                {sets.slice(0, 5).map((set) => (
                  <button
                    key={set.id}
                    className="btn btn-sm"
                    onClick={() => {
                      onAddToSet(addToSetFor, set.id);
                      setAddToSetFor(null);
                    }}
                  >
                    {set.name}
                  </button>
                ))}
              </div>
            ) : (
              <div className="save-form" style={{ padding: "10px 18px 14px", borderTop: "1px solid var(--line)" }}>
                <span className="meta">Create a set from the tray on the Analyze page first.</span>
              </div>
            ))}
        </div>
      </section>

      {/* Saved sets */}
      <section aria-label="Saved sets" style={{ marginBottom: 26 }}>
        <div className="panel">
          <div className="results-head">
            <span className="section-label">Saved sets</span>
            <span className="results-stats">{sets.length} SETS</span>
          </div>
          {sets.length === 0 ? (
            <div className="empty-state">
              <h3>No sets yet.</h3>
              <p>Build a selection on the Analyze page, then use Save as set in the tray at the bottom.</p>
            </div>
          ) : (
            sets.map((set) => (
              <div key={set.id} style={{ borderTop: "1px solid var(--line)" }}>
                <div className="srow" style={{ cursor: "pointer" }} onClick={() => setOpenSet(openSet === set.id ? null : set.id)}>
                  <span className="s-name">{set.name}</span>
                  <span className="s-metrics">
                    {set.tags.length} TAGS · {PLATFORM_LABEL[set.platform].toUpperCase()} · {collectionName(set.collectionId).toUpperCase()}
                  </span>
                  <span className="s-metrics" style={{ color: "var(--mut)" }}>CREATED {fmtDate(set.createdAt)}</span>
                  <span className="spacer" />
                  <button
                    className="btn-icon btn"
                    onClick={(e) => {
                      e.stopPropagation();
                      onCopySet(set);
                    }}
                    title="Copy all tags"
                    aria-label={`Copy all tags in ${set.name}`}
                  >
                    <IconCopy size={14} />
                  </button>
                  <button
                    className="btn-icon btn"
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteSet(set.id);
                    }}
                    title="Delete set"
                    aria-label={`Delete ${set.name}`}
                  >
                    <IconTrash size={14} />
                  </button>
                </div>
                {openSet === set.id && (
                  <div className="set-chips">
                    {set.tags.map((t) => (
                      <span className="tray-chip" key={t}>
                        <span className="hash">#</span>
                        {t}
                        <button onClick={() => onCopyTag(t)} aria-label={`Copy ${t}`}>
                          <IconCopy size={11} />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </section>

      {/* Collections */}
      <section aria-label="Collections">
        <div className="panel" style={{ paddingBottom: 6 }}>
          <div className="results-head">
            <span className="section-label">Collections</span>
            <span className="results-stats">{collections.length} GROUPS</span>
          </div>
          {collections.length === 0 ? (
            <div className="empty-state" style={{ paddingBottom: 20 }}>
              <h3>Group sets into collections.</h3>
              <p>One collection per client, campaign or content pillar keeps sets findable later.</p>
            </div>
          ) : (
            collections.map((c) => {
              const count = sets.filter((s) => s.collectionId === c.id).length;
              return (
                <div className="srow" key={c.id}>
                  <span className="s-name">{c.name}</span>
                  <span className="s-metrics">
                    {count} {count === 1 ? "SET" : "SETS"}
                  </span>
                  <span className="spacer" />
                  <span className="s-metrics">{fmtDate(c.createdAt)}</span>
                </div>
              );
            })
          )}
          <div className="save-form" style={{ padding: "10px 18px 14px", borderTop: "1px solid var(--line)" }}>
            <input
              type="text"
              placeholder="New collection, e.g. Client: Norr Studio"
              value={newCollection}
              onChange={(e) => setNewCollection(e.target.value)}
              maxLength={40}
              onKeyDown={(e) => {
                if (e.key === "Enter" && newCollection.trim()) {
                  onCreateCollection(newCollection.trim());
                  setNewCollection("");
                }
              }}
            />
            <button
              className="btn btn-sm"
              disabled={!newCollection.trim()}
              onClick={() => {
                onCreateCollection(newCollection.trim());
                setNewCollection("");
              }}
            >
              Create
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
