/* ============================================================
   Tagline · mock trend dataset
   Structure mirrors what a live trend API would return, so the
   engine in app.js can later read from a real endpoint.
   ============================================================ */

const CATEGORIES = [
  'Travel', 'Food', 'Fashion', 'Fitness',
  'Beauty', 'Business', 'Technology', 'Lifestyle'
];

const PLATFORMS = [
  { id: 'instagram', label: 'Instagram', tagLimit: 30, captionLimit: 2200 },
  { id: 'tiktok',    label: 'TikTok',    tagLimit: 20, captionLimit: 2200 },
  { id: 'youtube',   label: 'YouTube',   tagLimit: 15, captionLimit: 5000 },
  { id: 'linkedin',  label: 'LinkedIn',  tagLimit:  5, captionLimit: 3000 }
];

/*
  Each tag:
    t     tag name (no #)
    c     primary category
    kw    keywords that indicate content relevance
    dem   search demand          High | Medium | Low
    comp  competition, 0-100
    mom   7-day momentum, %
    volN  posts using the tag (numeric, for sorting)
    fit   optional platform overrides { instagram: 88, ... }
*/
const TAGS = [
  /* ---- Travel ---- */
  { t: 'TokyoFood',         c: 'Travel', kw: ['tokyo','japan','food','eat','sushi','ramen','izakaya','dinner','restaurant','travel'], dem: 'High',   comp: 48, mom:  34, volN: 1800000 },
  { t: 'JapanTravel',       c: 'Travel', kw: ['japan','tokyo','kyoto','osaka','travel','trip','vacation','asia'],                     dem: 'High',   comp: 62, mom:  21, volN: 4600000 },
  { t: 'TokyoGuide',        c: 'Travel', kw: ['tokyo','guide','itinerary','japan','tips','city','neighborhood'],                      dem: 'Medium', comp: 31, mom:   8, volN:  640000 },
  { t: 'TokyoCafe',         c: 'Travel', kw: ['tokyo','cafe','coffee','kissaten','brunch','latte','shop','coffee shop'],              dem: 'Medium', comp: 27, mom:  12, volN:  380000 },
  { t: 'HiddenJapan',       c: 'Travel', kw: ['hidden','secret','local','gem','japan','untouristy','spot'],                           dem: 'Low',    comp: 19, mom:  17, volN:  210000 },
  { t: 'SlowTravel',        c: 'Travel', kw: ['slow','stay','weeks','local','mindful','longer','unhurried'],                          dem: 'Low',    comp: 14, mom:   9, volN:   96000 },
  { t: 'CityBreak',         c: 'Travel', kw: ['city','weekend','urban','short trip','hours','downtown'],                              dem: 'Medium', comp: 38, mom:   5, volN: 1100000 },
  { t: 'TravelReel',        c: 'Travel', kw: ['reel','video','cinematic','footage','vlog','clip','edit'],                             dem: 'High',   comp: 71, mom:  26, volN: 3200000 },
  { t: 'StreetPhotography', c: 'Travel', kw: ['street','photography','photo','camera','candid','shots','walk'],                       dem: 'Medium', comp: 52, mom:  11, volN: 2700000 },
  { t: 'ArchitectureLover', c: 'Travel', kw: ['architecture','building','design','concrete','modern','facade'],                       dem: 'Medium', comp: 44, mom:   7, volN: 1400000 },
  { t: 'JapanFood',         c: 'Travel', kw: ['japanese','food','japan','sushi','ramen','cuisine','eats'],                            dem: 'High',   comp: 57, mom:  18, volN: 2200000 },
  { t: 'Wanderlust',        c: 'Travel', kw: ['travel','adventure','explore','trip','wander','journey'],                              dem: 'High',   comp: 84, mom:   3, volN:18000000, fit: { linkedin: 22 } },

  /* ---- Food ---- */
  { t: 'PastaNight',        c: 'Food', kw: ['pasta','italian','dinner','homemade','noodles','carbonara','sauce'],        dem: 'Medium', comp: 33, mom:  14, volN:  520000 },
  { t: 'HomeBaking',        c: 'Food', kw: ['baking','bake','bread','cake','cookies','oven','homemade','flour'],         dem: 'Medium', comp: 36, mom:  16, volN:  890000 },
  { t: 'SourdoughClub',     c: 'Food', kw: ['sourdough','starter','bread','loaf','crumb','ferment','bake'],              dem: 'Low',    comp: 21, mom:  11, volN:  310000 },
  { t: 'CoffeeLover',       c: 'Food', kw: ['coffee','espresso','latte','brew','barista','cafe','caffeine'],             dem: 'High',   comp: 58, mom:   9, volN: 6100000 },
  { t: 'BrunchDates',       c: 'Food', kw: ['brunch','weekend','eggs','pancakes','cafe','friends','mimosa'],             dem: 'Medium', comp: 41, mom:   7, volN:  740000 },
  { t: 'MealPrep',          c: 'Food', kw: ['meal prep','lunch','healthy','weekly','containers','prep','sunday'],        dem: 'Medium', comp: 45, mom:  12, volN:  980000 },
  { t: 'StreetFood',        c: 'Food', kw: ['street food','market','vendor','bites','stall','eats','cheap'],             dem: 'High',   comp: 63, mom:  22, volN: 2900000 },
  { t: 'RamenLover',        c: 'Food', kw: ['ramen','noodles','broth','japanese','bowl','slurp','tonkotsu'],             dem: 'Medium', comp: 35, mom:  19, volN:  460000 },
  { t: 'WineTasting',       c: 'Food', kw: ['wine','vineyard','tasting','glass','sommelier','cellar','pour'],            dem: 'Low',    comp: 24, mom:   4, volN:  350000 },
  { t: 'VeganRecipes',      c: 'Food', kw: ['vegan','plant based','recipe','vegetarian','bowl','healthy','dairy free'],  dem: 'Medium', comp: 49, mom:  15, volN: 1600000 },
  { t: 'FoodPhotography',   c: 'Food', kw: ['food photography','photo','styling','flatlay','shoot','light'],             dem: 'Medium', comp: 47, mom:  10, volN: 1300000 },
  { t: 'HighProtein',       c: 'Food', kw: ['protein','macros','gym food','recipe','fitness meal','chicken','gains'],    dem: 'Medium', comp: 29, mom:  28, volN:  540000 },

  /* ---- Fashion ---- */
  { t: 'OOTD',              c: 'Fashion', kw: ['outfit','wear','style','look','dressed','fit check','wearing'],        dem: 'High',   comp: 78, mom:   6, volN:12000000 },
  { t: 'StreetStyle',       c: 'Fashion', kw: ['street','style','fashion','city','candid','outfit','sidewalk'],        dem: 'High',   comp: 66, mom:  13, volN: 3400000 },
  { t: 'VintageFashion',    c: 'Fashion', kw: ['vintage','retro','secondhand','90s','archive','era'],                  dem: 'Medium', comp: 43, mom:  17, volN: 1100000 },
  { t: 'CapsuleWardrobe',   c: 'Fashion', kw: ['capsule','wardrobe','minimal','basics','essentials','closet'],         dem: 'Low',    comp: 22, mom:  12, volN:  260000 },
  { t: 'ThriftFinds',       c: 'Fashion', kw: ['thrift','thrifted','haul','secondhand','charity shop','vintage'],      dem: 'Medium', comp: 39, mom:  24, volN:  830000 },
  { t: 'SneakerHead',       c: 'Fashion', kw: ['sneakers','shoes','kicks','drop','collection','grails'],               dem: 'Medium', comp: 55, mom:   8, volN: 2100000 },
  { t: 'SlowFashion',       c: 'Fashion', kw: ['sustainable','ethical','slow','quality','made to last','fabric'],      dem: 'Low',    comp: 16, mom:  10, volN:  140000 },
  { t: 'DenimStyle',        c: 'Fashion', kw: ['denim','jeans','jacket','raw','fit','indigo'],                         dem: 'Medium', comp: 34, mom:   6, volN:  620000 },
  { t: 'OutfitInspo',       c: 'Fashion', kw: ['outfit','inspo','inspiration','ideas','styling','combine'],            dem: 'High',   comp: 69, mom:   9, volN: 4800000 },
  { t: 'RunwayFashion',     c: 'Fashion', kw: ['runway','fashion week','show','designer','couture','collection'],      dem: 'Medium', comp: 51, mom:   5, volN: 1200000 },

  /* ---- Fitness ---- */
  { t: 'HomeWorkout',       c: 'Fitness', kw: ['home','workout','equipment','bodyweight','living room','session'],     dem: 'Medium', comp: 42, mom:  16, volN: 1500000 },
  { t: 'RunningCommunity',  c: 'Fitness', kw: ['running','run','runner','5k','club','miles','race'],                   dem: 'Medium', comp: 37, mom:  21, volN:  980000 },
  { t: 'StrengthTraining',  c: 'Fitness', kw: ['strength','lifting','weights','gym','barbell','squat','deadlift'],     dem: 'Medium', comp: 48, mom:  13, volN: 1900000 },
  { t: 'MarathonTraining',  c: 'Fitness', kw: ['marathon','half','training','race','long run','plan','miles'],         dem: 'Low',    comp: 26, mom:  18, volN:  420000 },
  { t: 'YogaPractice',      c: 'Fitness', kw: ['yoga','flow','mat','stretch','breath','practice','pose'],              dem: 'High',   comp: 59, mom:   7, volN: 3800000 },
  { t: 'MorningRun',        c: 'Fitness', kw: ['morning','run','sunrise','6am','miles','routine','early'],             dem: 'Low',    comp: 23, mom:  15, volN:  290000 },
  { t: 'HIITWorkout',       c: 'Fitness', kw: ['hiit','interval','cardio','sweat','session','burn','circuit'],         dem: 'Medium', comp: 44, mom:   9, volN:  870000 },
  { t: 'FitnessJourney',    c: 'Fitness', kw: ['progress','journey','transformation','consistency','results','weeks'], dem: 'High',   comp: 72, mom:   6, volN: 5200000 },
  { t: 'PullUpProgress',    c: 'Fitness', kw: ['pull up','calisthenics','progression','skills','bar','strict'],        dem: 'Low',    comp: 18, mom:  23, volN:  130000 },
  { t: 'MobilityWork',      c: 'Fitness', kw: ['mobility','hips','shoulders','stretching','recovery','joints'],        dem: 'Low',    comp: 15, mom:  12, volN:  110000 },

  /* ---- Beauty ---- */
  { t: 'SkincareRoutine',   c: 'Beauty', kw: ['skincare','routine','serum','retinol','spf','cleanser','moisturizer'],  dem: 'High',   comp: 61, mom:  14, volN: 2800000 },
  { t: 'SkinBarrier',       c: 'Beauty', kw: ['barrier','ceramides','sensitive','repair','over exfoliated','calm'],    dem: 'Low',    comp: 17, mom:  26, volN:  160000 },
  { t: 'GlowUp',            c: 'Beauty', kw: ['glow','skin','transformation','before after','radiant','weeks'],        dem: 'High',   comp: 74, mom:   8, volN: 4400000 },
  { t: 'MakeupTutorial',    c: 'Beauty', kw: ['makeup','tutorial','look','eyeshadow','wing','blush','how to'],         dem: 'Medium', comp: 56, mom:   5, volN: 1900000 },
  { t: 'CleanBeauty',       c: 'Beauty', kw: ['clean','nontoxic','ingredients','natural','skincare','formula'],        dem: 'Low',    comp: 25, mom:  11, volN:  340000 },
  { t: 'HairCare',          c: 'Beauty', kw: ['hair','shampoo','curls','routine','mask','blowout','scalp'],            dem: 'Medium', comp: 46, mom:   9, volN: 1400000 },
  { t: 'MinimalMakeup',     c: 'Beauty', kw: ['minimal','no makeup','tinted','sheer','effortless','skin tint'],        dem: 'Low',    comp: 21, mom:  18, volN:  230000 },
  { t: 'NailArt',           c: 'Beauty', kw: ['nails','manicure','gel','design','polish','salon','chrome'],            dem: 'Medium', comp: 50, mom:  10, volN: 1700000 },
  { t: 'FragranceFinds',    c: 'Beauty', kw: ['fragrance','perfume','scent','collection','niche','bottle'],            dem: 'Low',    comp: 19, mom:  21, volN:  190000 },
  { t: 'BeautyOnABudget',   c: 'Beauty', kw: ['budget','affordable','drugstore','dupes','cheap finds','under'],        dem: 'Low',    comp: 20, mom:  16, volN:  210000 },

  /* ---- Business ---- */
  { t: 'SmallBusiness',     c: 'Business', kw: ['small business','shop','owner','local','support','store','made'],     dem: 'High',   comp: 68, mom:   9, volN: 7900000 },
  { t: 'FounderLife',       c: 'Business', kw: ['founder','startup','building','ceo','journey','lessons','company'],   dem: 'Medium', comp: 47, mom:  12, volN: 1100000 },
  { t: 'MarketingTips',     c: 'Business', kw: ['marketing','tips','strategy','growth','funnel','ads','audience'],     dem: 'Medium', comp: 52, mom:  13, volN: 1600000 },
  { t: 'PersonalBranding',  c: 'Business', kw: ['personal brand','brand','presence','authority','voice','positioning'],dem: 'Medium', comp: 41, mom:  19, volN:  780000 },
  { t: 'SideHustle',        c: 'Business', kw: ['side hustle','extra income','weekends','second job','evenings'],      dem: 'Medium', comp: 58, mom:  15, volN: 1800000 },
  { t: 'FreelanceLife',     c: 'Business', kw: ['freelance','client','invoice','remote','contract','rates'],           dem: 'Low',    comp: 27, mom:  10, volN:  460000 },
  { t: 'B2BMarketing',      c: 'Business', kw: ['b2b','saas','lead gen','content marketing','pipeline','demand'],      dem: 'Low',    comp: 23, mom:   7, volN:  240000 },
  { t: 'LeadershipLessons', c: 'Business', kw: ['leadership','team','management','culture','delegate','hiring'],       dem: 'Low',    comp: 25, mom:   6, volN:  380000 },
  { t: 'GrowthStrategy',    c: 'Business', kw: ['growth','metrics','retention','scale','experiments','kpi'],           dem: 'Low',    comp: 21, mom:   8, volN:  210000 },
  { t: 'LaunchDay',         c: 'Business', kw: ['launch','launching','product','live','waitlist','ship','release'],    dem: 'Medium', comp: 36, mom:  24, volN:  520000 },

  /* ---- Technology ---- */
  { t: 'TechReview',        c: 'Technology', kw: ['review','tech','gadget','tested','unboxing','verdict','hands on'],   dem: 'Medium', comp: 54, mom:  11, volN: 1300000 },
  { t: 'DeskSetup',         c: 'Technology', kw: ['desk','setup','workspace','monitor','keyboard','office','chair'],    dem: 'Medium', comp: 43, mom:  14, volN:  910000 },
  { t: 'SmartHome',         c: 'Technology', kw: ['smart home','automation','sensors','assistant','lights','hub'],      dem: 'Low',    comp: 28, mom:   9, volN:  470000 },
  { t: 'AppDesign',         c: 'Technology', kw: ['app','design','ui','ux','figma','interface','product','prototype'],  dem: 'Medium', comp: 39, mom:   8, volN:  640000 },
  { t: 'WebDevelopment',    c: 'Technology', kw: ['web dev','code','javascript','frontend','build','programming','ship'],dem: 'Medium', comp: 51, mom:   6, volN: 1200000 },
  { t: 'CyberSecurity',     c: 'Technology', kw: ['security','privacy','data','protect','threat','password','safe'],    dem: 'Low',    comp: 26, mom:  12, volN:  380000 },
  { t: 'FutureTech',        c: 'Technology', kw: ['future','emerging','innovation','robotics','next','breakthrough'],   dem: 'Medium', comp: 57, mom:  20, volN: 1500000 },
  { t: 'GadgetOfTheDay',    c: 'Technology', kw: ['gadget','new tech','device','cool tech','pickup','toy'],             dem: 'Low',    comp: 30, mom:  10, volN:  280000 },
  { t: 'AITools',           c: 'Technology', kw: ['ai','tools','workflow','automation','prompts','productivity','model'],dem: 'Medium', comp: 45, mom:  38, volN:  720000 },
  { t: 'CameraGear',        c: 'Technology', kw: ['camera','lens','sony','fuji','gear','kit','photography'],            dem: 'Low',    comp: 32, mom:   7, volN:  410000 },

  /* ---- Lifestyle ---- */
  { t: 'SlowLiving',        c: 'Lifestyle', kw: ['slow','living','intentional','calm','cozy','pace','quiet'],          dem: 'Low',    comp: 16, mom:  14, volN:  240000 },
  { t: 'MorningRoutine',    c: 'Lifestyle', kw: ['morning','routine','6am','habits','ritual','start','early'],         dem: 'Medium', comp: 40, mom:  11, volN: 1100000 },
  { t: 'CozyHome',          c: 'Lifestyle', kw: ['cozy','home','hygge','comfort','evening','blanket','apartment'],     dem: 'Medium', comp: 35, mom:  12, volN:  860000 },
  { t: 'InteriorInspo',     c: 'Lifestyle', kw: ['interior','decor','apartment','design','room','shelves','renovation'],dem: 'High',   comp: 62, mom:   9, volN: 3100000 },
  { t: 'MinimalistLiving',  c: 'Lifestyle', kw: ['minimalist','less','declutter','simple','own','tiny'],               dem: 'Low',    comp: 18, mom:   8, volN:  190000 },
  { t: 'PlantParent',       c: 'Lifestyle', kw: ['plants','monstera','jungle','watering','green','houseplants','leaf'],dem: 'Low',    comp: 24, mom:  10, volN:  410000 },
  { t: 'SelfCareSunday',    c: 'Lifestyle', kw: ['self care','sunday','reset','bath','journal','rest','slow'],         dem: 'Medium', comp: 33, mom:  13, volN:  620000 },
  { t: 'DayInMyLife',       c: 'Lifestyle', kw: ['day in my life','vlog','routine','realistic','pov','daily'],         dem: 'High',   comp: 65, mom:  17, volN: 2600000 },
  { t: 'WeekendReset',      c: 'Lifestyle', kw: ['weekend','reset','clean','errands','recharge','sunday','tidy'],      dem: 'Low',    comp: 20, mom:  19, volN:  170000 },
  { t: 'BookStack',         c: 'Lifestyle', kw: ['book','read','reading','stack','shelf','pages','novel'],             dem: 'Medium', comp: 31, mom:   9, volN:  540000 },

  /* ---- Cross-category creator tags ---- */
  { t: 'ContentCreator',    c: 'Lifestyle', kw: ['creator','content','creating','posting','niche','community'],        dem: 'High',   comp: 67, mom:   7, volN: 4100000 },
  { t: 'Reels',             c: 'Lifestyle', kw: ['reel','instagram','video','audio','short','clip','trend'],           dem: 'High',   comp: 81, mom:  12, volN: 9300000, fit: { instagram: 96, tiktok: 62, linkedin: 18 } },
  { t: 'TrendingAudio',     c: 'Lifestyle', kw: ['audio','sound','trending','tiktok','song','viral sound'],            dem: 'Medium', comp: 49, mom:  16, volN: 1200000, fit: { tiktok: 94, instagram: 58, linkedin: 12 } },
  { t: 'ExplorePage',       c: 'Lifestyle', kw: ['explore','viral','discover','feed','reach','fyp'],                   dem: 'High',   comp: 88, mom:   2, volN:14000000, fit: { linkedin: 10 } },
  { t: 'CreatorCommunity',  c: 'Lifestyle', kw: ['community','creators','support','engagement','mutuals','small'],     dem: 'Medium', comp: 44, mom:   6, volN:  980000 },
  { t: 'BehindTheScenes',   c: 'Lifestyle', kw: ['bts','behind','process','making','studio','shoot','workshop'],       dem: 'Medium', comp: 37, mom:  11, volN:  890000 }
];

/* ---------- deterministic helpers (stable between renders) ---------- */

function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

/* 8 weekly points ending exactly at the tag's momentum */
function trendSeries(tag) {
  const h = hashStr(tag.t);
  const n = 8, out = [];
  for (let i = 0; i < n; i++) {
    const prog = i / (n - 1);
    const wig = Math.sin(h % 97 + i * 1.7) * Math.abs(tag.mom) * 0.09;
    out.push(tag.mom * prog + wig);
  }
  out[n - 1] = tag.mom;
  return out.map(v => Math.round(v * 10) / 10);
}

/* audience fit per platform, deterministic when not overridden */
function platformFit(tag, platformId) {
  if (tag.fit && tag.fit[platformId] != null) return tag.fit[platformId];
  const priors = {
    Travel:     { instagram: 88, tiktok: 84, youtube: 74, linkedin: 30 },
    Food:       { instagram: 90, tiktok: 86, youtube: 76, linkedin: 24 },
    Fashion:    { instagram: 92, tiktok: 82, youtube: 70, linkedin: 26 },
    Fitness:    { instagram: 84, tiktok: 88, youtube: 78, linkedin: 40 },
    Beauty:     { instagram: 90, tiktok: 86, youtube: 74, linkedin: 22 },
    Business:   { instagram: 66, tiktok: 54, youtube: 62, linkedin: 92 },
    Technology: { instagram: 62, tiktok: 66, youtube: 84, linkedin: 80 },
    Lifestyle:  { instagram: 86, tiktok: 80, youtube: 72, linkedin: 44 }
  };
  const base = priors[tag.c][platformId];
  const jitter = (hashStr(tag.t + platformId) % 13) - 6;
  return Math.max(8, Math.min(98, base + jitter));
}

function competitionLevel(comp) {
  if (comp <= 30) return 'Low';
  if (comp <= 60) return 'Medium';
  return 'High';
}

function reachLabel(volN) {
  if (volN >= 5e6)  return 'Massive';
  if (volN >= 2e6)  return 'Very large';
  if (volN >= 5e5)  return 'Large';
  if (volN >= 1e5)  return 'Medium';
  return 'Small';
}

function fmtVol(volN) {
  if (volN >= 1e6) return (volN / 1e6).toFixed(1).replace('.0', '') + 'M';
  if (volN >= 1e3) return Math.round(volN / 1e3) + 'K';
  return String(volN);
}

function trendStatus(mom) {
  if (mom >= 12) return 'Rising';
  if (mom <= -4) return 'Falling';
  return 'Stable';
}

/* seeded demo content for Saved and History */
const SEED_HISTORY = [
  { id: 'h1', date: 'Oct 2, 2026',  caption: 'Shot our new ceramics collection in natural light this weekend. The glaze colors came out unreal.', platform: 'instagram', category: 'Business',  strategy: 'balanced' },
  { id: 'h2', date: 'Sep 28, 2026', caption: '6am runs before work sound impossible until you try them for two weeks straight.',                  platform: 'tiktok',    category: 'Fitness',  strategy: 'niche' },
  { id: 'h3', date: 'Sep 24, 2026', caption: 'Everything I ate in Osaka in 48 hours. Part one: the arcade district after dark.',                 platform: 'instagram', category: 'Food',     strategy: 'reach' },
  { id: 'h4', date: 'Sep 19, 2026', caption: 'We rebuilt our onboarding in a weekend and conversion went up 18 percent. Here is the whole process.', platform: 'linkedin', category: 'Technology', strategy: 'balanced' }
];

const SEED_SAVED_TAGS  = ['TokyoFood', 'SkinBarrier', 'HighProtein', 'ThriftFinds'];
const SEED_SAVED_SETS  = [
  { id: 's1', name: 'Tokyo trip content', platform: 'instagram', category: 'Travel',
    tags: ['TokyoFood', 'JapanTravel', 'TokyoCafe', 'HiddenJapan', 'TravelReel'], collection: 'Japan series' },
  { id: 's2', name: 'Protein series', platform: 'tiktok', category: 'Food',
    tags: ['HighProtein', 'MealPrep', 'FitnessJourney'], collection: '' }
];

const EXAMPLES = [
  'Just landed in Tokyo. The food, architecture and tiny coffee shops completely surprised me.',
  'New high protein meal prep is up. 40g of protein per bowl and it actually tastes good.',
  'Thrifted this entire look for under 30 dollars. Slow fashion is winning again.'
];
