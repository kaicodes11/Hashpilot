/* ============================================================
   Tagline · application
   One IIFE: state, analysis engine, rendering, interactions.
   The engine reads TAGS (data.js) exactly like it would read a
   live trend API payload, so swapping the source later is local.
   ============================================================ */

(function () {
'use strict';

/* ---------------- icons (custom, minimal, stroke-based) ---------------- */

const IC = {
  hash:    '<path d="M9.5 4.5 7.5 19.5M16.5 4.5l-2 15M4.5 9.5h16M3.5 14.5h16"/>',
  copy:    '<rect x="9" y="9" width="11" height="11" rx="1.5"/><path d="M5 15V5.5A1.5 1.5 0 0 1 6.5 4H15"/>',
  check:   '<path d="M4.5 12.5l5 5L19.5 7"/>',
  swap:    '<path d="M7 4.5v13M7 17.5l-3.2-3.4M7 17.5l3.2-3.4M17 19.5v-13M17 6.5l3.2 3.4M17 6.5l-3.2 3.4"/>',
  chev:    '<path d="M6 9.5l6 6 6-6"/>',
  up:      '<path d="M6 14.5l6-6 6 6"/>',
  down:    '<path d="M6 9.5l6 6 6-6"/>',
  x:       '<path d="M6 6l12 12M18 6L6 18"/>',
  bookmark:'<path d="M6.5 4.5h11a0 0 0 0 1 0 0v15l-5.5-4-5.5 4v-15a0 0 0 0 1 0 0z"/>',
  clock:   '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2.5"/>',
  right:   '<path d="M5 12h14M13.5 6.5 19 12l-5.5 5.5"/>',
  trash:   '<path d="M4.5 6.5h15M9.5 6V4.5h5V6M7 6.5l.8 13h8.4l.8-13M10 10v6M14 10v6"/>',
  arrow:   '<path d="M7 17 17 7M9 7h8v8"/>',
  platform:'<rect x="4" y="4" width="16" height="16" rx="3"/><path d="M4 10h16"/>'
};

function ic(name, size) {
  const s = size || 16;
  return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" ' +
    'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    IC[name] + '</svg>';
}

/* ---------------- helpers ---------------- */

const $  = function (sel, root) { return (root || document).querySelector(sel); };
const $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function tagHtml(t) { return '<b>#</b>' + esc(t); }

/* ---------------- persistent store ---------------- */

const LS_KEY = 'tagline:v1';
let store;

function loadStore() {
  let s = null;
  try { s = JSON.parse(localStorage.getItem(LS_KEY)); } catch (e) { s = null; }
  if (!s || !s.savedTags) {
    s = {
      savedTags: SEED_SAVED_TAGS.map(function (t) { return { t: t, at: 'Sep 2026' }; }),
      sets: SEED_SAVED_SETS.slice(),
      collections: ['Japan series', 'Evergreen'],
      history: SEED_HISTORY.slice()
    };
    try { localStorage.setItem(LS_KEY, JSON.stringify(s)); } catch (e) {}
  }
  return s;
}
function saveStore() { try { localStorage.setItem(LS_KEY, JSON.stringify(store)); } catch (e) {} }

/* ---------------- session state ---------------- */

const state = {
  route: 'analyze',
  platform: 'instagram',
  category: 'Travel',
  strategy: 'balanced',
  caption: '',
  analysis: null,          // { caption, platform, category, strategy, results: [ {tag,score,rel,hits} ] }
  selected: [],            // ordered tag names in the working set
  openRow: null,
  loading: false,
  stale: false,
  regen: 0,
  trends: { platform: 'all', category: 'all', sort: 'rising' },
  savedTab: 'tags',
  namingSet: false,
  namingColl: false
};

function platform() {
  return PLATFORMS.find(function (p) { return p.id === state.platform; }) || PLATFORMS[0];
}

function findTag(t) {
  return TAGS.find(function (x) { return x.t === t; });
}

/* ---------------- analysis engine ---------------- */

const WEIGHTS = {
  balanced: { rel: .42, mom: .22, compInv: .20, reach: .16 },
  reach:    { rel: .20, mom: .24, compInv: .14, reach: .42 },
  niche:    { rel: .40, mom: .16, compInv: .30, reach: .14 }
};

function tokenize(caption) {
  return caption.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(function (w) { return w.length > 2; });
}

function matchTag(tag, norm, tokens) {
  const hits = [];
  for (let i = 0; i < tag.kw.length; i++) {
    const kw = tag.kw[i];
    if (kw.indexOf(' ') > -1) {
      if (norm.indexOf(kw) > -1) hits.push(kw);
    } else if (tokens.indexOf(kw) > -1) {
      hits.push(kw);
    } else if (kw.length > 4) {
      for (let j = 0; j < tokens.length; j++) {
        const t = tokens[j];
        if (t.length > 3 && (t.indexOf(kw) === 0 || kw.indexOf(t) === 0)) { hits.push(kw); break; }
      }
    }
  }
  return hits;
}

function topicOf(hits) {
  return hits.slice(0, 3).join(' + ');
}

function relevanceFor(tag, hits, category) {
  let r;
  if (hits.length) r = 52 + Math.min(44, hits.length * 15);
  else r = (category && tag.c === category) ? 46 : 18;
  if (category && tag.c === category) r += 8;
  return Math.min(98, Math.round(r));
}

function scoreTag(tag, rel, ctx) {
  const w = WEIGHTS[ctx.strategy];
  const momN = Math.max(0, Math.min(100, 50 + tag.mom * 1.15));
  const reach = Math.min(100, Math.log10(Math.max(10, tag.volN)) / 7 * 100);
  const fit = platformFit(tag, ctx.platform) / 100;
  let s = rel * w.rel + momN * w.mom + (100 - tag.comp) * w.compInv + reach * w.reach;
  if (ctx.jitter) s += (hashStr(tag.t + 'g' + ctx.jitter) % 7) - 3;
  return Math.max(12, Math.min(98, Math.round(s * .88 + fit * 12)));
}

function reasonFor(tag, hits) {
  const st = trendStatus(tag.mom);
  const topic = topicOf(hits);
  const cat = tag.c.toLowerCase();
  let main;
  if (st === 'Rising') {
    main = hits.length
      ? 'Strong match for ' + topic + ', with activity up ' + tag.mom + '% over the last 24 hours.'
      : 'Rising fast in ' + cat + ' right now. Specific enough to rank, broad enough to travel.';
  } else if (st === 'Falling') {
    main = 'Volume cooled ' + Math.abs(tag.mom) + '% this week, but the audience still matches ' + (topic || cat) + '. Use inside a mix, not on its own.';
  } else {
    main = hits.length
      ? 'Reliable tag for ' + topic + '. Steady search demand, little week to week movement.'
      : 'Stable conversation in ' + cat + ' with predictable reach.';
  }
  if (tag.comp <= 25) main += ' Low competition means good posts stay visible for days.';
  else if (tag.comp >= 72) main += ' Crowded tag, so pair it with one or two niche picks.';
  return main;
}

function computeAnalysis() {
  const caption = state.caption.trim();
  if (!caption) return null;
  const norm = ' ' + caption.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ') + ' ';
  const tokens = tokenize(caption);
  const ctx = { platform: state.platform, strategy: state.strategy, jitter: state.regen || 0 };

  const scored = TAGS.map(function (tag) {
    const hits = matchTag(tag, norm, tokens);
    const rel = relevanceFor(tag, hits, state.category);
    return { tag: tag, rel: rel, hits: hits, score: scoreTag(tag, rel, ctx) };
  });

  scored.sort(function (a, b) { return b.score - a.score; });

  /* guarantee a usable mix: no more than 9 heavy-competition tags in the top 15 */
  const out = [];
  let heavy = 0;
  for (let i = 0; i < scored.length && out.length < 15; i++) {
    const c = scored[i];
    if (c.tag.comp > 60) { heavy++; if (heavy > 9) continue; }
    out.push(c);
  }

  return {
    caption: caption,
    platform: state.platform,
    category: state.category,
    strategy: state.strategy,
    results: out,
    at: Date.now()
  };
}

function replacementFor(exclude) {
  const used = {};
  state.analysis.results.forEach(function (r) { used[r.tag.t] = 1; });
  state.selected.forEach(function (t) { used[t] = 1; });
  exclude.forEach(function (t) { used[t] = 1; });

  const norm = ' ' + state.analysis.caption.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ') + ' ';
  const tokens = tokenize(state.analysis.caption);
  const ctx = { platform: state.platform, strategy: state.strategy, jitter: (state.regen || 0) + 1 };

  const cands = TAGS.filter(function (t) { return !used[t.t]; }).map(function (tag) {
    const hits = matchTag(tag, norm, tokens);
    const rel = relevanceFor(tag, hits, state.category);
    return { tag: tag, rel: rel, hits: hits, score: scoreTag(tag, rel, ctx) };
  });
  cands.sort(function (a, b) { return b.score - a.score; });
  return cands[0];
}

/* ---------------- toast ---------------- */

let toastTimer = null;
function toast(msg) {
  const el = $('#toast');
  el.innerHTML = ic('check', 14) + '<span>' + esc(msg) + '</span>';
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { el.classList.remove('show'); }, 1900);
}

function copyText(text, confirmMsg, btn) {
  function done() {
    toast(confirmMsg);
    if (btn) {
      const old = btn.innerHTML;
      btn.classList.add('copied');
      btn.innerHTML = ic('check', 15);
      setTimeout(function () { btn.classList.remove('copied'); btn.innerHTML = old; }, 1300);
    }
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done, function () { fallback(); });
  } else fallback();
  function fallback() {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); done(); } catch (e) {}
    document.body.removeChild(ta);
  }
}

/* ---------------- small render helpers ---------------- */

function sparkSVG(series, cls, w, h) {
  w = w || 76; h = h || 22;
  const min = Math.min.apply(null, series), max = Math.max.apply(null, series);
  const span = (max - min) || 1;
  const pts = series.map(function (v, i) {
    const x = 2 + (i / (series.length - 1)) * (w - 6);
    const y = h - 3 - ((v - min) / span) * (h - 6);
    return x.toFixed(1) + ',' + y.toFixed(1);
  });
  const last = pts[pts.length - 1].split(',');
  const st = trendStatus(series[series.length - 1] - series[0]);
  const color = st === 'Rising' ? '' : (st === 'Falling' ? ' down' : ' flat');
  return '<svg class="spark' + (cls ? ' ' + cls : '') + color + '" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">' +
    '<path d="M' + pts.join(' L') + '" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>' +
    '<circle cx="' + last[0] + '" cy="' + last[1] + '" r="2.1" fill="currentColor" stroke="none"/></svg>';
}

function statusChip(mom) {
  const st = trendStatus(mom);
  const cls = st === 'Rising' ? 'rising' : (st === 'Falling' ? 'falling' : 'stable');
  const sign = mom > 0 ? '+' : '';
  return '<span class="chip ' + cls + '">' + st + ' ' + sign + mom + '%</span>';
}

function opportunityLabel(score) {
  if (score >= 80) return 'High opportunity';
  if (score >= 66) return 'Strong match';
  if (score >= 52) return 'Good fit';
  return 'Situational';
}

function momClass(mom) {
  const st = trendStatus(mom);
  return st === 'Rising' ? 'up' : (st === 'Falling' ? 'down' : 'flat');
}

/* ============================================================
   TOP BAR
   ============================================================ */

function initTopbar() {
  const sel = $('#topPlatform');
  sel.innerHTML = PLATFORMS.map(function (p) {
    return '<option value="' + p.id + '"' + (p.id === state.platform ? ' selected' : '') + '>' + p.label + '</option>';
  }).join('');
  sel.addEventListener('change', function () { setPlatform(sel.value); });

  $('#brand').addEventListener('click', function () { go('analyze'); });
  $$('#nav .nav-link').forEach(function (b) {
    b.addEventListener('click', function () { go(b.dataset.route); });
  });

  const prof = $('#profile'), menu = $('#profileMenu');
  $('#avatarBtn').addEventListener('click', function (e) {
    e.stopPropagation();
    menu.hidden = !menu.hidden;
  });
  document.addEventListener('click', function () { menu.hidden = true; });
  menu.addEventListener('click', function (e) { e.stopPropagation(); });
  $$('.pm-item', menu).forEach(function (b) {
    b.addEventListener('click', function () {
      menu.hidden = true;
      toast('Account features are outside this preview.');
    });
  });
}

function syncTopbar() {
  $$('#nav .nav-link').forEach(function (b) { b.classList.toggle('active', b.dataset.route === state.route); });
  $('#topPlatform').value = state.platform;
}

function setPlatform(id) {
  if (state.platform === id) return;
  state.platform = id;
  if (state.analysis) { state.analysis = computeAnalysis(); }
  rerender();
}

/* ---------------- routing ---------------- */

function go(route) {
  state.route = route;
  window.scrollTo(0, 0);
  rerender();
}

function rerender() {
  syncTopbar();
  const app = $('#app');
  if (state.route === 'analyze') app.innerHTML = viewAnalyze();
  else if (state.route === 'trends') app.innerHTML = viewTrends();
  else if (state.route === 'saved') app.innerHTML = viewSaved();
  else app.innerHTML = viewHistory();
  bindPage();
}

/* ============================================================
   ANALYZE VIEW
   ============================================================ */

function viewAnalyze() {
  const p = platform();
  return '' +
  '<div class="page">' +
    '<div class="hero">' +
      '<div>' +
        '<h1>Find the tags your post deserves.</h1>' +
        '<p class="hero-sub">Paste your post and see which conversations are gaining momentum.</p>' +
      '</div>' +
      '<div class="hero-meta">' +
        '<div class="hm-line">Trend coverage</div>' +
        '<div class="hm-strong"><b>' + TAGS.length + ' tags</b> · ' + CATEGORIES.length + ' categories · ' + PLATFORMS.length + ' platforms</div>' +
        '<div class="hm-strong" style="font-size:12px;color:var(--faint)">Refreshed 14 minutes ago</div>' +
      '</div>' +
    '</div>' +

    '<div class="composer">' +
      '<div class="kicker no-rule" style="margin-bottom:10px">Your post</div>' +
      '<div class="caption-wrap">' +
        '<textarea id="caption" class="caption" rows="3" placeholder="Paste or write your caption. Try the Tokyo example: just landed, food, architecture, tiny coffee shops." maxlength="' + (p.captionLimit + 400) + '"></textarea>' +
      '</div>' +
      '<div class="caption-foot">' +
        '<div class="examples">' +
          '<span class="ex-label">Try:</span>' +
          EXAMPLES.map(function (ex, i) { return '<button class="ex-chip" data-action="example" data-arg="' + i + '">' + ['Tokyo trip', 'Meal prep', 'Thrifted outfit'][i] + '</button>'; }).join('') +
        '</div>' +
        '<span class="char-count" id="charCount">0 / ' + p.captionLimit + '</span>' +
      '</div>' +
    '</div>' +

    '<div class="controls">' +
      '<div class="field"><label>Platform</label>' +
        '<select id="ctlPlatform" class="select">' +
          PLATFORMS.map(function (x) { return '<option value="' + x.id + '"' + (x.id === state.platform ? ' selected' : '') + '>' + x.label + '</option>'; }).join('') +
        '</select></div>' +
      '<div class="field"><label>Audience / category</label>' +
        '<select id="ctlCategory" class="select">' +
          '<option value="">No preference</option>' +
          CATEGORIES.map(function (c) { return '<option value="' + c + '"' + (c === state.category ? ' selected' : '') + '>' + c + '</option>'; }).join('') +
        '</select></div>' +
      '<div class="field" style="min-width:250px"><label>Strategy</label>' +
        '<div class="seg" id="segStrategy">' +
          '<button data-strategy="balanced" class="' + (state.strategy === 'balanced' ? 'on' : '') + '">Balanced</button>' +
          '<button data-strategy="reach" class="' + (state.strategy === 'reach' ? 'on' : '') + '">Reach</button>' +
          '<button data-strategy="niche" class="' + (state.strategy === 'niche' ? 'on' : '') + '">Niche</button>' +
        '</div>' +
        '<div class="seg-hint" id="segHint"></div></div>' +
      '<div class="field"><label>&nbsp;</label>' +
        '<button class="btn-primary" id="btnAnalyze">' + ic('hash', 15) + 'Analyze</button></div>' +
    '</div>' +

    '<div class="analyze-grid">' +
      '<div class="results-col" id="resultsArea"></div>' +
      '<aside class="rail">' +
        '<section class="rail-section rail-momentum">' +
          '<div class="kicker">Trend momentum</div>' +
          '<div id="momList"></div>' +
        '</section>' +
        '<section class="rail-section rail-set">' +
          '<div class="kicker">Your set</div>' +
          '<div id="setPanel"></div>' +
        '</section>' +
      '</aside>' +
    '</div>' +

    '<div class="foot"><span>Tagline · hashtag research for working creators</span>' +
    '<span>Trend data refreshes hourly. Prototype figures are illustrative.</span></div>' +
  '</div>';
}

const STRATEGY_HINTS = {
  balanced: 'Even mix of reach, relevance and competition.',
  reach: 'Favors large, active conversations.',
  niche: 'Favors low-competition communities.'
};

const LOAD_STEPS = ['Reading your caption', 'Matching category vocabulary', 'Checking trend momentum', 'Scoring competition', 'Ranking opportunities'];

/* ---------- results area ---------- */

function renderResultsArea(firstLoad) {
  const area = $('#resultsArea');
  if (!area) return;

  if (state.loading) {
    area.innerHTML = '' +
      '<div class="analyzing">' +
        '<div class="az-status"><span class="az-dot"></span><span id="azMain">Analyzing your post</span></div>' +
        '<div class="az-steps">' +
          LOAD_STEPS.map(function (s, i) {
            return '<div class="az-step" data-step="' + i + '"><span class="dot-s"></span><span class="tick">' + ic('check', 13) + '</span><span>' + s + '</span></div>';
          }).join('') +
        '</div>' +
        '<div class="az-bar"><i id="azBarFill"></i></div>' +
      '</div>';
    return;
  }

  if (!state.analysis) {
    area.innerHTML = '' +
      '<div class="empty" style="margin-top:34px">' +
        '<div class="empty-title">Nothing analyzed yet</div>' +
        '<p>Write or paste a caption, pick a platform and strategy, then run Analyze. Recommendations rank by relevance, momentum, competition and reach.</p>' +
      '</div>';
    return;
  }

  const st = state.strategy;
  area.innerHTML = '' +
    '<div style="margin-top:34px">' +
      '<div class="result-head">' +
        '<div class="kicker" style="flex:1">Content analysis · ' + STRATEGY_HINTS[st].split('.')[0].toLowerCase() + ' mix</div>' +
        '<span class="rh-note">' + state.analysis.results.length + ' ranked recommendations</span>' +
        '<button class="btn-ghost" data-action="regenerate" title="Re-run with a fresh trend pass">' + ic('swap', 13) + 'Regenerate</button>' +
      '</div>' +
      (state.stale ? '<div style="font-size:12px;color:var(--down);margin:8px 0 2px">Caption changed. Run Analyze again to refresh these results.</div>' : '') +
      '<div id="rows">' + rowsHtml(firstLoad) + '</div>' +
    '</div>';
}

function rowsHtml(firstLoad) {
  return state.analysis.results.map(function (r, i) {
    const tag = r.tag;
    const open = state.openRow === tag.t;
    const sel = state.selected.indexOf(tag.t) > -1;
    return '' +
    '<div class="tag-row' + (sel ? ' selected' : '') + (open ? ' open' : '') + (firstLoad ? ' row-anim' : '') + '" data-tag="' + esc(tag.t) + '"' +
      (firstLoad ? ' style="animation-delay:' + (i * 45) + 'ms"' : '') + '>' +
      '<div class="tag-row-main" data-action="row-toggle">' +
        '<span class="row-check' + (sel ? ' on' : '') + '" data-action="row-select" title="Add to set">' + ic('check', 12) + '</span>' +
        '<span class="row-rank">' + String(i + 1).padStart(2, '0') + '</span>' +
        '<div class="row-id">' +
          '<div class="row-tagline"><span class="row-tag">' + tagHtml(tag.t) + '</span>' + statusChip(tag.mom) + '</div>' +
          '<div class="row-reason">' + esc(reasonFor(tag, r.hits)) + '</div>' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:14px">' +
          '<div class="row-score">' +
            '<span class="rs-num" data-score="' + r.score + '">' + r.score + '</span><span class="rs-of">/ 100</span>' +
            '<span class="rs-label">' + opportunityLabel(r.score) + '</span>' +
          '</div>' +
          '<div class="row-actions">' +
            '<button class="icon-btn" data-action="copy-tag" title="Copy hashtag">' + ic('copy', 15) + '</button>' +
            '<button class="icon-btn" data-action="replace-tag" title="Replace with the next best option">' + ic('swap', 15) + '</button>' +
            '<button class="icon-btn' + (open ? ' chev-open' : '') + '" data-action="row-toggle" title="Why this tag">' + ic('chev', 15) + '</button>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="tag-row-detail">' + detailHtml(tag, r) + '</div>' +
    '</div>';
  }).join('');
}

function detailHtml(tag, r) {
  const p = platform();
  const fit = platformFit(tag, state.platform);
  const series = trendSeries(tag);
  const comp = competitionLevel(tag.comp);
  const cell = function (label, val) {
    return '<div class="dg-cell"><div class="dg-label">' + label + '</div><div class="dg-val">' + val + '</div></div>';
  };
  const meter = function (pct, warn) {
    return '<div class="meter"><i class="' + (warn ? 'warn' : '') + '" data-w="' + pct + '" style="width:0"></i></div>';
  };
  return '' +
    '<div class="detail-grid">' +
      cell('Search demand', tag.dem) +
      '<div class="dg-cell"><div class="dg-label">Competition</div><div class="dg-val">' + comp + ' <span class="dg-quiet">' + tag.comp + '/100</span></div>' + meter(tag.comp, tag.comp > 60) + '</div>' +
      '<div class="dg-cell"><div class="dg-label">Momentum · 7 days</div><div class="dg-val" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><span class="mom-num ' + momClass(tag.mom) + '">' + (tag.mom > 0 ? '+' : '') + tag.mom + '%</span>' + sparkSVG(series, '', 64, 20) + '</div></div>' +
      '<div class="dg-cell"><div class="dg-label">Content relevance</div><div class="dg-val">' + r.rel + '%</div>' + meter(r.rel) + '</div>' +
      '<div class="dg-cell"><div class="dg-label">Audience fit · ' + p.label + '</div><div class="dg-val">' + fit + '%</div>' + meter(fit, fit < 45) + '</div>' +
      '<div class="dg-cell"><div class="dg-label">Reach potential</div><div class="dg-val">' + reachLabel(tag.volN) + ' <span class="dg-quiet">' + fmtVol(tag.volN) + ' posts</span></div></div>' +
      cell('Trend signal', trendStatus(tag.mom)) +
      cell('Audience', esc(tag.c)) +
    '</div>' +
    '<div class="why-line"><span class="why-label">Why this tag</span><p>' + esc(reasonFor(tag, r.hits)) + '</p></div>' +
    '<div class="detail-actions">' +
      '<button class="btn-ghost" data-action="copy-tag">' + ic('copy', 13) + 'Copy</button>' +
      '<button class="btn-ghost" data-action="replace-tag">' + ic('swap', 13) + 'Replace</button>' +
      '<button class="btn-ghost accent" data-action="save-tag">' + ic('bookmark', 13) + (store.savedTags.some(function (s) { return s.t === tag.t; }) ? 'Saved' : 'Save tag') + '</button>' +
    '</div>';
}

/* animate scores from previous values */
function animateScores(oldScores) {
  $$('#rows .rs-num').forEach(function (el, idx) {
    const to = parseInt(el.dataset.score, 10);
    const from = oldScores ? (oldScores[idx] != null ? oldScores[idx] : 0) : 0;
    if (isNaN(to)) return;
    const t0 = performance.now(), dur = 550, delay = idx * 40;
    function tick(now) {
      const k = Math.min(1, (now - t0 - delay) / dur);
      if (k < 0) { requestAnimationFrame(tick); return; }
      const e = 1 - Math.pow(1 - k, 3);
      el.textContent = Math.round(from + (to - from) * e);
      if (k < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });
  /* reveal meters inside open detail */
  $$('#rows .meter i[data-w]').forEach(function (m) {
    requestAnimationFrame(function () { setTimeout(function () { m.style.width = m.dataset.w + '%'; }, 60); });
  });
}

/* FLIP reorder for strategy / platform changes */
function refreshResults({ animateRows } = {}) {
  const rows = $('#rows');
  if (!rows || !state.analysis) { renderResultsArea(false); return; }

  const prev = {};
  if (animateRows) {
    $$('.tag-row', rows).forEach(function (el) {
      prev[el.dataset.tag] = el.getBoundingClientRect().top;
    });
  }
  const oldScores = $$('#rows .tag-row').map(function (el) {
    const n = el.querySelector('.rs-num');
    return n ? parseInt(n.textContent, 10) : 0;
  });

  rows.innerHTML = rowsHtml(false);
  animateScores(oldScores);

  /* open row detail: restore meter widths immediately */
  $$('#rows .tag-row.open .meter i[data-w]').forEach(function (m) {
    m.style.width = m.dataset.w + '%';
  });

  if (animateRows) {
    $$('.tag-row', rows).forEach(function (el) {
      const before = prev[el.dataset.tag];
      if (before == null) { el.classList.add('row-anim'); return; }
      const dy = before - el.getBoundingClientRect().top;
      if (Math.abs(dy) > 1) {
        el.style.transition = 'none';
        el.style.transform = 'translateY(' + dy + 'px)';
        requestAnimationFrame(function () {
          el.style.transition = 'transform .34s cubic-bezier(.2,.7,.3,1)';
          el.style.transform = '';
        });
      }
    });
  }
}

/* ---------- loading sequence ---------- */

let loadToken = 0;
function runAnalysis(fromHistory) {
  if (!state.caption.trim()) { toast('Write or paste a caption first.'); return; }
  state.loading = true;
  state.analysis = null;
  state.openRow = null;
  state.stale = false;
  renderResultsArea(false);
  updateRail();

  const token = ++loadToken;
  const per = 340, total = per * LOAD_STEPS;
  const t0 = Date.now();

  function frame() {
    if (token !== loadToken) return;
    const el = Date.now() - t0;
    const bar = $('#azBarFill');
    if (bar) bar.style.width = Math.min(100, el / total * 100) + '%';
    const idx = Math.min(LOAD_STEPS.length - 1, Math.floor(el / per));
    $$('.az-step').forEach(function (s, i) {
      s.classList.toggle('done', i < idx);
      s.classList.toggle('active', i === idx);
    });
    if (el < total) requestAnimationFrame(frame);
    else finish();
  }
  requestAnimationFrame(frame);

  function finish() {
    if (token !== loadToken) return;
    state.loading = false;
    state.analysis = computeAnalysis();
    if (!fromHistory) pushHistory();
    renderResultsArea(true);
    animateScores(null);
    updateRail();
    toast(state.analysis.results.length + ' recommendations ranked.');
  }
}

function pushHistory() {
  const a = state.analysis;
  const dupe = store.history.some(function (h) { return h.caption === a.caption; });
  if (dupe) return;
  const d = new Date();
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  store.history.unshift({
    id: 'h' + Date.now(),
    date: months[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear(),
    caption: a.caption,
    platform: a.platform,
    category: a.category,
    strategy: a.strategy
  });
  if (store.history.length > 30) store.history.pop();
  saveStore();
}

/* ---------- trend momentum rail ---------- */

function momentumTags() {
  let pool = TAGS.slice();
  if (state.analysis) {
    const ranked = state.analysis.results.slice().sort(function (a, b) { return b.tag.mom - a.tag.mom; });
    const top = ranked.slice(0, 4).map(function (r) { return r.tag; });
    if (top.length >= 3) return top;
  }
  if (state.category) pool = pool.filter(function (t) { return t.c === state.category; });
  pool.sort(function (a, b) { return b.mom - a.mom; });
  return pool.slice(0, 4);
}

function updateRail() {
  const mom = $('#momList');
  if (mom) {
    mom.innerHTML = momentumTags().map(function (tag) {
      const fit = platformFit(tag, state.platform);
      const fitLabel = fit >= 80 ? 'Strong fit' : (fit >= 62 ? 'Good fit' : (fit >= 45 ? 'Fair fit' : 'Weak fit'));
      return '<div class="mom-item">' +
        '<div><div class="mi-tag">' + tagHtml(tag.t) + '</div><div class="mi-fit">' + fitLabel + ' · ' + esc(tag.c) + '</div></div>' +
        sparkSVG(trendSeries(tag), 'draw') +
        '<div class="mi-mom ' + momClass(tag.mom) + '">' + (tag.mom > 0 ? '+' : '') + tag.mom + '%</div>' +
      '</div>';
    }).join('');
  }
  renderSetPanel();
}

/* ---------- your set rail ---------- */

function renderSetPanel() {
  const panel = $('#setPanel');
  if (!panel) return;
  const p = platform();
  const tags = state.selected.map(findTag).filter(Boolean);

  let body;
  if (!tags.length) {
    body = '<div class="set-empty">Select recommendations to build your set. They stay ordered as you add them.</div>';
  } else {
    body = '<div class="set-body">' + tags.map(function (tag, i) {
      return '<div class="set-item" style="animation-delay:' + (i * 30) + 'ms">' +
        '<span class="si-tag">' + tagHtml(tag.t) + '</span>' +
        '<button data-action="set-up" data-arg="' + i + '" title="Move up" ' + (i === 0 ? 'disabled style="visibility:hidden"' : '') + '>' + ic('up', 13) + '</button>' +
        '<button data-action="set-down" data-arg="' + i + '" title="Move down" ' + (i === tags.length - 1 ? 'disabled style="visibility:hidden"' : '') + '>' + ic('down', 13) + '</button>' +
        '<button class="si-x" data-action="set-remove" data-arg="' + i + '" title="Remove">' + ic('x', 13) + '</button>' +
      '</div>';
    }).join('') + '</div>';
  }

  const naming = state.namingSet;
  panel.innerHTML = '' +
    '<div class="set-panel">' +
      '<div class="set-head">' +
        '<span class="set-count"><b>' + tags.length + '</b> selected · ' + p.label + '</span>' +
        (tags.length ? '<button class="btn-ghost" data-action="clear-set" style="padding:4px 10px;font-size:11.5px">Clear</button>' : '') +
      '</div>' +
      body +
      (tags.length ?
        '<div class="set-foot">' +
          '<div class="set-preview">' + tags.map(function (t) { return '<b>#' + esc(t.t) + '</b>'; }).join(' ') + '</div>' +
          '<div class="set-actions">' +
            '<button class="btn-primary" data-action="copy-set" style="padding:9px 16px;font-size:13px">' + ic('copy', 13) + 'Copy all</button>' +
            (naming
              ? '<div class="set-input-row" style="flex:1"><input id="setNameInput" placeholder="Set name" maxlength="40"><button class="btn-ghost accent" data-action="confirm-save-set">' + ic('check', 13) + '</button></div>'
              : '<button class="btn-ghost accent" data-action="begin-save-set">' + ic('bookmark', 13) + 'Save set</button>') +
          '</div>' +
          '<div class="set-note"><b>' + tags.length + ' / ' + p.tagLimit + '</b> hashtags allowed on ' + p.label + '.' +
            (tags.length > p.tagLimit ? ' Trim the set before posting.' : ' Room for ' + (p.tagLimit - tags.length) + ' more.') + '</div>' +
        '</div>'
      : '') +
    '</div>';

  const inp = $('#setNameInput');
  if (inp) {
    inp.focus();
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') confirmSaveSet(inp.value); });
  }
}

function toggleSelect(tagName) {
  const i = state.selected.indexOf(tagName);
  if (i > -1) state.selected.splice(i, 1);
  else state.selected.push(tagName);
  renderSetPanel();
  const row = $('.tag-row[data-tag="' + tagName + '"]');
  if (row) {
    const on = state.selected.indexOf(tagName) > -1;
    row.classList.toggle('selected', on);
    const chk = $('.row-check', row);
    if (chk) chk.classList.toggle('on', on);
  }
}

function confirmSaveSet(name) {
  name = (name || '').trim();
  if (!name) { toast('Give the set a name first.'); return; }
  store.sets.unshift({
    id: 's' + Date.now(),
    name: name,
    platform: state.platform,
    category: state.category,
    tags: state.selected.slice(),
    collection: ''
  });
  saveStore();
  state.namingSet = false;
  renderSetPanel();
  toast('Saved "' + name + '". Find it under Saved.');
}

/* ============================================================
   TRENDS VIEW
   ============================================================ */

const SORTS = [
  { id: 'rising',      label: 'Rising fastest' },
  { id: 'reach',       label: 'Highest reach' },
  { id: 'competition', label: 'Lowest competition' },
  { id: 'opportunity', label: 'Best opportunity' }
];

function trendRows() {
  const ctx = { platform: state.trends.platform === 'all' ? 'instagram' : state.trends.platform, strategy: 'balanced', jitter: 0 };
  const rows = TAGS.filter(function (t) {
    return (state.trends.category === 'all' || t.c === state.trends.category);
  }).map(function (tag) {
    const rel = state.trends.category === 'all' ? 55 : 70;
    return { tag: tag, score: scoreTag(tag, rel, ctx), fit: platformFit(tag, ctx.platform) };
  });
  const s = state.trends.sort;
  rows.sort(function (a, b) {
    if (s === 'rising') return b.tag.mom - a.tag.mom;
    if (s === 'reach') return b.tag.volN - a.tag.volN;
    if (s === 'competition') return a.tag.comp - b.tag.comp;
    return b.score - a.score;
  });
  return rows.slice(0, 18);
}

function viewTrends() {
  const t = state.trends;
  const platChips = [{ id: 'all', label: 'All platforms' }].concat(PLATFORMS.map(function (p) { return { id: p.id, label: p.label }; }));
  const catChips = [{ id: 'all', label: 'All' }].concat(CATEGORIES.map(function (c) { return { id: c, label: c }; }));

  return '' +
  '<div class="page">' +
    '<div class="page-head">' +
      '<div class="kicker no-rule">Trends</div>' +
      '<h2>What is gaining momentum</h2>' +
      '<p class="ph-sub">Seven day movement across tracked tags. Filter by platform and category, then sort by the signal that matters for your post.</p>' +
    '</div>' +

    '<div class="filter-row">' +
      '<div class="chipset"><span class="cs-label">Platform</span>' +
        platChips.map(function (c) { return '<button class="fchip' + (t.platform === c.id ? ' on' : '') + '" data-action="trend-plat" data-arg="' + c.id + '">' + c.label + '</button>'; }).join('') +
      '</div>' +
      '<div class="chipset"><span class="cs-label">Category</span>' +
        catChips.map(function (c) { return '<button class="fchip' + (t.category === c.id ? ' on' : '') + '" data-action="trend-cat" data-arg="' + c.id + '">' + c.label + '</button>'; }).join('') +
      '</div>' +
    '</div>' +

    '<div class="sort-tabs">' +
      SORTS.map(function (s) { return '<button class="sort-tab' + (t.sort === s.id ? ' on' : '') + '" data-action="trend-sort" data-arg="' + s.id + '">' + s.label + '</button>'; }).join('') +
    '</div>' +

    '<div class="ttable-wrap"><table class="ttable"><thead><tr>' +
      '<th></th><th>Tag</th><th>Category</th><th>7 day trend</th><th class="c-mom">Momentum</th>' +
      '<th class="num">Posts</th><th>Competition</th><th class="num">Opportunity</th><th></th>' +
    '</tr></thead><tbody>' +
      trendRows().map(function (r, i) {
        const tag = r.tag;
        const cl = competitionLevel(tag.comp);
        return '<tr data-action="trend-open" data-arg="' + esc(tag.t) + '">' +
          '<td class="tt-rank">' + String(i + 1).padStart(2, '0') + '</td>' +
          '<td><span class="tt-tag">' + tagHtml(tag.t) + '</span></td>' +
          '<td><span class="tt-cat">' + esc(tag.c) + '</span></td>' +
          '<td>' + sparkSVG(trendSeries(tag), 'draw', 84, 22) + '</td>' +
          '<td class="c-mom"><span class="mom-num ' + momClass(tag.mom) + '">' + (tag.mom > 0 ? '+' : '') + tag.mom + '%</span></td>' +
          '<td class="num tt-vol">' + fmtVol(tag.volN) + '<span class="tt-vol-sub">' + reachLabel(tag.volN) + ' reach</span></td>' +
          '<td class="comp-cell"><div class="cc-row"><span>' + cl + '</span><span>' + tag.comp + '</span></div><div class="meter"><i class="' + (tag.comp > 60 ? 'warn' : '') + '" style="width:' + tag.comp + '%"></i></div></td>' +
          '<td class="num"><span class="score-badge">' + r.score + '</span><small style="display:block;font-size:10px;color:var(--faint)">' + r.fit + '% fit</small></td>' +
          '<td class="tt-action"><span class="icon-btn" title="Open in Analyze">' + ic('right', 14) + '</span></td>' +
        '</tr>';
      }).join('') +
    '</tbody></table></div>' +

    '<div class="foot"><span>Tagline · trends</span><span>Sorted by ' + SORTS.filter(function (s) { return s.id === t.sort; })[0].label.toLowerCase() + '. Click any row to analyze in that category.</span></div>' +
  '</div>';
}

/* ============================================================
   SAVED VIEW
   ============================================================ */

function viewSaved() {
  const tab = state.savedTab;
  const tabs = [['tags', 'Saved hashtags (' + store.savedTags.length + ')'], ['sets', 'Sets (' + store.sets.length + ')'], ['collections', 'Collections (' + store.collections.length + ')']];
  let body = '';

  if (tab === 'tags') {
    body = store.savedTags.length
      ? '<div class="saved-list">' + store.savedTags.map(function (s, i) {
          const tag = findTag(s.t) || { t: s.t, mom: 0, c: '', volN: 0 };
          return '<div class="srow" style="animation-delay:' + (i * 35) + 'ms">' +
            '<span class="si-tag2">' + tagHtml(tag.t) + '</span>' +
            '<span class="si-mom mom-num ' + momClass(tag.mom) + '">' + (tag.mom > 0 ? '+' : '') + tag.mom + '%</span>' +
            '<span class="si-meta">' + esc(tag.c || '') + '</span>' +
            '<button class="icon-btn" data-action="copy-tag" data-arg="' + esc(tag.t) + '" title="Copy">' + ic('copy', 14) + '</button>' +
            '<button class="icon-btn" data-action="unsave-tag" data-arg="' + esc(tag.t) + '" title="Remove">' + ic('trash', 14) + '</button>' +
          '</div>';
        }).join('') + '</div>'
      : '<div class="empty"><div class="empty-title">No saved hashtags</div><p>Use the bookmark action on any recommendation to keep it here.</p></div>';
  }

  if (tab === 'sets') {
    body = store.sets.length
      ? store.sets.map(function (s, i) {
          return '<div class="setcard" style="animation-delay:' + (i * 40) + 'ms">' +
            '<div class="setcard-head"><span class="sc-name">' + esc(s.name) + '</span><span class="sc-date">' + s.tags.length + ' tags · ' + esc((PLATFORMS.filter(function (p) { return p.id === s.platform; })[0] || {}).label || '') + '</span></div>' +
            '<div class="setcard-tags">' + s.tags.map(function (t) { return '<b>#' + esc(t) + '</b>'; }).join(' ') + '</div>' +
            '<div class="setcard-foot">' +
              '<button class="btn-ghost" data-action="copy-saved-set" data-arg="' + s.id + '">' + ic('copy', 12) + 'Copy all</button>' +
              '<button class="btn-ghost" data-action="open-saved-set" data-arg="' + s.id + '">' + ic('right', 12) + 'Use in Analyze</button>' +
              '<select data-action-change="assign-coll" data-arg="' + s.id + '">' +
                '<option value="">No collection</option>' +
                store.collections.map(function (c) { return '<option value="' + esc(c) + '"' + (s.collection === c ? ' selected' : '') + '>' + esc(c) + '</option>'; }).join('') +
              '</select>' +
              '<button class="icon-btn" data-action="delete-set" data-arg="' + s.id + '" title="Delete set">' + ic('trash', 14) + '</button>' +
            '</div>' +
          '</div>';
        }).join('')
      : '<div class="empty"><div class="empty-title">No sets yet</div><p>Build a selection on the Analyze page and save it with a name.</p></div>';
  }

  if (tab === 'collections') {
    body = '<div class="saved-list">' +
      store.collections.map(function (c, i) {
        const n = store.sets.filter(function (s) { return s.collection === c; }).length;
        return '<div class="coll-row" style="animation-delay:' + (i * 35) + 'ms">' +
          '<span class="cr-name">' + esc(c) + '</span>' +
          '<span class="cr-count">' + n + (n === 1 ? ' set' : ' sets') + '</span>' +
          '<button class="icon-btn" data-action="delete-coll" data-arg="' + esc(c) + '" title="Remove collection">' + ic('trash', 14) + '</button>' +
        '</div>';
      }).join('') +
      (state.namingColl
        ? '<div class="set-input-row" style="padding:12px 0 4px"><input id="collNameInput" placeholder="Collection name" maxlength="40"><button class="btn-ghost accent" data-action="confirm-coll">' + ic('check', 13) + '</button></div>'
        : '<div style="margin-top:16px"><button class="btn-ghost accent" data-action="begin-coll">' + ic('bookmark', 12) + 'New collection</button></div>') +
      '</div>';
  }

  return '' +
  '<div class="page">' +
    '<div class="page-head">' +
      '<div class="kicker no-rule">Saved</div>' +
      '<h2>Your working library</h2>' +
      '<p class="ph-sub">Tags and sets you kept. Everything stays on this device.</p>' +
    '</div>' +
    '<div class="tabs">' +
      tabs.map(function (t) { return '<button class="sort-tab' + (tab === t[0] ? ' on' : '') + '" data-action="saved-tab" data-arg="' + t[0] + '">' + t[1] + '</button>'; }).join('') +
    '</div>' +
    body +
    '<div class="foot"><span>Tagline · saved</span><span>Saved items persist locally in this preview.</span></div>' +
  '</div>';
}

/* ============================================================
   HISTORY VIEW
   ============================================================ */

/* compute a history entry's results without disturbing the live session */
function historyStats(h) {
  const saved = [state.caption, state.platform, state.category, state.strategy, state.regen];
  state.caption = h.caption; state.platform = h.platform; state.category = h.category; state.strategy = h.strategy; state.regen = 0;
  const a = computeAnalysis();
  state.caption = saved[0]; state.platform = saved[1]; state.category = saved[2]; state.strategy = saved[3]; state.regen = saved[4];
  return a ? { top: a.results.length ? a.results[0].tag.t : '', count: a.results.length } : { top: '', count: 0 };
}

function viewHistory() {
  return '' +
  '<div class="page">' +
    '<div class="page-head">' +
      '<div class="kicker no-rule">History</div>' +
      '<h2>Previous analyses</h2>' +
      '<p class="ph-sub">Every analysis is kept with its settings. Open one to reload the caption, strategy and fresh scores.</p>' +
    '</div>' +
    '<div style="margin-top:18px">' +
      store.history.map(function (h, i) {
        const p = (PLATFORMS.filter(function (x) { return x.id === h.platform; })[0] || {}).label || h.platform;
        const st = historyStats(h);
        return '<div class="hrow" data-action="open-history" data-arg="' + h.id + '" style="animation-delay:' + (i * 40) + 'ms">' +
          '<span class="h-date">' + esc(h.date) + '</span>' +
          '<span class="h-topic">' + esc(h.caption) + '</span>' +
          '<span class="h-meta">' + esc(p) + ' · ' + esc(h.strategy) + '</span>' +
          '<span class="h-meta extra">' + st.count + ' tags</span>' +
          '<span class="h-meta" style="display:flex;align-items:center;gap:10px">' + (st.top ? tagHtml(st.top) : '') + '<span class="h-arrow">' + ic('right', 14) + '</span></span>' +
        '</div>';
      }).join('') +
    '</div>' +
    '<div class="foot"><span>Tagline · history</span><span>Analyses are stored locally in this preview.</span></div>' +
  '</div>';
}

function openHistory(id) {
  const h = store.history.filter(function (x) { return x.id === id; })[0];
  if (!h) return;
  state.caption = h.caption;
  state.platform = h.platform;
  state.category = h.category;
  state.strategy = h.strategy;
  state.route = 'analyze';
  rerender();
  const ta = $('#caption');
  if (ta) ta.value = state.caption;
  updateCharCount();
  runAnalysis(true);
}

/* ============================================================
   EVENTS
   ============================================================ */

function updateCharCount() {
  const ta = $('#caption'), cc = $('#charCount');
  if (!ta || !cc) return;
  const limit = platform().captionLimit;
  const n = ta.value.length;
  cc.textContent = n + ' / ' + limit;
  cc.classList.toggle('over', n > limit);
  const staleNow = state.analysis && ta.value.trim() !== state.analysis.caption;
  if (staleNow !== state.stale) {
    state.stale = staleNow;
    if (state.analysis && !state.loading) renderResultsArea(false);
  }
}

function bindPage() {
  const ta = $('#caption');
  if (ta) {
    ta.value = state.caption;
    ta.addEventListener('input', function () {
      state.caption = ta.value;
      updateCharCount();
    });
    updateCharCount();
  }

  const cp = $('#ctlPlatform');
  if (cp) cp.addEventListener('change', function () { setPlatform(cp.value); });

  const cc = $('#ctlCategory');
  if (cc) cc.addEventListener('change', function () {
    state.category = cc.value;
    if (state.analysis) state.analysis = computeAnalysis();
    rerenderKeepCaption();
  });

  const btn = $('#btnAnalyze');
  if (btn) btn.addEventListener('click', function () { runAnalysis(false); });

  const seg = $('#segStrategy');
  if (seg) {
    $$('#segStrategy button').forEach(function (b) {
      b.addEventListener('click', function () {
        if (state.strategy === b.dataset.strategy) return;
        state.strategy = b.dataset.strategy;
        $$('#segStrategy button').forEach(function (x) { x.classList.toggle('on', x === b); });
        const hint = $('#segHint');
        if (hint) { hint.textContent = STRATEGY_HINTS[state.strategy]; hint.style.opacity = 1; }
        if (state.analysis) {
          state.analysis = computeAnalysis();
          refreshResults({ animateRows: true });
        }
      });
    });
    const hint = $('#segHint');
    if (hint) hint.textContent = STRATEGY_HINTS[state.strategy];
  }

  if (state.route === 'analyze') {
    renderResultsArea(false);
    updateRail();
  }
}

/* re-render analyze page but restore caption text into the textarea */
function rerenderKeepCaption() {
  rerender();
  const ta = $('#caption');
  if (ta) ta.value = state.caption;
  updateCharCount();
}

/* one delegated handler for everything with data-action */
document.addEventListener('click', function (e) {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const action = el.dataset.action;
  const arg = el.dataset.arg;

  if (action === 'example') {
    const i = parseInt(arg, 10);
    state.caption = EXAMPLES[i];
    const ta = $('#caption');
    if (ta) { ta.value = state.caption; ta.focus(); }
    updateCharCount();
    return;
  }
  if (action === 'row-toggle') {
    const row = el.closest('.tag-row');
    if (!row || !state.analysis) return;
    state.openRow = state.openRow === row.dataset.tag ? null : row.dataset.tag;
    const wasOpen = row.classList.contains('open');
    $$('.tag-row.open').forEach(function (r) { r.classList.remove('open'); $$('.icon-btn.chev-open', r).forEach(function (b) { b.classList.remove('chev-open'); }); });
    if (!wasOpen) {
      row.classList.add('open');
      $$('.icon-btn', row).forEach(function (b) { if (b.title === 'Why this tag') b.classList.add('chev-open'); });
      $$('.meter i[data-w]', row).forEach(function (m) {
        requestAnimationFrame(function () { m.style.width = m.dataset.w + '%'; });
      });
    }
    return;
  }
  if (action === 'row-select') {
    e.stopPropagation();
    const row = el.closest('.tag-row');
    toggleSelect(row.dataset.tag);
    return;
  }
  if (action === 'copy-tag') {
    e.stopPropagation();
    const t = arg || (el.closest('.tag-row') ? el.closest('.tag-row').dataset.tag : '');
    copyText('#' + t, 'Copied #' + t, el.classList.contains('icon-btn') ? el : null);
    return;
  }
  if (action === 'replace-tag') {
    e.stopPropagation();
    const row = el.closest('.tag-row');
    if (!row || !state.analysis) return;
    const name = row.dataset.tag;
    const idx = state.analysis.results.findIndex(function (r) { return r.tag.t === name; });
    if (idx < 0) return;
    const rep = replacementFor([name]);
    if (!rep) { toast('No alternatives left in this category.'); return; }
    const wasSel = state.selected.indexOf(name) > -1;
    if (wasSel) toggleSelect(name);
    state.analysis.results[idx] = rep;
    state.selected.push(rep.tag.t);
    refreshResults({ animateRows: true });
    requestAnimationFrame(function () {
      const newRow = $('.tag-row[data-tag="' + rep.tag.t + '"]');
      if (newRow) newRow.classList.add('swap-flash');
    });
    toast('Replaced #' + name + ' with #' + rep.tag.t);
    return;
  }
  if (action === 'save-tag') {
    e.stopPropagation();
    const t = arg || (el.closest('.tag-row') ? el.closest('.tag-row').dataset.tag : '');
    if (store.savedTags.some(function (s) { return s.t === t; })) { toast('#' + t + ' is already saved.'); return; }
    store.savedTags.unshift({ t: t, at: 'Oct 2026' });
    saveStore();
    if (el.classList.contains('btn-ghost')) el.innerHTML = ic('bookmark', 13) + 'Saved';
    toast('Saved #' + t);
    return;
  }
  if (action === 'unsave-tag') {
    e.stopPropagation();
    store.savedTags = store.savedTags.filter(function (s) { return s.t !== arg; });
    saveStore();
    rerender();
    toast('Removed #' + arg);
    return;
  }
  if (action === 'regenerate') {
    state.regen++;
    state.analysis = computeAnalysis();
    refreshResults({ animateRows: true });
    toast('Fresh trend pass complete.');
    return;
  }
  if (action === 'set-up' || action === 'set-down') {
    const i = parseInt(arg, 10);
    const j = action === 'set-up' ? i - 1 : i + 1;
    if (j < 0 || j >= state.selected.length) return;
    const tmp = state.selected[i]; state.selected[i] = state.selected[j]; state.selected[j] = tmp;
    renderSetPanel();
    return;
  }
  if (action === 'set-remove') {
    toggleSelect(state.selected[parseInt(arg, 10)]);
    return;
  }
  if (action === 'clear-set') {
    state.selected = [];
    renderSetPanel();
    $$('.tag-row.selected').forEach(function (r) { r.classList.remove('selected'); $$('.row-check', r).forEach(function (c) { c.classList.remove('on'); }); });
    return;
  }
  if (action === 'copy-set') {
    const text = state.selected.map(function (t) { return '#' + t; }).join(' ');
    copyText(text, 'Set copied. ' + state.selected.length + ' hashtags.', null);
    return;
  }
  if (action === 'begin-save-set') { state.namingSet = true; renderSetPanel(); return; }
  if (action === 'confirm-save-set') {
    const inp = $('#setNameInput');
    confirmSaveSet(inp ? inp.value : '');
    return;
  }
  if (action === 'trend-plat') { state.trends.platform = arg; rerender(); return; }
  if (action === 'trend-cat') { state.trends.category = arg; rerender(); return; }
  if (action === 'trend-sort') { state.trends.sort = arg; rerender(); return; }
  if (action === 'trend-open') {
    const tag = findTag(arg);
    if (tag) {
      state.category = tag.c;
      go('analyze');
      toast('Category set to ' + tag.c + '. Paste a post to analyze.');
    }
    return;
  }
  if (action === 'saved-tab') { state.savedTab = arg; rerender(); return; }
  if (action === 'copy-saved-set') {
    const s = store.sets.filter(function (x) { return x.id === arg; })[0];
    if (s) copyText(s.tags.map(function (t) { return '#' + t; }).join(' '), 'Copied "' + s.name + '".', null);
    return;
  }
  if (action === 'open-saved-set') {
    const s = store.sets.filter(function (x) { return x.id === arg; })[0];
    if (!s) return;
    state.selected = s.tags.slice();
    if (!state.selected.some(function (t) { return findTag(t); })) return;
    state.platform = s.platform || state.platform;
    state.category = s.category || state.category;
    go('analyze');
    toast('Set "' + s.name + '" loaded into Your set.');
    return;
  }
  if (action === 'delete-set') {
    store.sets = store.sets.filter(function (x) { return x.id !== arg; });
    saveStore();
    rerender();
    toast('Set deleted.');
    return;
  }
  if (action === 'begin-coll') { state.namingColl = true; rerender(); return; }
  if (action === 'confirm-coll') {
    const inp = $('#collNameInput');
    const name = (inp ? inp.value : '').trim();
    if (!name) { toast('Name the collection first.'); return; }
    if (!store.collections.some(function (c) { return c === name; })) store.collections.push(name);
    saveStore();
    state.namingColl = false;
    rerender();
    toast('Collection "' + name + '" created.');
    return;
  }
  if (action === 'delete-coll') {
    store.collections = store.collections.filter(function (c) { return c !== arg; });
    store.sets.forEach(function (s) { if (s.collection === arg) s.collection = ''; });
    saveStore();
    rerender();
    toast('Collection removed.');
    return;
  }
  if (action === 'open-history') { openHistory(arg); return; }
});

document.addEventListener('change', function (e) {
  const el = e.target.closest('[data-action-change]');
  if (!el) return;
  if (el.dataset.actionChange === 'assign-coll') {
    const s = store.sets.filter(function (x) { return x.id === el.dataset.arg; })[0];
    if (s) { s.collection = el.value; saveStore(); toast(el.value ? 'Moved to "' + el.value + '".' : 'Removed from collection.'); }
  }
});

/* keyboard: Cmd/Ctrl+Enter runs the analysis */
document.addEventListener('keydown', function (e) {
  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter' && state.route === 'analyze') runAnalysis(false);
});

/* ---------------- boot ---------------- */

store = loadStore();
initTopbar();
rerender();
})();
